# Liga Profesional de Fútbol da Argentina — clubes e elencos

- **País:** Argentina
- **Campeonato:** Liga Profesional de Fútbol (LPF), torneios da Primera División
- **Divisão:** 1ª divisão
- **Temporada/status:** Não há uma temporada oficial identificada como “2026/27” nas fontes oficiais consultadas. A LPF denomina a competição **Torneos LPF 2026**, com Apertura e Clausura. Em 12 de novembro de 2026, a temporada de calendário de 2026 estava em andamento: o site oficial exibia o Clausura 2026 e noticiava em 9 de novembro que Boca Juniors foi campeão da tabela anual. Portanto, os clubes abaixo são os participantes listados no regulamento da Primera División 2026, não uma lista presumida para uma temporada 2026/27.[1][2]
- **Cobertura de jogadores:** Não foi possível verificar, em fontes oficiais abertas consultadas, listas completas e contemporâneas de jogadores para cada elenco. O regulamento confirma clubes e disciplina os registros de jogadores, mas não é uma lista nominal pública de elencos; o portal público da LPF fornece torneios, fixtures e resultados. Como o usuário pediu que não se inventassem nomes nem se copiassem elencos de temporada anterior, nenhuma lista de jogadores é apresentada abaixo. “Não verificado” não significa que o clube não tenha jogadores ou que nenhuma informação individual esteja publicada em outro lugar.

## Clubes participantes e elencos

A lista de 30 clubes reproduz o Artigo 4 do regulamento oficial dos Torneios Primera División 2026. A indicação de jogadores em cada seção registra apenas a limitação de evidência pública verificável; não atribui a nenhum clube um elenco de outra temporada.[1]

### Argentinos Juniors
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Estudiantes de La Plata
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Aldosivi
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Banfield
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Barracas Central
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Belgrano
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Boca Juniors
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. O site da LPF noticia Boca como campeão da tabela anual 2026, mas essa informação não constitui uma relação de jogadores do plantel.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf); [notícia oficial: campeão da Liga 2026](https://www.ligaprofesional.ar/notas/primera/2026/11/09/boca-es-el-campeon-de-liga-2026/)

### Central Córdoba
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Gimnasia y Esgrima de Mendoza
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Huracán
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Independiente
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Lanús
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Newell’s Old Boys
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Platense
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### River Plate
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Rosario Central
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### San Lorenzo
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Sarmiento
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Talleres
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Tigre
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Atlético Tucumán
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Unión
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Vélez Sarsfield
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Gimnasia y Esgrima La Plata
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Deportivo Riestra
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Defensa y Justicia
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Independiente Rivadavia
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Instituto
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

### Racing Club
- **Jogadores:** nenhum nome de elenco completo verificável em fonte oficial consultada para 2026/27. A competição oficialmente documentada é a temporada 2026.
- **Fonte:** [Regulamento oficial LPF 2026](https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf)

## Fontes consultadas

[1] Regulamento oficial da LPF, *Reglamento Torneos Primera División 2026*. Artigos 1, 3 e 4 identificam a temporada como 2026 e listam os 30 participantes; os capítulos de Apertura e Clausura também são intitulados 2026. URL: https://www.ligaprofesional.ar/wp-content/uploads/2026/01/Reglamento-Torneos-LPF-Primera-2026-1.pdf

[2] Site oficial da Liga Profesional de Fútbol. Página inicial apresenta “Torneo Clausura Mercado Libre 2026” e a notícia de 9 de novembro de 2026 sobre o campeão da tabela anual; consultada como verificação do status contemporâneo. URL: https://www.ligaprofesional.ar/

[3] Página oficial do Torneo Apertura Mercado Libre 2026, que confirma a nomenclatura anual da competição. URL: https://www.ligaprofesional.ar/torneo-apertura-2026/
