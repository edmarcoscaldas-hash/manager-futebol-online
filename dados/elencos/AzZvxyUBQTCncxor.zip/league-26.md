# Elencos da Championship — 2026/27

**País:** Inglaterra  
**Campeonato:** EFL Championship (Sky Bet Championship)  
**Divisão:** 2ª divisão do sistema inglês  
**Temporada/status:** temporada 2026/27 em andamento; a EFL anunciou início em 14 de agosto de 2026 e conclusão da Championship em 1º de maio de 2027. O comunicado de lista de elencos foi publicado em 8 de setembro de 2026.

## Cobertura e critério

A fonte-base é a lista oficial de jogadores registrados da EFL, publicada em setembro de 2026, que contém seções “In Squad Players” e “Under 21 Contract players”. Abaixo estão transcritos os nomes nas duas categorias para os 24 participantes da Championship; nomes reproduzem a forma “sobrenome, nomes próprios” do PDF. Não são listas integrais de todo jogador contratado: cobrem os registros que aparecem nessa publicação. A composição dos clubes está identificada pela página da temporada 2026/27 e fixtures oficiais da EFL. Omissões não foram preenchidas com base em temporadas anteriores. Comissão técnica excluída.

## Clubes e jogadores

### Birmingham City

**Jogadores incluídos na lista principal:** Allsop, Ryan, Beadle, James Giles, Bird, Max Andrew, Buchanan, Lee David, Cochrane, Alexander William, Ducksch, Marvin, Flyger, August Priske, Fry, Dael Jonathan, Fujimoto, Kanya, Gardner-Hickman, Taylor Edward, Gray, Demarai Remelle, Hansen, Kristoffer Lund, Iwata, Tomoki, Klarer, Christoph, Laird, Ethan Benjamin, Mayo, Bradley Paul, Millar, Liam Alan, Neumann, Phil Yannik, Osayi Samuel, Bright, Paik, Seung-Ho, Roberts, Patrick John Joseph, Solis Romero, Jhon Elmer, Stansfield, Jay, Vazquez, Luis Ismael, Vicente Robles, Carlos.

**Jogadores com contrato U21:** Bamba Biol, Salif, Bateman, Bria, Burrell, William Harvey, Carvalho Santos Da Silva, Alezandro De Pedro, Maddox, Cobi Joel, Maphosa Mazwi, Menzi Brayden, Martin-Moore, Dynaeo Dieago, McGreevy, Finn Eamonn, O'Sullivan, William Joseph, Quirk, Jack William, Rea, Louie, Sanders, Caleb Stewart, Thompson-Jones, Riquelme Nathan Reece, Ugorji, Tobechwukwu Ogadima Michael Zereuwa, Warmington, Tyrese Karl, Wilson, Junior John.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Blackburn Rovers

**Jogadores incluídos na lista principal:** Afolayan, Oladapo Joshua, Alebiosu, Ryan Fiyinfoluwa, Baradji, Moussa, Cantwell, Todd Owen, Carter, Hayden James, De Neve, Dion, Fevrier, Jayden Raymond, Forshaw, Adam James, Garrett, Jake Joseph, Goddard, Felix Benjamin, Gudjohnsen, Andri Lucas, Jorgensen, Mathias, Kargbo, Augustus, McLoughlin, Sean Desmond, Montgomery, Kristi Julian, Morishita, Ryoya, Morsy, Samy Sayed, Ohashi, Yuki, Oliveira Ribeiro, Yuri, Pears, Aynsley Alan William, Pickering, Harry Leslie, Toth, Balazs, Wharton, Scott Bradley.

**Jogadores com contrato U21:** Atcheson, Tom Joseph, Beyuku-Bowutankoyi, Gady-Pierre, Davies, Max Adam, Decandia, Michael Stanley, Doherty, Aodhan Patrick, Dunn, Isaac Joseph, Edmondson, James Stephen, Eze, Silver Obinna, Goremusandu, Tinotenda Blessing, Higgins, Harvey Paul, Houghton, Lucas, Kamara, Osman Hassan, Leatherbarrow, Freddie Andrew, Litherland, Matthew Isaac Mark, Mansbridge, Tyler Jake, McCoy, Archie James, Michalski, Nicolas Michal, Mullarkey-Matthews, Lorenze, Ouattara, Yerime Ty Ethan, Pates, Harvey Jack Daniel, Powell, Brandon Daehan, Rice, Alfie Robert Adebowale, Sergeant, Jayden Thomas, Taylor, Finley Baxter, Vare, Frank Peter.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Bolton Wanderers

**Jogadores incluídos na lista principal:** Bair, Thelonius Alston Bradley, Bazunu, Gavin Okeroghene, Bonham, Jack Elliott, Broome, Nathan Lee, Brunt, Lewis Ray, Conway, Maxwell John, Da Rocha Rodrigues, Ruben, Dalby, Samuel George, Davies, Benjamin Keith, Dong, Kyliane Isaac Yanis, Erhahon, Ethan Jay Osadebawen, Famewo, Akinlolu Richard Olamide, Forino-Joseph, Christian Kai John, Gale, Thierry Mikael, Hardie, Ryan, Harrington, David, Iling-Junior, Samuel, Itoh, Atsuki, Larrazabal Goikoetxea, Gaizka, McAtee, John George, Nelson, Jayden, Sheehan, Joshua Luke, Simons, Xavier Levi, Stephenson, Luca Bobby, Toal, Eoin.

**Jogadores com contrato U21:** Inwood, Samuel Lawrence, Irwin, Harley Peter, King, Thomas Willoughby, Kirkpatrick, Lucas Kirkpatrick, Lawrence, Daeshon Stanley, Leigh, Harry Patrick Ellis, Lewis, Conor Ethan, Lomax, Luke Ronald, Lott, Max Matthew, Mawditt, Jack Joseph, O'Neill, Samuel James, Oliver, Emile Wesley James, Paye, Charles Henry, Rice, Harrison Stephen, Ritchie, Tobias Luca, Temple, Lewis John, Watson, David Shankland, Wilkinson, Finlay Joseph McEwan.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Bristol City

**Jogadores incluídos na lista principal:** Adebayo, Elijah Oluwaferanmi, Atkinson, Robert Philip, Ballard, Dominic, Bell, Samuel John, Cardines, Rio Solomon, Collins, Bradley Ray, De Keersmaecker, Brian, Dickie, Robert Joseph Andrew, Eile, Noah Johannes, Eissat, Lisav-Naif, Greenwood, Sam, Hirakawa, Yu, Horvat, Tomi, Knight, Jason Paul, McNally, Luke, Moir-Pring, Cameron Lewis, Randell, Adam Fletcher, Tanner, George, Thomas, Lewis Rhys, Tickle, Samuel Lloyd, Tolaj, Lorent, Twine, Scott Edward, Wallace, Jed Fernley, Williams, Joseph Michael, Yah, Gibson Osahumen.

**Jogadores com contrato U21:** Akinbo, Oluwanifemi Tolulope Victor, Anderson, Taine Charlie, Campbell-Slowey, Joshua Aaron Lloyd, Casa-Grande, Josey Brian, Derrick, Louie Leonard George, Duncan, Joseph William Alan, Ezendu, Daniel Uchechukwu, Filer, Charlie David, Finch, Isaac John Alexander, Gibbs, Tomos George Steven, Godden, Freddie Scotford, Griffin Pacheco, Jack Gordon, Hogg, Harry James, Hooper, Jack Clive, Ikpeama, Excellent, King-Phillips, Zac Alexander, Knight, Rhys Paul, Morrison, Elijah Morrison, Murphy, Adam, Naylor, Sebastian Jacob, Nelson, Raekwan Antonio, O'Neill, Billy, Osei Yeboah, Ephraim, Pecover, Leo James, Sheppard, Ruebin Lee, Skinner, Luke Alan, Thelwell, Marley Ricardo Romaine, Witchard, Jack William, Young, Ranel Jervai.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Burnley

**Jogadores incluídos na lista principal:** Ahmedhodži, Anel, Alleyne, Max Lewis Rowe, Amdouni, Mohamed Zeki, Banel, Jaydon Amauri, Broja, Armando, Coudert, Grégoire, Cullen, Joshua Jon, Dos Santos De Paulo, Igor Julio, Ekdal, Hjalmar, Hatate, Reo, Hountondji, Andreas William Edwin, Larsen, Jacob Bruun, Laurent, Joshua Ishaele Jacob-Heron, Mejbri, Hannibal, Pires Silva, Lucas, Raghouber, Ugo David, Ramazani, Largie, Ramsey, Aaron James, Roberts, Connor, Satpayev, Dastan, Sonne, Oliver, Walker, Kyle Andrew, Weiß, Max Oliver, Vardy, Jamie Richard.

**Jogadores com contrato U21:** Adewumi, Oluwaseun Victor, Agyei, Enock, Airoboma, Emmanuel Ehigie, Balogun, Hamzat Alamu O O A O, Bauress, Joseph Michael, Borgesson, Blayz Burnell, Brierley, George Alexander, Campbell, Murray Craig, Castell Sole, Lluc, Clark, Ellis, Cooney, Oisin Pedraig, Derbyshire, Braidin Francis Tadhg, Edwards, Connor Jack, Forshaw, Lewis Dean, Jiaming, Zhang, Johnson, Zachary David, King, Corey Mikel, Luwawu, Delfim Betuela, McMahon-Brown, Kian, Pimlott, Oliver Edmund David, Pouani Siewe, Brandon Ellison, Robinson, Jack William, Savage, Troy Greig Samuel, Scott, Cameron Iain, Stanley, Michael Ray, Williams, Jesse Okonofua.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Cardiff City

**Jogadores incluídos na lista principal:** Ashford, Cian Ty, Bagan, Joel Matthew, Bielik, Krystian, Chambers, Calum, Colwill, Joel WIlliam, Colwill, Rubin James, Davies, Isaak James, Fish, William Thomas, Moylan, Jack, Ng, Perry Tian Hee, Osho, Gabriel Jeremiah Adedayo, Robertson, Alexander Sean Pablo, Robinson, Callum Jack, Salech, Yousef, Scanlon, Calum Alexander, Tanner, Oliver Anthony, Trott, Nathan Wallace Newman, Turnbull, David, Turner, Matthew David, Tyrer, Harry Alfred, Willock, Christopher Anthony.

**Jogadores com contrato U21:** Allmark, Hayden Ian Slocombe, Armstrong, Luke, Barton, Mannie, Davies, Isaac Tiger, Davies, Jake Thomas, Debono, Alyas Tony Kyle, George, Trey Ellis, Giles, Luey Philip, Griffiths, Ewan Henri, Higgs, Daniel Evan, Hilaire-Clarke, Riley, James, Herbie George, Kaba, Sekou, Katsukunya, Thierry Alfred Farai, Keita, Gabriel Ofosu, Kpakio, Ronan Sahr, Lawlor, Dylan Rhys, Mafico, Dakarai Asante, Nyakuhwa, Tanatswa Thierry, O'Brien, Charlie Michael, Okoli-Parfitt, T-Jay Chibuzo, Ola, Daniel Olutayo Olatimeyin, Perrett, Troy Ryan, Tankiewicz, Robert Mariusz, Thomas, Jac Edward, Twose, Cody William, Voice, Caden John Brian, Williams, Noah Elliot.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Charlton Athletic

**Jogadores incluídos na lista principal:** Ahearne-Grant, Karlan Laughton, Alli, Millenic Oluwole Sulaiman, Apter, Robert Julian, Bell, Amari'i Kyren, Bindon, Tyler Grant, Brooks, Tiernan Jon, Campbell, Tyreece Anthony Tupac Shakur, Carey, Sonny Jack, Chalobah, Nathaniel, Coventry, Conor James, Edwards, Joshua John, Godden, Matthew James, Jones, Lloyd Richard, Knibbs, Harvey Andrew, Koumetio, Billy Dawson, Leaburn, Miles Lester, Lee-Kelman, Charlie Robert Martin, Mannion, William John, McNamara, Danny, Mesik, Ivan, Okonkwo, Arthur Chukwuezugo, Ouma, Timothy Noor, Ramsay, Kayne Richard Junior, Rankin-Costello, Joseph Scott, Skipp, Oliver.

**Jogadores com contrato U21:** Belton, Jack, Brown, Ethan Marcel Solomon, Burnham, Shia-Lee Wayne, Davis, Dionte Tyler, Elliott, Tate Levi, Ewens-Findlay, Ty Joseph, Forzah Nkeng, Robert Junior, Fullah, Ibrahim Mohamed, Gough, Keenan Blue, Hardy, George Henry, Hebert, Joshua Michael, Kobashi Enslin, Kai, Laqeretabua, Joshua, Mbick, Micah Lionel, McMillan, Ellis Solomon Laurel Kingsley Knight Oluwole, Mitchell, Zach Joseph, Mwamba, Alan Isaac, Rayment-Dawkins, Marley Skye, Reid, Reuben Raheme, Rylah, Henry Alan Zachariah, Safa, Jacob Ruhy, Sol-Loza, Emmanuel-Mary Hadriel, Tagoe, Bradley Nii-Aryee, Tiitinen, Otto Henrik Arthur, Valentine, Phoenix Vincenzo Adekunle Gemma, Wales, Manu Isaac Thomas, Washington-Amoah, Samuel Yawson, Woodham, Finley James.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Derby County

**Jogadores incluídos na lista principal:** Agyemang, Patrick Kwakye, Bilbija, Filip, Blackett-Taylor, Corey Josiah Paul, Brewster, Rhian Joel, Cashin, Eiran Joe, Clarke, Matthew Edward Barkell, Forsyth, Craig, Fraulo, Oscar Luigi, Fuseini, Mohammed Gadafi, Hedges, Ryan Peter, Johnston, Max, Langas, Sondre Klingen, Meister, Henrik, Morris, Carlton John, Mowatt, Alex James, Nyambe, Simiasku Ryan, Salvesen, Lars-Jorgen, Sanderson, Dion Dannie Leonard, Szmodics, Samuel Joseph, Taylor, Charles James, Travis, Lewis, Vickers, Joshua Anthony, Ward, Joseph Henry, Widell Zetterstrom, Jacob Mikael.

**Jogadores com contrato U21:** Agbawodikiezu, Charles Chuckwuebuka Ebubechukw, Allen, Cruz Anthony, Banks, Luke Marcus, Brown, Dajaune Anthony, Canoville, Rio Joseph, Clark, Bobby Lamont, Corry, Sean Niall, Crolla-Dowe, Luca William, Davidson, Jaydan Simeon, Eames, Owen Thomas, Friars, Alfie Kevin, Gill, Tristan Louie Miles, Gordon, Isaac Samuel, Gordon, Khace Sheene, Green, Israel Henry, Griffiths, Euan Alexander, Halliwell, Alfie Bryn, Hodges, Dantel Dayan, Jones, Frankie, Kane, Samuel Jacob, McAndrew, Niall Patrick, Mintus, Marley Harry, Offor, Raymond Okezie, Oguntolu, Justin Femi, Osayande, Adisa Kweli, Osong, Johnson Shum, Ozoh, David Ikechukwu, Price, Harley Leslie, Richards, Jerome Sean, Robinson, Keilen Joseph, Smith, Charlie, Tola, Marsel, Turley, Freddie Michael Joseph, Wilson, Cameron Aston, Wren, Kean Adam.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Lincoln City

**Jogadores incluídos na lista principal:** Bayliss, Thomas David, Bradley, Sonny, Coubi, Andrei, Draper, Frederick Charles, Elder, Callum Roddie, Elerewe, Ayodeji Joshua Oluwapelumi Akinola, Gauci, Joe Anthony, Hackett-Fairchild, Reeco Lee, Hamer, Thomas Philip, Honohan, Joshua Phillip, House, Benjamin, Jefferies, Dominic William, Konak, Yunus Emre, Ladefoged, Mikkel Riis, McGrandles, Conor, Melia, Mason, Ogbene, Chiedozie Somkelechukwu, Olaofe, Isaac Tanitoluwaloba, Oyegoke, Daniel Oladele Akinbiyi, Reach, Adam Michael, Street, Robert Nicholas, Towler, Ryley Ben, Varfolomieiev, Ivan, Wheatley, Ethan Joseph, Wickens, George Alexander.

**Jogadores com contrato U21:** Okoro, Zane Kola, Parks, Charles Kenneth.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Middlesbrough

**Jogadores incluídos na lista principal:** Arfsten, Maximilian Michael, Bangura, Alex, Barron, Connor Clark, Berhalter, Sebastian, Borges Dos Santos Neto, Vivaldo, Brittain, Callum James, Brynn, Solomon, Byram, Samuel Mark, Conway, Tommy Daniel John, Cozier-Duberry, Amario, Edmundson, Samuel George Alan, Hamilton, Micah, Harris, Myles Spencer, Jones, Alfie Charles, Joseph, Kyle Alexander, Malanda, Adilson Keithe Michel, McGree, Riley PatrIck, McLaughlin, Jonathan Peter, Morris, Aidan Zen Patrick, Pukstas, Rokas, Sarmiento Morante, Jeremy Leonel, Strelec, David, Vitek, Radek, Weller-Ayling, Luke David.

**Jogadores com contrato U21:** Bernard, Dwayne Junior, Campbell, Layton Hugh, Carbon, Jayden Elijah, Cartwright, Finlay James, Castledine, Leo Alexander Francis, Cole, Cayden Peter Maxwell, Connor, Shea Christy, Coulson, Frankie Jake, Daley, Jack Robert Douglas, Dede, Josh Lewis Oghenerume, Foster, Owen Jacob Anthony, Greenup, Isaac James, Harrison, Lucas Christopher, Hinneh, Listowell Lord, Hunt, Harley Peter, Ibeh, Cruz Jonathan, James, Daniel Michael Sisihu, Johnson, Brayden Nana Yaw, Lankshear, William Terence, Martin, Oliver Allan, McCabe, Law Marc, McCormick, George Mark, Munroe, Finley Christopher Ryan, Okunola, Abdulhalim Olanrewaju O, Parker, Leon Kai, Patterson Powell, Rio Dior Kayden, Phillips, Ashley, Samuels, Oliver, Tika-Lemba, Ezra Gabriel Mekhi, Wilson, James.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Millwall

**Jogadores incluídos na lista principal:** Arconte, Taïryk, Baggott, Elkan William Tio, Batth, Daniel Tanveer, Coburn, Joshua Guy, Cooper, Jake Matthew, Crama, Tristan Pierre, Crocombe, Maxime Teremoana, Cundle, Luke James, De Norre, Casper, Doughty, Alfie Henry, Dykes, Lyndon John, Esse, Romain Joy Kouakou, Ivanovi, Mihailo, Jensen, Lukas Bornhoft, Leonard, Ryan Ian, Lisbie, Kyrell Jeremiah, Marschall, Filip, Mazou-Sacko, Derek Youri Jean Etienne, Metcalfe, Jenson Thomas John, Neghli, Camiel, Osei-Tutu, Jordi Martin Emmanuel, Servais, Mathis, Sturge, Zak Norton, Sykes, Mark, Taylor, Caleb Joaquin.

**Jogadores com contrato U21:** Beaumont, George Hedley, Clark Evans, George David, Freedman, Freddie Ray, Howland, Jack Thomas, Issoufou, Yanis Ali, Kelly, Daniel, Kendall, Sheldon Anthony, Kirby, Archie James, Lamptey, Rafiq Yaw Nii Lantei, Lovelace, Zakariya Shakeel, Mansor, Elias, Massey, Alfie Ben, Matthews, Ajay, Ofori-Manteaw, Lloyd Junior, Ojetoro Amachree, Abdulwahab Iyanda Omogbolahon, Przewozny, Jakub Mateusz, Redhead, Caleb Paul, Sandford, Ronnie William, Taylor, Harry Dwain, Tektas, Jayden Marc Jem, Thomas-Smith, Jaydon Darnell, Tsugita Vieira, Sacha Natsuki.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Norwich City

**Jogadores incluídos na lista principal:** Ansen, Caleb Kinful, Ben Slimane, Anis, Brooks, Andre Chance, Chrisene, Benjamin Joshua, Cordoba Chambers, Jose Angel, Crnac, Ante, Darling, Harry Jack, Diallo, Papa Amadou, Ferreira Alves, Bruno, Field, Samuel Edward, Fisher, Kellen Lucas, Grimshaw, Daniel James, Kovacevic, Vladan, Kvistgaarden, Mathias Damm, Maghoma, Edmond-Paris, Makama, Jovon Willesley, Mattsson, Pelle ElkjÆr, McLean, Kenneth, Musaba, Anthony Tite Emmanuel, Reyes, Vicente Phillip, Stacey, Jack William, Topic, Mirko, Toure, Mohamed A, Yongwa Ngameni, Darlin Zidane.

**Jogadores com contrato U21:** Adelusi, Theodore Olakitan Ademide, Ameen, Botan, Baumann, Zachary Joseph, Bracking Makonese, Miles Munyaradzi, Chilvers, Toby James, Chukwu, Luke Dubem, Cooper, Reuben Brian, Corke, Finlay John Patrick, Djedje, Uriah Darren, Domeracki, Alan, Forsyth, Gabriel Kevin, Glossop, Jake Francis, Gwanzura, Takudzwa Cohen, Jones, Dylan Kye, Lines, Luis Paul, Mahovo, Lucien Denhere Patrick Java, McConville, Ruairi Conor, McCourt, Glenn Conor, McGinley Leonard, Vincent Scott, Mitchell, Rylee Kyran Cain, Mundle, Rio York, Mundle-Smith, Errol Isaiah O'Neil, Myles, Elliot Jermaine Akinola, Okpiabhele, Emmanuel Oserhiemen Temitope T, Oligbo, Finlay Nicholas, Ozcan, Vatan Oguz, Rowland, Sonny William, Schwartau, Oscar, Sinclair-Brown, Jeremiah Lee, Steele, Kahlil Ari, Towler, Luke James, Tree, Benjamin Assongo, Wilkes, Reece Ashton, Williams, Tyler James, Wright, Jacob Anthony.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Portsmouth

**Jogadores incluídos na lista principal:** Adams, Ebrima, Arthur, Benjamin Kristian, Bailey, Odin Ohray, Bielica, Daniel Henryk, Bishop, Colby David, Devlin, Terry Joseph, Dia, Madiodio, Kamara, Abu Bakarr, Kavuma-McQueen, Ryan Denis Edward, Killip, Ben, Meghoma, Jayden Ade Trindade, Milovanovic, Marko, Mohamed, Iyad Inomse M'vourani, Pack, Marlon, Poole, Regan Leslie, Schmid, Nicolas, Segecic, Adrian, Shade, Tyrese Jamess, Shaughnessy, Conor, Shein, Rocco Robert, Swanson, Zak, Swift, John David.

**Jogadores com contrato U21:** Agu, Chinedu Fred Ayomide, Ani, Michael Obinna, Brooke-Smith, Luke Joseph, Chioma, Nathaniel Ugochukwu Chimezie, Kenny, Eoin Richard, Singerr, Olutayo Joseph Kai, Steward, Toby Peter Gary, Umeh, Franco Chibueze, Waddingham, Thomas Anthony.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Preston North End

**Jogadores incluídos na lista principal:** Burgzorg, Delano Dwayne, Clarke, Harrison Thomas, Devine, Alfie Sean, Erabi, Jusef, Gibbs, Liam, Gibson, Lewis Jack, Hughes, Andrew Martyn, Iversen, Daniel Lønne, Kenny, Johnny, Lang, Callum Joseph, Leroy, Léo Patrick Pierre, Lindsay, Liam James, McCann, Alistair Edward, Mills, Stanley, Moran, Andrew, Nicholls, Lee Anthony, Offiah, Odeluga Joshua, Potts, Bradley, Small, Thierry, Storey, Jordan Ben, Thompson, Jordan Andrew, Valentín Sancho, Pol, Vukevi, Andrija, Wiley, Caleb Ryan.

**Jogadores com contrato U21:** Cameron, Finlay Sean, Carroll, Theo Jon, Gryba, George Thomas, Irwin, Isaac Peter, Kamara, Kaedyn Kabbar, Nelson, Kitt Edward, Nolan, Edward Anthony, O'Sullivan, Cathal James, Pasiek, Kacper Nikodem, Snowball, Nathan Kristian, Stowell, Li-Bau Kenny, Stringfellow, Harry, Tarry, Troy Junior, Wilson, Max Riley.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Queens Park Rangers

**Jogadores incluídos na lista principal:** Adamson, Kealey Otieno, Adubofour Poku, Kwame Afriyie, Burrell, Rumarn Kameron-Scott, Chair, Ilias Emilian, Charles, Pierce Joseph, Cirkin, Dennis, Clarke-Salter, Jake Liam, Dunne, James Gerard, Edwards, Ronnie Lee, Kamara, Glen Adjei, Kemper, Boy Jacobus Gerardus Maria, Kone, Richard, Lamptey, Tariq Kwame Nii Lante, Lloyd, Alfie David, Madsen, Nicolas Martin Hautorp, Mbengue, Amadou Salif, Morrison, Liam John, Obikwu, Justin Patrick Nnamdi, Saito, Koki, Salamon, Matteo, Smyth, Paul Patrick, Vale, Harvey James, Varane, Jonathan Raymond Francois, Ward, Calum Brian Joseph.

**Jogadores com contrato U21:** Adjetey-Brew, Cory Ugene Michael Kwadwo Krasare, Agbude, Kobe Jaques Ojeyme, Akindileni, Timothy Ayomide, Alemayehu Mulugeta, Isak Alexander, Bennie, Daniel Ian, Brunson, Kalen Ryan, Dyke, Kaleb Asher, Friel, Rocco John Michael, Hassan, Ridwanullahi Oladeji Ayinde, Kolli, Rayan Jawad, Mendes Da Silva, Joao Henrique, Morgan, Kieran Lloyd, Neill, Fraser George Drew, O'Brien, Archie Joseph, Pearman, Jaylan Bradley, Pullella, Christian David, Putman, Jaiden Ellis, Sanghrajka, Amar Nur, Sanyaolu, Philip Olanrewaju Tobiloba Emmanuel Oladipo Alani, Scarlett, Leon Jayden, Smith, Tylon Christopher, Sutton, Emmerson Malachi Hopeton, Tarbotton, Teddy, Warren, Charlie Fredrick.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Sheffield United

**Jogadores incluídos na lista principal:** Arblaster, Oliver Luke, Ayew, Jordan Pierre, Bamford, Patrick James, Baptiste, Jamal Marcus, Brereton, Benjamin Anthony, Burrows, Harrison James, Campbell, Tyrese Kai, Cannon, Thomas Christopher, Chong, Tahith Jose Girigorio Djorkaef, Cooper, Michael John, Davies, Adam Rhys, Dewan Choudhury, Hamza, Doherty, Matthew James, Donovan, Romelle Troy, Kitching, Liam James, McCallum, Sam Benjamin, McGuinness, Mark James, Norrington-Davies, Rhys Llewelyn, Peck, Sydie Frederick, Phillips, Kalvin, Riedewald, Jairo Jocquim, Rothwell, Joseph Matthew, Seriki, Oluwafemi Ibrahim, Shackleton, Jamie Stuart, Tanganga, Japhet Manzambi.

**Jogadores com contrato U21:** Asante-Boakye, Maxwell Kwesi, Aston, Samual James, Barrett-Underwood, Keehan Francis, Beattie, Jevan, Blacker, Billy Rolfe, Christie-Crainie, Archie John Gordon, Colechin, Samuel Gary, Coubrough, Arlo Hughie, Curtis, Sam, Eadie, Christopher James, Faxon, Luke John, Giggs, Zach Joseph, Grainger, Benjamin Anthony, Hay, Cole, Hewitson, Coby Anthony Mark, Hough, Alfie David, Howard, Theo Charles, Makhalira, Jaydon Maziko, McGlinchey, Harry Daniel, Okyere, Seth Okyere Boah, One, Ryan Martin, Patterson, Lennon Alex, Polendakov, Mihail Yordanov, Poppleton, Matthew William, Purches, Benjamin, Reid, Aaron John, Sachdev, Sai Sachin Rony, Sasnauskas, Dovydas, Sidibe, Lamine, Tahir, Zain Ashan, Tinsdale, Jay Dillan, Zatterstrom, Nils Erik Ulf.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Southampton

**Jogadores incluídos na lista principal:** Abbott, Zach MacFarlane, Azaz, Finn Isaac, Bragg, Cameron Roger, Bree, James Patrick, Damascena Santos, Welington, Dobbin, Lewis, Downes, Flynn, Edozie, Samuel Ikechukwu, Fellows, Tom Allen, Jander, Casper, Jones, Jamie, Larin, Cyle Christopher, Long, George Martin, Manning, Ryan Phelim, Matsuki, Kuryu, Mubama, Divin Saku, Peretz, Daniel, Ramsdale, Aaron, Rasmussen, Mads Roerslev, Schlotterbeck, Keven Matteo, Stephens, Jack, Ward-Prowse, James Michael Edward, Weschenfelder Scienza, Leonardo, Wood-Gordon, Nathan Dean Joshua.

**Jogadores com contrato U21:** Abbotson, Oscar Thomas, Adjei-Afriyie, Hansel, Afzal, Harris Jackson, Akachukwu, Romeo, Anderson, Calum Trevor, Bailey, Lewis Gregory, Boot, Nathanael Joshua Asiimwe, Charles, Brandon Davis, Daley, Aston, Dipepa, Baylee Jack, Dobson-Ventura, Tommy Eric, Ehibhatiomhan, Princewill Omonefe, Fry, Max Joseph, Gathercole, Harry John, Gbajumo, Davon Nana Kwabena Abdul Wasui, Grieves, Xander Thomas, Hawe, Luke Thomas, Kakay, Sutura, Kayi Sanda, Joachim, McMullan, Korban James, Moody, Dylan Lewis, Moore, Jayden James, Newman, Oliver Jacob, Nutter, Walter Edward Robert, Oyekunle, Adetokunbo Adewale Ayomide, Robinson, Jay Steven, Rohart-Brown, Thierry David, Sesay, Jonathan Moses Momoh, Sewell, Broghan Rannell, Sillah Dibaga, Sufianu, Tounkara, Issa, Traore, Daouda, Umeh, Leo Chidiebere, Vallance, Jake Benjamin, Whittaker, Rory Innes, Williams, Barnaby Joe.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Stoke City

**Jogadores incluídos na lista principal:** Bae, Junho, Bocat, Eric-Junior Doriane Magate Kom Baga, Bozenik, Robert, Cisse, Mohamed Lamine, Cresswell, Aaron William, Devenny, Justin, Fielding, Francis David, Galbraith, Ethan Stuart William, Gallagher, Samuel James, Gibson, Benjamin James, Graham, Luke Robin, Griffiths, Joshua James, Hirst, George David Eric, Ingelsson, Svante Ulf Ingel, Johansson, Tobias Viktor, Johnson, Benjamin Anthony, Lawal, Mohammed Olabosun, Manhoef, Million Eljoenai Levinio, McGlynn, Jack Ryan, Pearson, Benjamin David, Rigo, Tomas, Soumare, Elhadji Djibril, Talovierov, Maksym, Tchamadeu, Junior Baptiste, Wilmot, Benjamin Lewis.

**Jogadores com contrato U21:** Achu, Tristan Formuzang, Agina, Sydney Cesc Jean, Ampah, Ato Bondze, Anderson, Freddie Samuel, Baptista Hamelberg, Eric Albert, Bombino, Luca Dylan, Chibueze, Chinonso McAnthony Abi, Clothier, Caleb Shael, Cooper, Noah Kailen, Curley, Ruben, Enabulele, Oghosaiwi Rafael, Fawunmi, Favour Ayobamide Daniel, Fearn, Elliot, Festus Eyaife, Daniel, Giani, Laurence Adam, Grant, True Blakeley, Kelly, Gabriel Francis, Knight, Lucas Thomas Grant, Kynaston Bradbury, Louie Jacob, Kyremeh, Jerome Osei, Liu, Ryan James Jun Wen, Lowe, Nathan Alexander, Makavore, Paul Nyakeh, Martin, Tyler Emmanuel Alexander, Maskall, Joshua Flynn, Mears, Jaden Jamil, Morrison, George William, Newall, Jack John, Ogbebor, Jayden Chukwudi Nosakhare, Otegbayo, Raphael Pijus, Phillips, Sanchez Amore, Powell, Owen Johny, Tezgel, Emre James Vann, Thompson, Will Iain, Walker, Adriel Donald Thomas.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Swansea City

**Jogadores incluídos na lista principal:** Antunes Eustaquio, Stephen, Appleby Farman, Paul David, Baptista Franco, Gonçalo, Cabango, Benjamin, Eom, Jisung, Fisher, Andrew Lee, Fulton, Jay, Geraldes Parente, Tiago Miguel, Idah, Adam, Just, Elijah Henry, Key, Joshua Myles Abraham, Lissah, Filip Augustus, Monga, Jeremy Ngola, Pereira Martins, Ronald, Seelt, Jenson Danluca, Stamenic, Marko Seufatu Nikola, Stewart, Ross Cameron, Tymon, Joshua Lewis, Vigouroux, Lawrence, Vipotnik, Žan, Watts, Evan Thomas, Welsh, Stephen John, Widell, Viktor Melker, Yeo, Moussa Kounfolo.

**Jogadores com contrato U21:** Asemokhai, Gregory Oshogbeh, Bates, Morgan Trevor, Bowen, Staitham Michael, Clarke, Billy Oscar, Collins, Joseph Rory, Cook, Jacob Benjamin, Dabrowski, Sebastian, Davies, Joseph Gabriel, Demery, Caleb Anthony, Fanning, Jack William, Govea Merlin, David Aimar, Griffith, Yori, Heywood, Carter Mark James, Ifans, Caio Sion, Iorpenda, Thomas Achi, Jones, Callum David, Jones, Iestyn David, Lloyd, Ben Nicholas, McKenzie, Blair, Opoku, Joseph Amankwaah, Parker, Arthur George, Parker, Samuel David, Perry, Harlan Emrys, Pescatore, Joshua Mario Brian, Rees-Siso, Ramon, Robinson, Milo Carter, Searle, Thomas Christopher, Wales, Bobby James, Watts, Daniel, Woodward, Thomas Charles.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Watford

**Jogadores incluídos na lista principal:** Baah, Kwadwo Kyeremeh, Bachmann, Daniel, Boadu, Myron Kwasi Koomson, Bola, Marc Joel, Bove, Edoardo, Clarridge, James Andrew, Coulibaly, Soumaila, Grieves, Jack Alexander, Kayembe, Edo, Keben Biakolo, Kevin Xavier, Kjerrumgaard, Luca Tange, Kyprianou, Hector Matthew, Marriott, Alfie Simon Rodney, Mavididi, Stephy Alvaro, Mlacic, Branimir, Ngakia, Jeremy Mpobi, Payero, Martin Ismael, Pollock, Mattie William, Ravaglia, Federico, Traore, Omar Haktab, Walker, Samuel Colin, Zemura, Jordan Bhekithemba.

**Jogadores com contrato U21:** Adu-Poku, Michael Kofi, Akinyimika, Oluwatobi Mikel, Akomeah, Travis, Bravo Solanilla, Iker, Browne, Roraigh Woodthorpe, Chikovani, Nikoloz, Doumbia, Mamadou, Eames, Albert George, Galajevs, Marats, Georgiou, Thomas Joe, Hunt, Conrad, Maamma, Othmane, MacAulay, Jonathan Ludvig, Morris, Samuel Anthony, Moulton, Jai-Dea Stephen Angel, Moulton, Remiero Adam John, Mullins, Joshua George Jack, Nabizada, Amin, Odiase, Kashopefoluwa Orlando, Okosun, Nickson Ebigualor, Ortelli, Gabriel George, Ramirez-Espain Swart, Leonardo Petrus, Semedo Moura De Sousa, Vivaldo Leandro, Smith, Max James, Smith Daley, Kymani Jahiem, Stephenson, Oliver Michael, Thrussell, Sebastian Beau, Vancea, Raul Mihai, Vata, Rocco.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### West Bromwich Albion

**Jogadores incluídos na lista principal:** Bani Odeh, Tamer Jehad Abdallah, Campbell, George Hampton, Collyer, Tobias Christopher, Diakite, Ousmane, Galves, Nolan, Heggebo, Aune Selland, Ingram, Matthew Robert, Johnston, Michael Andrew, Mepham, Christopher, Molumby, Jayson, Morgan, Jimmy-Jay, Myhre, Felix Horn, Nzingoula, Rabby Alexandre Jason, O'Leary, Max Edward, Pereira, Brayann Leanceley Christva, Phillips, Nathaniel Harry, Price, Isaac, Stewart, Barnaby Jude Columbus, Styles, Callum, Townsend, Conor Stephen, Tunde Ruiz, Kareem, Whitwell, Harry John Daniel, Williams, Alexander David.

**Jogadores com contrato U21:** Abudu, Abdulhakeem Oluwatobiloba, Blackshields, Charlie Brian, Bostock, Oliver David, Brady, Louis James, Bray, Jack owen, Cisse, Ben Foumba, Colesby, Ryan Stuart, Crowther, Matthew William, Deeming, Cole Thomas, Dlamini, Nathan Mpho, Dupont, Noah Charles Evenor, Francis-Caesar, Jaiden Desean, French, Harry Oliver, Iddrisa, Dauda Amihere, Letlat, Adam, Lucas, Kayden, Maughan, Alfie James, McNeil, Remar Sheldon, Mohammed, Jamal Samir Haroon, Moses, Maxwell Kelvington, Okonkwo, Brian Chukwuedozie, Parmar, Rio, Perkins, Antonio, Pinnington, Carter William, Rutter, William, Shaw, George Taylor, Wallis, Joseph.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### West Ham United

**Jogadores incluídos na lista principal:** Alvarez Velazquez, Edson Omar, Areola, Alphonse Francis, Boiro Boiro, Adama, Bowen, Jarrod, Castellanos Gimenez, Valentin Mariano Jose, Cornet, Gnaly Albert Maxwel, Engels, Arne, Golambeckis, Airidas, Hermansen, Mads, Kilman, Maximilian, Lamadrid Briceno, Keiber Alberto, Magassa, Soungoutou, Mavropanos, Konstantinos, Mayers, Ezra Samuel Korbinian, Mukasa, Divine Tayon Mahogany, Orford, Lewis William, Pereira De Jesus, Pablo Felipe, Piroe, Joel Mohammed Ramzan, Rodrigues Da Silva, Felipe, Scarles, Oliver James, Solomon, Manor, Soucek, Tomas, Veltman, Joel Ivo, Walker-Peters, Kyle Leonardus.

**Jogadores com contrato U21:** Ajala, Joshua Oluwaseun Oladimeji, Austbo, Edvin, Awesu, Olanrewaju Mubarak, Balogun-Ajisafe, Majid Omobolaji, Battrum, Ryan Lewis Denis, Beckford, Lewis Wayne, Briggs, Joshua Joseph, Brooks, Connor Michael Kenny, Brown, Luis George, Caliste, Gabriel Paul Russie, Cummings, Daniel, Dike, Andre Obinna, Fearon, Preston Royston, Hargan, Riley Mason Christopher, Herrick, Finlay Jacob, Hooper, Finley John, Kamara, Aaron Affieu, Kante, Mohamadou, Kerr, Joel James, Landers, Josh Finlay, Leacock, Callum Samuel, Medine, Jethro Claude, Murphy, Jett Thomas, Oyebade, Rayan Oladayo, Thomas, Isaac Michael.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Wolverhampton Wanderers

**Jogadores incluídos na lista principal:** Armstrong, Adam James, Bellegarde, Jeanricner, Bueno Lopez, Hugo, Chirewa, Tawanda Blessing, Djiga, Yacouba Nasser, Doyle, Thomas Glyn, Gomes, Tote Antonio, James, Jordan Anthony, Jimenez Rodriguez, Raul Alonso, Konan, N'Clomande Ghislain, Krejci, Ladislav, Lopez Gonzalez, Fernando, Malheiro De Sa, Jose Pedro, Martins Gomes, Rodrigo, Mosquera Valdelamar, Yerson, Munetsi, Marshall Nyasha, Neave, Sean Thomas, Neves Val Bento Virginia, Joao Manuel, Ruddy, John Thomas Gordon, Said Ahamada, Rafiki, Tchatchoua, Jackson, Traore, Boubacar, Trindade Da Costa Neto, Andre, Trippier, Kieran John.

**Jogadores com contrato U21:** Anunlopo, Oladapo Sean, Ashworth, Finlay, Ballard-Matthews, Emilio Les, Benjamin, Lewys James, Bowen, Reiss Jaya, Bradbury, Makenzie Jack, Bula Dami Mane, Mateus, Cardoso De Lima, Pedro Henrique, Chiwome, Leon, Dayman, Myles Jayden Alfie, Edozie, Thomas, Elendu, Elvis Ugochukwunyerm, Enguru Mangue, Daniel, Ford, Hayden Christopher, Fraser, Nathan John Mark, Gonzalez Medina, Enso David, Gracey, Joshua Daniel, Harrison, Adam Alan, Ji, Min Kyu, Lochhead, Sebastian Scott William, Mcleod, Conor William, Nolan-Ruddock, Max Ethan, O'Donnell, Luke Francis, Ojinnaka, Temple Uchenna, Okoduwa, Wesley Eboselume, Olagunju, Saheed Oluwapelumi, Rawlings, Lucas Kai, Sutherland, Ethan Daniel, White, Alfie Thomas, Williams, Ashton Harley.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

### Wrexham

**Jogadores incluídos na lista principal:** Broadhead, Nathan Paul, Cleworth, Max George, Dobson, George David, Doyle, Callum Craig, Ekomie, Jaques Emmanuel Paul, Hyam, Dominic John, Imray, Daniel Edward Peter, James, Matthew Lee, Kabore, Issa, Longman, Ryan James, Moore, Keiffer Roberto Francisco, O'Brien, Lewis John, O'Hare, Callum Luke, Patterson, Anthony William, Rathbone, Oliver Michael, Smith, Samuel Toby, Vyner, Zachary George Onyego, Ward, Daniel, Whiteman, Benjamin, Windass, Joshua Dean, WORRALL, JOSEPH ADRIAN.

**Jogadores com contrato U21:** Cadamarteri, Bailey-Tye, Chesworth, Samuel David, Clayton, Tommy Stuart Neil, Cruise, George, Edwards, Dafydd Vaughan, James, Aaron Thomas, McTweed, Oliver Jack Wilson, Moore, Alexander James, Owen, Rio Lloyd, Rees, Joe Gavin.

**Fonte por clube:** [Lista oficial da EFL 2026/27 (PDF)](https://images.gc.eflservices.co.uk/c0eadad0-aba0-11f1-ab8f-c3717d4e1e2b.pdf).

## Fontes principais

- EFL, [EFL Squad List: Season 2026/27](https://efl.com/news/2026/september/08/efl-squad-list--season-2026-27/) (8 set. 2026), com PDF oficial vinculado.
- EFL, [The 2026/27 EFL Fixtures are here](https://efl.com/news/2026/june/25/the-2026-27-efl-fixtures-are-here/) (25 jun. 2026), datas do campeonato e início da temporada.
- [2026–27 EFL Championship](https://en.wikipedia.org/wiki/2026%E2%80%9327_EFL_Championship), referência secundária para a relação de participantes e mudanças de divisão.
