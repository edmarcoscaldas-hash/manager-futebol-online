# Segunda División (LALIGA HYPERMOTION) — 2026/27

- **País:** Espanha
- **Campeonato:** LALIGA HYPERMOTION (Segunda División)
- **Divisão:** segunda divisão masculina
- **Temporada/status:** 2026/27 em andamento. Em 12 de novembro de 2026, o calendário oficial já registrava a 13ª rodada, com partidas disputadas entre 6 e 9 de novembro. [2]
- **Critério de nomes:** incluí apenas jogadores que consegui verificar publicamente em conteúdo legível de elenco especificamente identificado como 2026/27. A página da liga disponibiliza um link oficial de “Plantilla” para cada equipe e mostra o título de elenco 2026/27 em pelo menos uma página examinada, mas o conteúdo acessível nessa página não expõe nomes de jogadores. Para não atribuir nomes de temporada passada ou inventar dados, as listas abaixo ficam explicitamente sem nomes verificados nesta coleta.

## AD Ceuta FC

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A ficha oficial identifica “Plantilla oficial del AD Ceuta FC 2026/27”, mas não fornece nomes no texto acessível. [3]

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/ad-ceuta-fc/plantilla)

## Albacete BP

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/albacete-bp/plantilla)

## Burgos CF

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/burgos/plantilla)

## Cádiz CF

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/cadiz-cf/plantilla)

## CD Castellón

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/cd-castellon/plantilla)

## CD Eldense

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/eldense/plantilla)

## CD Leganés

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/cd-leganes/plantilla)

## CD Tenerife

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/cd-tenerife/plantilla)

## CE Sabadell

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/ce-sabadell/plantilla)

## Celta Fortuna

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/rc-celta-b/plantilla)

## Córdoba CF

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/cordoba-cf/plantilla)

## FC Andorra

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/fc-andorra/plantilla)

## Girona FC

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/girona-fc/plantilla)

## Granada CF

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/granada-cf/plantilla)

## R. Sociedad B

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/r-sociedad-b/plantilla)

## RCD Mallorca

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/rcd-mallorca/plantilla)

## Real Oviedo

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/real-oviedo/plantilla)

## Real Sporting

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/real-sporting/plantilla)

## Real Valladolid CF

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/r-valladolid-cf/plantilla)

## SD Eibar

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/sd-eibar/plantilla)

## UD Almería

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/ud-almeria/plantilla)

## UD Las Palmas

**Jogadores nomeados verificáveis nesta coleta:** nenhum. A página de elenco oficial está vinculada à lista 2026/27, mas os nomes não foram recuperáveis no conteúdo acessível consultado.

Fonte: [elenco oficial LALIGA](https://www.laliga.com/clubes/ud-las-palmas/plantilla)

## Cobertura e limitações

A lista de 22 participantes foi coberta integralmente a partir da página oficial de clubes 2026/27. As 22 páginas oficiais de elenco correspondentes estão ligadas acima. O conteúdo textual consultável das fichas de elenco não apresentou nomes nesta coleta; apenas confirmei diretamente a identificação explícita 2026/27 na ficha do AD Ceuta. Portanto, não afirmo que os elencos estejam indisponíveis no site em navegador interativo, apenas que seus nomes não puderam ser verificados nas páginas acessíveis por extração textual. Nenhum nome de comissão técnica foi tratado como jogador e nenhum elenco de temporada anterior foi reutilizado.

## Referências

[1]: https://www.laliga.com/laliga-hypermotion/clubes "Clubes de LALIGA HYPERMOTION 2026/27"
[2]: https://www.laliga.com/en-GB/laliga-hypermotion/results "Resultados e 13ª rodada de LALIGA HYPERMOTION 2026/27"
[3]: https://www.laliga.com/clubes/ad-ceuta-fc/plantilla "Plantilla oficial del AD Ceuta FC 2026/27"
