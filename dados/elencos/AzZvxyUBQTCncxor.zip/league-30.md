# J2 League 2026/27: clubes e jogadores

**País:** Japão  
**Campeonato:** Meiji Yasuda J2 League  
**Divisão:** J2 (2ª divisão)  
**Temporada/status:** 2026/27, em andamento em 12 de novembro de 2026. O site oficial já exibe partidas e estatísticas da temporada.  
**Data de consulta:** 12 de novembro de 2026.

A J.League anunciou em 16 de julho de 2026 a publicação do guia de jogadores da temporada 2026/27, com páginas individuais por clube. Os nomes abaixo foram transcritos das páginas oficiais de elenco da J.League; são jogadores listados, não comissão técnica. As páginas podem ser atualizadas durante a janela/temporada, então esta relação é um retrato consultado na data indicada, não uma garantia de inscrições imutáveis. [1]

## Hokkaido Consadole Sapporo
Fonte do elenco: [https://www.jleague.jp/club/sapporo/player/](https://www.jleague.jp/club/sapporo/player/)

菅野 孝憲, 田川 知樹, 唯野 鶴眞, 高木 駿, 髙尾 瑠, パク ミンギュ, 中村 桐耶, 福森 晃斗, 内田 瑞己, 大﨑 玲央, 岡田 大和, キム ゴヌン, 川原 颯斗, 野瀬 翔也, 西野 奨太, 浦上 仁騎, 梅津 龍之介, スパチョーク, 宮澤 裕樹, 青木 亮太, 堀米 勇輝, 田中 克幸, 長谷川 竜也, 木戸 柊摩, ティラパット, 荒野 拓馬, 真田 蓮司, 堀米 悠斗, 木實 快斗, マリオ セルジオ, アマドゥ バカヨコ, キングロード サフォ, 大森 真吾, 唐山 翔自, 佐藤 陽成, ヴィニ ペイショット, 白井 陽斗, イッティモン

## Vanraure Hachinohe
Fonte do elenco: [https://www.jleague.jp/club/hachinohe/player/](https://www.jleague.jp/club/hachinohe/player/)

吉村 耕一, 大西 勝俉, 谷口 裕介, カウン ゼン マラ, 平松 航, 澤田 雄大, 雪江 悠人, 白井 陽貴, 佐々木 輝大, 保坂 善里, 鈴木 慎之介, 稲積 大介, 鵜木 郁哉, 佐藤 碧, 音泉 翔眞, 佐藤 祐太, 栗澤 陸, 高橋 耕平, 田中 翼冴, 猪狩 祐真, 高吉 正真, 永田 一真, 髙尾 流星, 澤上 竜二, 岡 健太, 井波 勇太, オウイエ ウイリアム, 新谷 聖基, 中野 誠也

## Vegalta Sendai
Fonte do elenco: [https://www.jleague.jp/club/sendai/player/](https://www.jleague.jp/club/sendai/player/)

堀田 大暉, 松澤 香輝, 林 彰洋, 髙橋 一平, 五十嵐 聖己, 奥山 政幸, 菅田 真啓, 工藤 珠凜, マテウス モラエス, 髙田 椋汰, 永井 大義, 石井 隼太, 井上 詩音, 韓 浩康, 湯谷 杏吏, 松井 蓮之, 武田 英寿, 鎌田 大夢, 相良 竜之介, 南 創太, 工藤 蒼生, 有田 恵人, 横山 颯大, 岩渕 弘人, 杉山 耀建, 尾川 丈, 浅倉 廉, 中島 元彦, 宮崎 鴻, 小林 心, 梅木 翼, 中田 有祐, 西丸 道人, 古屋 歩夢, 安野 匠, 荒木 駿太

## Blaublitz Akita
Fonte do elenco: [https://www.jleague.jp/club/akita/player/](https://www.jleague.jp/club/akita/player/)

山田 元気, 矢田貝 壮貴, ヒル 袈依廉, 堀内 智葵, 岡﨑 亮平, 飯泉 涼矢, 岡野 洵, 長井 一真, 才藤 龍治, 野々村 鷹人, 高橋 秀典, 長谷川 巧, 平瀬 大, 神田 篤輝, 寺門 純悠, 畑橋 拓輝, 水谷 拓磨, 中村 亮太, 大石 竜平, 吉岡 雅和, 藤山 智史, 岩井 琢朗, 川上 エドオジョン 智慧, 田中 純, 永澤 柊太, 土井 紅貴, 中野 嘉大, 梅田 魁人, 佐川 洸介, 半田 航也, 粟飯原 尚平, 鈴木 翔大

## Montedio Yamagata
Fonte do elenco: [https://www.jleague.jp/club/yamagata/player/](https://www.jleague.jp/club/yamagata/player/)

渋谷 飛翔, 長谷川 洸, 上林 大誠, 佐藤 瑠星, 佐藤 陸斗, イ ドンヒ, 熊本 雄太, 西村 慧祐, 杉井 颯, 山田 拓巳, 野嶽 寛也, 川井 歩, 城和 隼颯, 森岡 陸, 坂本 稀吏也, 本間 海翔, 中村 亮太朗, 土居 聖真, 氣田 亮真, 柳町 魁耀, 寺山 翼, 横山 塁, 吉尾 海夏, 田中 祉同, 國分 伸太郎, 榎本 啓吾, 竹ノ谷 優駕スベディ, 山本 将吾, 川名 連介, タリソン アウベス, 高橋 潤哉, ディサロ 燦シルヴァーノ, 森 海渡, 堀金 峻明

## Iwaki FC
Fonte do elenco: [https://www.jleague.jp/club/iwaki/player/](https://www.jleague.jp/club/iwaki/player/)

加藤 有輝, 松本 崚汰, 佐々木 雅士, ジュ ヒョンジン, 遠藤 凌, 牛澤 健, 桒田 大誠, 岩下 航, 中野 陽斗, 深港 壮一郎, 岡庭 愁人, 今野 息吹, 中島 舜, 柴田 壮介, 藤井 海和, 山口 大輝, 荒木 仁翔, チョン ソホ, 大氏 凜州, 高橋 勇利也, 山中 惇希, 久永 瑠音, 木吹 翔太, 永木 亮太, 松本 琉雅, 中山 竜之介, 道脇 豊, 西谷 亮, 加藤 大晟, 田中 幹大, 熊田 直紀, 伊師 虎ノ助

## Tochigi City
Fonte do elenco: [https://www.jleague.jp/club/tochigic/player/](https://www.jleague.jp/club/tochigic/player/)

原田 欽庸, 児玉 潤, 村田 智哉, キム ジンヒョン, マテイ ヨニッチ, 照山 颯人, 奥井 諒, 佐藤 喜生, 知念 哲矢, 鈴木 裕斗, 小西 慶太郎, シモンズ エイデン, 乾 貴哉, 升掛 友護, 加藤 丈, 森 俊貴, 岡庭 裕貴, 大嶌 貴, 加藤 大, ペドロ アウグスト, 山下 敬大, 鈴木 武蔵, バスケス バイロン, 吉田 篤志, 西谷 和希, 小池 裕太, 西村 朋倭, 田中 パウロ淳一, トクマック グェン, 平岡 将豪

## RB Omiya Ardija
Fonte do elenco: [https://www.jleague.jp/club/omiya/player/](https://www.jleague.jp/club/omiya/player/)

笠原 昂史, トム グローバー, 志村 滉, 新村 和史, 若林 学歩, 村上 陽介, 加藤 聖, ガブリエウ, イヨハ 理 ヘンリー, 尾崎 優成, 茂木 力也, 中澤 凜, 関口 凱心, 水谷 アルトゥール, 熊田 佳斗, 木寺 優直, 井芹 響輔, メンディー サイモン 友, 西尾 隆矢, 小島 幹敏, カウアン ディニース, 泉 柊椰, 中山 昂大, 加藤 玄, スファナット ムエアンタ, 日隠 ナシュ 大士, 古川 蒼真, 石川 匠, エドワード 真秀, 迫田 凌和, 小林 柚希, カルリーニョス ジュニオ, 豊川 雄太, カプリーニ, 山本 桜大, 日髙 元, 杉本 健勇, 兼頭 晴宗, 中島 大翔, マギー ジェラニー 蓮

## Yokohama FC
Fonte do elenco: [https://www.jleague.jp/club/yokohamafc/player/](https://www.jleague.jp/club/yokohamafc/player/)

市川 暉記, 原田 眞透, 西方 瑛太郎, 石井 僚, 山岸 克斗, 細井 響, 林 賢吾, 伊藤 槙人, 杉田 隼, 岩武 克弥, 秦 樹, 中村 琉聖, 新保 海鈴, 佃 颯太, 小倉 陽太, 山田 康太, 窪田 稜, 高塩 隼生, 島村 拓弥, 村田 透馬, 横山 暁之, 熊倉 弘貴, 宇田 光史朗, 清水 悠斗, 福岡 湧大, 渡辺 莉太, 髙江 麗央, 岩崎 亮佑, ルキアン, ジョアン パウロ, 前田 勘太朗, 千葉 寛汰, 齋藤 翔, 駒沢 直哉, アダイウトン

## Shonan Bellmare
Fonte do elenco: [https://www.jleague.jp/club/shonan/player/](https://www.jleague.jp/club/shonan/player/)

永井 建成, 真田 幸太, 岩瀬 陽, 上福元 直人, 松村 晟怜, 袴田 裕太郎, 舘 幸希, 大野 和成, 下口 稚葉, 髙橋 直也, 堂鼻 起暉, 保田 成琉, 松村 秀明, 松本 大弥, 武田 将平, 小野瀬 康介, アルトゥール シルバ, 田村 蒼生, 池田 昌生, 石橋 瀬凪, 奥埜 博亮, 深澤 佑太, 山口 豪太, 中村 龍, 鈴木 雄斗, 上月 壮一郎, 大下 蒼生, 加瀬 直輝, ファビアン ゴンザレス, 小田 裕太郎, 西野 太陽, 太田 修介, 渡邊 啓吾, 山田 寛人, 石井 久継

## Ventforet Kofu
Fonte do elenco: [https://www.jleague.jp/club/kofu/player/](https://www.jleague.jp/club/kofu/player/)

河田 晃兵, イ ミンギ, 山内 康太, 後藤 陽翔, 東 ジョン, 井上 樹, 野澤 陸, 山本 英臣, 一瀬 大寿, 福元 竣, 小出 悠太, 豊田 怜央, 川井 謙真, 福井 啓太, メンデス, 小林 岩魚, 荒木 翔, 安田 虎士朗, 熊倉 弘達, 村上 千歩, 米陀 大洋, 末木 裕也, 水野 颯太, 遠藤 光, 佐藤 恵介, 平塚 悠知, 佐藤 和弘, 武井 成豪, 岡島 悠元, 松山 北斗, 和田 拓也, 保坂 知希, 黒川 淳史, 三平 和司, 内藤 大和, 藤井 一志, スタチオーリ ミケーレ, 大島 康樹, 前澤 拓城

## Albirex Niigata
Fonte do elenco: [https://www.jleague.jp/club/niigata/player/](https://www.jleague.jp/club/niigata/player/)

吉満 大介, 松浦 大翔, 佐藤 空斗夢, バウマン, 内山 翔太, ジェイソン ゲリア, 加藤 徹也, 舞行龍ジェームズ, 早川 史哉, 森 璃太, 佐藤 海宏, 関口 正大, 松岡 敏也, 藤原 優大, 森 昂大, 舩木 翔, 笠井 佳祐, 大西 悠介, 白井 永地, ダニーロ ゴメス, 落合 陸, 古長谷 千博, シマブク カズヨシ, 星 雄次, 新井 泰貴, 石山 青空, 前田 椋介, イウリ カスティーリョ, 大澤 朋也, 若月 大和, 桑山 侃士, マテウス モラエス, 小野 裕二

## Kataller Toyama
Fonte do elenco: [https://www.jleague.jp/club/toyama/player/](https://www.jleague.jp/club/toyama/player/)

平尾 駿輝, 寺門 陸, コ ボンジョ, 原田 岳, 香川 勇気, 深澤 壯太, 今瀬 淳也, 實藤 友紀, 西矢 慎平, カン ミヌ, 荒木 将太朗, 竹内 豊, 岡本 將成, 瀬良 俊太, 亀田 歩夢, 松岡 大智, 谷本 駿介, 湯之前 匡央, チョン ウヨン, 椎名 伸志, 布施谷 翔, 溝口 駿, 髙橋 馨希, 竹中 元汰, 池田 春汰, 植田 啓太, 國武 勇斗, 香川 太朗, 吉平 翼, 松田 力, キム テウォン, 小川 慶治朗, 坪井 清志郎, 中島 裕希, 古川 真人

## Júbilo Iwata
Fonte do elenco: [https://www.jleague.jp/club/iwata/player/](https://www.jleague.jp/club/iwata/player/)

川島 永嗣, 牲川 歩見, 三浦 龍輝, 中島 佳太郎, ダニーロ, 松原 后, 江﨑 巧朗, 加藤 大育, 上夷 克典, 西久保 駿介, 桑原 航太, 山﨑 浩介, 甲斐 佑蒼, 吉村 瑠晟, 川﨑 一輝, 松田 和輝, 西野 陽向, 増田 大空, 金子 大毅, 上原 力也, 為田 大貴, 小原 基樹, ユーリ ララ, 西岡 健斗, 井上 潮音, 乾 貴士, 小池 直矢, イアゴ テレス, 川合 徳孟, 石塚 蓮歩, 相田 勇樹, 植村 洋斗, 奥田 悠真, 藤原 健介, 渡邉 りょう, マテウス ペイショット, 野澤 零温, 太田 龍之介, 佐藤 大樹, ジョアン ヴィクトル

## Fujieda MYFC
Fonte do elenco: [https://www.jleague.jp/club/fujieda/player/](https://www.jleague.jp/club/fujieda/player/)

田口 潤人, ジョーンズ レイ, 吉田 舜, 栗栖 汰志, 松田 佳大, 鈴木 翔太, 中川 創, 楠本 卓海, 岡本 拓也, 森 侑里, 近藤 優成, 久富 良輔, 大森 彗斗, 角田 惠風, 中村 優斗, 三木 仁太, 杉田 真彦, 梶川 諒太, 河本 大雅, 芹生 海翔, 島野 怜, 上畑 佑平士, 行友 祐翔, 長尾 優斗, 北原 槙, 青木 俊輔, 松木 駿之介, 菊井 悠介, 真鍋 隼虎, 川本 梨誉, 沼田 駿也, 金本 毅騎, 渡邉 幸汰

## Tokushima Vortis
Fonte do elenco: [https://www.jleague.jp/club/tokushima/player/](https://www.jleague.jp/club/tokushima/player/)

三井 大輝, 長谷川 徹, 北村 海 チディ, カン ヨンガン, 田中 隼人, 山田 奈央, カイケ, 青木 駿人, 山越 康平, 柳澤 亘, 西坂 斗和, 高木 友也, 山口 竜弥, モヨ マルコム強志, 鹿沼 直生, 児玉 駿斗, 岩尾 憲, 杉本 太郎, 稲見 哲行, 髙田 優, 髙田 颯也, 尾上 瑠聖, 伊藤 翼, 重廣 卓也, 福田 武玖, トニー アンデルソン, ルーカス バルセロス, 梶谷 政仁, 渡 大生, 宮崎 純真, ローレンス デイビッド

## FC Imabari
Fonte do elenco: [https://www.jleague.jp/club/imabari/player/](https://www.jleague.jp/club/imabari/player/)

立川 小太郎, 山本 透衣, 伊藤 元太, 山田 陽介, 高木和 徹, 梅木 怜, 孫 大河, 市原 亮太, 菊地 健太, イ ヨンジュン, 竹内 悠力, 萩原 慶, 丸山 大和, 白石 蓮, 菊池 季汐, 櫛引 一紀, 土屋 巧, ガブリエル ゴメス, 新井 光, 梶浦 勇輝, 山田 貴文, 森 晃太, 近藤 高虎, 駒井 善成, 持井 響太, 安部 裕葵, 佐藤 璃樹, アレクサンダル パロチェヴィッチ, 柴野 快仁, 久保 恵音, 馬越 晃, 加藤 潤也, 中井 卓大 ピピ, エジガル ジュニオ, ウェズレイ タンキ, 古山 兼悟

## Sagan Tosu
Fonte do elenco: [https://www.jleague.jp/club/tosu/player/](https://www.jleague.jp/club/tosu/player/)

泉森 涼太, 松原 颯汰, 藤嶋 栄介, エジケ 唯吹ヴィンセント, 神山 京右, 今津 佑太, 長澤 シヴァタファリ, 安藤 寿岐, 吉田 真那斗, 小川 大空, 森下 怜哉, 阿部 海大, 磯谷 駿, 松本 凪生, 櫻井 辰徳, 坂本 亘基, 楢原 慶輝, 城定 幹大, 堺屋 佳介, 西澤 健太, 玄 理吾, 中原 輝, 豊田 歩, 山内 翔, 水巻 時飛, 松岡 響祈, 芳野 凱斗, 伊澤 璃来, 髙橋 利樹, 鈴木 大馳, 塩浜 遼, 酒井 宣福, パク ホミン, 合戸 晴矢

## Oita Trinita
Fonte do elenco: [https://www.jleague.jp/club/oita/player/](https://www.jleague.jp/club/oita/player/)

田中 悠也, ムン キョンゴン, 古野 優斗, 川島 康暉, 小田 逸稀, 宮川 歩己, 三竿 雄斗, 松尾 勇佑, 戸根 一誓, ペレイラ, 坂田 陸, 井上 聖也, 森山 公弥, 中川 寛斗, 西村 恭史, 榊原 彗悟, 茂 平, パトリッキ ヴェロン, 林田 滉也, 吉川 敬進, 山崎 太新, 清武 弘嗣, 松岡 颯人, 後藤 響, 山口 卓己, 有馬 幸太郎, マテウス レイリア, 宇津元 伸弥, 木本 真翔, 木許 太賀, 有働 夢叶, 櫻井 勇斗, 古川 大悟, 相澤 デイビッド

## Tegevajaro Miyazaki
Fonte do elenco: [https://www.jleague.jp/club/miyazaki/player/](https://www.jleague.jp/club/miyazaki/player/)

茂木 秀, 徳若 碧都, 松山 健太, 木村 凌也, 長友 海翔, 安部 崇士, 元木 漣, 松本 雄真, 宮脇 茂夫, 眞鍋 旭輝, 黒木 謙吾, 下川 陽太, 田中 誠太郎, 渡邉 英祐, 大熊 健太, 阿野 真拓, 山内 陸, 井上 怜, 堤 奏一郎, 家坂 葉光, 田中 雄大, 河合 駿樹, 小西 宏登, 奥村 晃司, 坂井 駿也, 村越 凱光, 橋本 啓吾, 佐藤 遼, 小林 俊瑛, 松本 ケン チザンガ

## Observações de cobertura

Cobertura de páginas oficiais: 20/20 clubes consultados; elencos obtidos de páginas oficiais próprias da J.League. Cada seção aponta para a fonte específica. O guia de temporada funciona como índice oficial. A composição dos clubes está documentada no anúncio oficial de 19 de dezembro de 2025.

## Referências

[1]: https://www.jleague.jp/news/article/34439/ "J.League: guia oficial de jogadores 2026/27"  
[2]: https://www.jleague.jp/news/article/32852/ "J.League: composição dos clubes 2026/27"  
[3]: https://www.jleague.jp/j2/stats/ "J.League: estatísticas oficiais J2 2026/27"
