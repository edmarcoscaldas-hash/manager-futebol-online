# UAE Pro League 2026/27 — clubes e elencos verificáveis

- **País:** Emirados Árabes Unidos
- **Campeonato:** UAE Pro League (ADNOC Pro League)
- **Divisão:** 1ª divisão masculina
- **Temporada/status em 12 de novembro de 2026:** temporada 2026/27 em andamento. O site oficial apresenta a temporada 2026/2027 e seus jogos da ADNOC Pro League; a página inicial oficial anuncia a rodada 8 para 7–8 de novembro. Portanto, não se trata de temporada ainda não iniciada. [1] [2]
- **Cobertura dos jogadores:** a página oficial de cada clube expõe “Squad and Manager” e filtro de temporada 2026/2027, mas o conteúdo recuperável publicamente nesta consulta não apresenta os nomes da lista de jogadores (renderização dinâmica não incluída no texto extraído). Não usei elencos de 2025/26 como substituto e não atribuí nomes sem confirmação verificável. Assim, os clubes estão cobertos individualmente, mas não foi possível produzir uma lista nominal confiável de jogadores por elenco; “sem nomes confirmáveis nesta coleta” não significa elenco vazio. Comissão técnica não é tratada como jogadores. A relação de 14 participantes foi conferida em listagem específica de equipes de 2026/27; os links oficiais por clube abaixo servem como fontes primárias para o elenco da temporada. [3]

## Clubes e jogadores

### Ajman Club
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/ajman). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Al Ain FC
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/al-ain). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Al Dhafra
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/al-dhafra). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Al Jazira Club
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/al-jazira). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Al Nasr SC
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/al-nasr). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Al Wahda
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/al-wahda). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Al Wasl
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/al-wasl). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Baniyas SC
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/bani-yas). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Hatta Club
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/hatta). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Ittihad Kalba FC
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/kalba). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Khor Fakkan Club
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/khorfakkan). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Shabab Al Ahli Club
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/shabab-alahli). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### Sharjah FC
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/sharjah). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

### United FC
**Jogadores nomeados confirmáveis para 2026/27 nesta coleta:** nenhum. O conteúdo textual da página oficial não expôs a lista do elenco.

Fonte do elenco: [página oficial do clube — Squad, filtro 2026/2027](https://www.uaeproleague.ae/en/clubs/united). Participante na lista da temporada: [WorldFootball, equipes 2026/27](https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/).

## Referências

[1]: https://www.uaeproleague.ae/en/standings "UAE Pro League — classificação e seletor da temporada"
[2]: https://www.uaeproleague.ae/ "UAE Pro League — página inicial e notícias da temporada 2026/27"
[3]: https://www.worldfootball.net/competition/co1183/ua-emirates-uae-pro-league/teams/ "WorldFootball — equipes participantes 2026/2027"
[4]: https://www.uaeproleague.ae/en/fixtures "UAE Pro League — calendário e resultados da temporada 2026/2027"
