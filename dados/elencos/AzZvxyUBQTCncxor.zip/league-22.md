# Ligue 2 BKT — participantes e cobertura de elencos

**País:** França  
**Campeonato:** Ligue 2 BKT  
**Divisão:** segunda divisão masculina do futebol francês  
**Temporada:** 2026/27  
**Status em 12 de novembro de 2026:** temporada em andamento. O calendário oficial já mostra a 13ª rodada, programada de 20 a 23 de novembro de 2026; portanto, não se trata de temporada futura ou ainda não iniciada. [1]

## Cobertura e limitação

A lista abaixo reúne os 18 clubes apresentados no calendário oficial da LFP. A página oficial de classificação consultada não entregou nesta captura uma tabela navegável nem listas de plantel. A página de competição da Transfermarkt declara temporada 26/27, 18 equipes e 481 jogadores no total, e oferece links de plantel por clube; porém, a extração consultada não expôs nomes individuais de jogadores em todas as fichas. [2]

Por isso, este documento **não afirma cobrir os elencos completos**. A lista de jogadores nomeados neste arquivo é zero: não inseri nomes de temporadas anteriores, nem nomes encontrados apenas em resultados de busca sem validação de página de elenco correspondente a 2026/27. As ligações por clube abaixo apontam à ficha de plantel Transfermarkt identificada como temporada 2026/27, para consulta do elenco publicado nessa fonte. Não foram localizadas/confirmadas aqui páginas oficiais de elenco 2026/27 para os 18 clubes. Os links oficiais dos clubes são os publicados no site da LFP. [1] [2]

## Clubes participantes

### AS Saint-Étienne
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/as-saint-etienne/kader/verein/618/saison_id/2026).
- Site oficial do clube: [ASSE](https://www.asse.fr/).

### Stade de Reims
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/stade-reims/kader/verein/1421/saison_id/2026).
- Site oficial do clube: [Stade de Reims](https://www.stade-de-reims.com/).

### FC Nantes
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/fc-nantes/kader/verein/995/saison_id/2026).
- Site oficial do clube: [FC Nantes](https://www.fcnantes.com/).

### FC Metz
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/fc-metz/kader/verein/347/saison_id/2026).
- Site oficial do clube: [FC Metz](https://www.fcmetz.com/).

### Montpellier HSC
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/montpellier-hsc/kader/verein/969/saison_id/2026).
- Site oficial do clube: [Montpellier HSC](https://www.mhscfoot.com/).

### Clermont Foot 63
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/clermont-foot-63/kader/verein/3524/saison_id/2026).
- Site oficial do clube: [Clermont Foot](https://www.clermontfoot.com/).

### AS Nancy-Lorraine
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/as-nancy-lorraine/kader/verein/1159/saison_id/2026).
- Site oficial do clube: [AS Nancy-Lorraine](https://www.asnl.net/).

### Red Star FC
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/red-star-fc/kader/verein/1154/saison_id/2026).
- Site oficial do clube: [Red Star](https://www.redstar.fr/).

### Rodez Aveyron Football
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/rodez-af/kader/verein/11273/saison_id/2026).
- Site oficial do clube: [Rodez AF](https://rodezaveyronfootball.com/).

### USL Dunkerque
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/usl-dunkerque/kader/verein/9202/saison_id/2026).
- Site oficial do clube: [USL Dunkerque](https://www.usldunkerque.com/accueil/).

### Grenoble Foot 38
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/grenoble-foot-38/kader/verein/1290/saison_id/2026).
- Site oficial do clube: [Grenoble Foot 38](https://www.gf38.fr/).

### EA Guingamp
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/ea-guingamp/kader/verein/855/saison_id/2026).
- Site oficial do clube: [EA Guingamp](https://www.eaguingamp.com/).

### Pau FC
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/pau-fc/kader/verein/3166/saison_id/2026).
- Site oficial do clube: [Pau FC](https://paufc.fr/).

### Stade Lavallois
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/stade-lavallois/kader/verein/1080/saison_id/2026).
- Site oficial do clube: [Stade Lavallois](https://www.stade-lavallois.com/).

### FC Sochaux-Montbéliard
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/fc-sochaux-montbeliard/kader/verein/750/saison_id/2026).
- Site oficial do clube: [FC Sochaux-Montbéliard](https://www.fcsochaux.fr/).

### FC Annecy
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/fc-annecy/kader/verein/30204/saison_id/2026).
- Site oficial do clube: [FC Annecy](https://www.fc-annecy.fr/).

### US Boulogne
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/us-boulogne/kader/verein/7042/saison_id/2026).
- Site oficial do clube: [US Boulogne](https://www.usbco.com/).

### Dijon FCO
- Jogadores nomeados verificados neste levantamento: nenhum.
- Elenco 2026/27 (fonte secundária): [Transfermarkt](https://www.transfermarkt.us/dijon-fco/kader/verein/2969/saison_id/2026).
- Site oficial do clube: [Dijon FCO](https://www.dfco.fr/).

## Fontes principais

[1] [Calendário oficial Ligue 2 BKT — LFP](https://ligue1.com/en/calendar/ligue2). Página oficial da competição; na captura consultada apresenta jogos da rodada 13 em 20–23 de novembro e lista os clubes nas partidas.

[2] [Ligue 2 26/27 — Transfermarkt](https://www.transfermarkt.us/ligue-2/startseite/wettbewerb/FR2). Fonte secundária consultada para verificar que as páginas de elenco estão associadas à temporada 26/27 e que a página declara 18 clubes.

[3] [Classificação oficial Ligue 2 BKT — LFP](https://ligue1.com/en/competitions/ligue2bkt/standings). Página oficial consultada; a captura não exibiu classificação utilizável.
