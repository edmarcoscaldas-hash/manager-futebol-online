# Brasil — NBB CAIXA (Liga Nacional de Basquete), 1ª divisão

**Temporada:** 2026/27. **Status em 12 de novembro de 2026:** temporada iniciada; a Liga Nacional de Basquete (LNB) anunciou 17 de outubro como início e seu site já registra jogos da temporada em outubro e novembro. Não é uma temporada futura nem uma lista herdada automaticamente do ano anterior. [1] [2]

## Cobertura e limite de verificação

A LNB confirmou oficialmente os 18 participantes. A fonte oficial de equipe localizada não expõe elenco completo legível na página consultada. Para não apresentar nomes não verificados nem tratar uma notícia seletiva como roster completo, abaixo constam apenas jogadores que a própria LNB nomeou explicitamente como atletas da temporada 2026/27 em matéria publicada em 28 de outubro de 2026. Os nomes são parciais e não representam o elenco integral de cada clube. A matéria informa ainda três contratações ainda não inscritas naquela data; não as conto como atletas inscritos. Portanto, o pedido de todos os jogadores reais por elenco não pode ser completado com segurança usando as fontes públicas consultadas. [2] [3]

## Clubes e jogadores nomeados em fonte da temporada

### Basquete Cearense (CE)
- Michael Dupree.
- Viont’e Daniels foi descrito como contratado, mas ainda não inscrito na competição na data da matéria; não incluído na lista de atletas inscritos. [3]

### Bauru Basket (SP)
- Anthony Harris
- Corderro Bennett
- Fermin Thygesen
- Franco Vieta [3]

### Botafogo (RJ)
- Isaac Thornton
- Alexander Mudronja [3]

### CAIXA/Brasília (DF)
- Jeantal Cylla
- Kevin Crescenzi
- Martín Fernández
- Lathaniel Bastian [3]

### Caxias do Sul Basquete (RS)
- Mateo Bolivar [3]

### Corinthians (SP)
- A matéria da LNB declara que o clube era o único participante sem atleta estrangeiro no elenco; não relaciona nominalmente seus jogadores. Nenhum nome é reproduzido aqui por falta de roster nominal nessa fonte. [3]

### Cruzeiro Basquete (MG)
- Dominique Coleman [3]

### Flamengo (RJ)
- Franco Baralle
- Alex Negrete
- Luis Montero
- Sam Freeman foi descrito como contratado, mas ainda não inscrito na data da matéria; não incluído como atleta inscrito. [3]

### Sesi Franca (SP)
- David Jackson
- Luciano Parodi [3]

### Minas Tênis Clube (MG)
- Elyjah Clark
- Jeremy Hollowell
- Santi Scala
- Luis Santos [3]

### Mogi Basquete (SP)
- Dontrell Brite [3]

### Basket Osasco (SP)
- Brit Harris foi descrito como contratado, mas ainda não inscrito na data da matéria; não incluído como atleta inscrito. [3]

### Pato Basquete (PR)
- Grantham Gillard
- Franck Kamgain [3]

### Paulistano (SP)
- Edson Tovar [3]

### Pinheiros (SP)
- Brandon Weatherspoon
- David Nesbitt
- Domnick Bridgewater [3]

### São José Basketball (SP)
- Tradavis Thompson
- Emmanuel Payton [3]

### Ceisc/União Corinthians (RS)
- Enzo Ruiz
- Henrique Struecker
- Juan Cardenas [3]

### Unifacisa (PB)
- Charles Hinkle
- Elijah Weaver
- Diego Figueredo [3]

## Observações

A fonte oficial da LNB confirma os 18 clubes e o formato da temporada. A segunda matéria é uma listagem de atletas nascidos fora do Brasil, não uma página de elenco; os jogadores brasileiros dos clubes não listados individualmente não podem ser inferidos a partir dela. A cobertura nominal acima é, portanto, explicitamente parcial e conservadora. Nomes de clubes seguem a denominação usada pela LNB na relação oficial de participantes. [1] [3]

## Referências

[1]: https://lnb.com.br/noticias/lnb-define-participantes-e-formato-da-temporada-2026-27-do-nbb-caixa/ "LNB define participantes e formato da temporada 2026-27 do NBB CAIXA"
[2]: https://lnb.com.br/ "Portal oficial da Liga Nacional de Basquete, com registros de jogos do NBB 2026/2027"
[3]: https://lnb.com.br/noticias/nbb-caixa-2026-27-reune-atletas-de-dez-paises-conheca-o-mapa-internacional-da-temporada/ "NBB CAIXA 2026/27 reúne atletas de dez países"
