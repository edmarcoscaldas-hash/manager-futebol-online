# La Liga (1ª divisão), Espanha — temporada 2026/27

- **País:** Espanha
- **Campeonato:** LALIGA EA SPORTS (Primera División / La Liga)
- **Divisão:** primeira divisão masculina
- **Temporada e status em 12 de novembro de 2026:** **em andamento**. A classificação oficial da LaLiga identifica a temporada 2026/27, está na jornada 13 e registra partidas disputadas. [Classificação oficial](https://www.laliga.com/en-GB/laliga-easports/standing)
- **Participantes:** 20 clubes, conforme a página oficial da competição para 2026/27. [Lista oficial de clubes](https://www.laliga.com/en-GB/laliga-easports/clubs)

## Nota sobre cobertura dos elencos

Foram consultadas as páginas oficiais de elenco da LaLiga para os 20 participantes, todas rotuladas como 2026/27. A extração pública acessível nesta consulta exibe o título de elenco oficial, mas omite a lista de jogadores na maioria das páginas. Para não transportar nomes da temporada anterior nem completar lacunas por inferência, este documento só registra nomes que puderam ser verificados nos trechos públicos atuais das páginas oficiais; esses trechos são parciais e **não constituem elencos completos**. Quando nenhum nome pôde ser confirmado na extração, isso é indicado expressamente. Comissão técnica não foi incluída.

## Athletic Club

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Athletic Club](https://www.laliga.com/en-GB/clubs/athletic-club/squad)

## Atlético de Madrid

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Atlético de Madrid](https://www.laliga.com/en-GB/clubs/atletico-de-madrid/squad)

## CA Osasuna

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — CA Osasuna](https://www.laliga.com/en-GB/clubs/c-a-osasuna/squad)

## Celta

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Celta](https://www.laliga.com/en-GB/clubs/rc-celta/squad)

## Deportivo Alavés

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Deportivo Alavés](https://www.laliga.com/en-GB/clubs/d-alaves/squad)

## Elche CF

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Elche CF](https://www.laliga.com/en-GB/clubs/elche-c-f/squad)

## FC Barcelona

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — FC Barcelona](https://www.laliga.com/en-GB/clubs/fc-barcelona/squad)

## Getafe CF

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Getafe CF](https://www.laliga.com/en-GB/clubs/getafe-cf/squad)

## Levante UD

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Levante UD](https://www.laliga.com/en-GB/clubs/levante-ud/squad)

## Málaga CF

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Málaga CF](https://www.laliga.com/en-GB/clubs/malaga-cf/squad)

## R. Racing Club

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — R. Racing Club](https://www.laliga.com/en-GB/clubs/r-racing-club/squad)

## Rayo Vallecano

**Jogadores verificáveis no trecho público do elenco:** Cárdenas; A. Batalla; Emil Audero; Adrián Molina (goleiros). Estes são apenas os nomes expostos no trecho recuperado, não uma lista completa do plantel.

**Fonte do elenco 2026/27:** [LaLiga — Rayo Vallecano](https://www.laliga.com/en-GB/clubs/rayo-vallecano/squad)

## RC Deportivo

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — RC Deportivo](https://www.laliga.com/en-GB/clubs/rc-deportivo/squad)

## RCD Espanyol de Barcelona

**Jogadores verificáveis no trecho público do elenco:** Àngel Fortuño; Dmitrovic; Llorenç (goleiros no trecho, cujo restante foi truncado). Estes são apenas os nomes expostos, não uma lista completa do plantel.

**Fonte do elenco 2026/27:** [LaLiga — RCD Espanyol](https://www.laliga.com/en-GB/clubs/rcd-espanyol/squad)

## Real Betis

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Real Betis](https://www.laliga.com/en-GB/clubs/real-betis/squad)

## Real Madrid

**Jogadores verificáveis no trecho público do elenco:** Courtois; Lunin; Mestre; Javi Navarro; Illia Voloshyn (goleiros). Estes são apenas os nomes expostos no trecho recuperado, não uma lista completa do plantel.

**Fonte do elenco 2026/27:** [LaLiga — Real Madrid](https://www.laliga.com/en-GB/clubs/real-madrid/squad)

## Real Sociedad

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Real Sociedad](https://www.laliga.com/en-GB/clubs/real-sociedad/squad)

## Sevilla FC

**Jogadores verificáveis no trecho público do elenco:** Iglesias; Julio Díaz; Kike Salas; A. Castrin; Sangante (defensores no trecho, truncado). Estes são apenas os nomes expostos, não uma lista completa do plantel.

**Fonte do elenco 2026/27:** [LaLiga — Sevilla FC](https://www.laliga.com/en-GB/clubs/sevilla-fc/squad)

## Valencia CF

**Jogadores verificados nesta consulta:** nenhum nome individual exposto na versão pública acessível da página consultada; não é possível atestar a lista completa.

**Fonte do elenco 2026/27:** [LaLiga — Valencia CF](https://www.laliga.com/en-GB/clubs/valencia-cf/squad)

## Villarreal CF

**Jogadores verificáveis no trecho público do elenco:** Costa; Freeman; Pau Navarro; Foyth; Renato Veiga (defensores no trecho, truncado). Estes são apenas os nomes expostos, não uma lista completa do plantel.

**Fonte do elenco 2026/27:** [LaLiga — Villarreal CF](https://www.laliga.com/en-GB/clubs/villarreal-cf/squad)

## Referências gerais

- [LaLiga — clubes participantes, temporada 2026/27](https://www.laliga.com/en-GB/laliga-easports/clubs)
- [LaLiga — classificação oficial 2026/27](https://www.laliga.com/en-GB/laliga-easports/standing)
