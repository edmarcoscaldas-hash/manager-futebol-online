# Primera Nacional da Argentina — participantes e elencos

**País:** Argentina  
**Campeonato:** Primera Nacional  
**Divisão:** segunda categoria do futebol argentino  
**Temporada solicitada:** 2026/27  
**Status objetivo em 12 nov. 2026:** a temporada em andamento é denominada oficialmente **Primera Nacional 2026**, não 2026/27. A AFA publicou o fixture de 2026 e a ESPN confirma que o campeonato começou em 13 de fevereiro e se estende até dezembro. Portanto, não há base para tratar a atual competição como um ciclo 2026/27 separado. [1] [2]

## Cobertura e critério

O fixture da AFA confirma 36 participantes na Primera Nacional 2026. A lista abaixo reproduz esses clubes, não uma lista inferida de temporada anterior. [1] [2]

Não foi possível verificar publicamente, em páginas oficiais individuais de elenco, uma relação completa e nominal dos jogadores atuais de todos os 36 clubes com confirmação suficiente de que cada nome pertence ao plantel vigente em 12 nov. 2026. A página da Transfermarkt consultada identifica 2026 e agrega 1.022 jogadores, mas a listagem geral, por si só, não permite certificar neste relatório cada vínculo e a atualidade de cada elenco. Por isso, não foram incluídos nomes não confirmados; a ausência de nomes abaixo significa **cobertura nominal não verificada**, e não que o clube não tenha jogadores divulgados. A temporada anterior não foi usada para preencher lacunas. [3]

## Clubes participantes

### Acassuso
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Agropecuario Argentino
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### All Boys
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Almagro
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Almirante Brown
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Atlanta
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Atlético de Rafaela
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Central Norte (Salta)
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Chacarita Juniors
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Chaco For Ever
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Ciudad de Bolívar
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Colegiales
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Colón
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Defensores de Belgrano
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Deportivo Madryn
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Deportivo Maipú
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Deportivo Morón
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Estudiantes de Buenos Aires
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Ferro Carril Oeste
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Ferrocarril Midland
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Gimnasia y Esgrima de Jujuy
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Gimnasia y Tiro de Salta
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Godoy Cruz
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Güemes (Santiago del Estero)
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Los Andes
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Mitre (Santiago del Estero)
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Nueva Chicago
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Patronato
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Quilmes
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Racing de Córdoba
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### San Martín de San Juan
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### San Martín de Tucumán
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### San Miguel
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### San Telmo
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Temperley
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

### Tristán Suárez
Participante confirmado no fixture 2026 da AFA. **Jogadores:** não listados — elenco atual não verificado nominalmente em fonte oficial acessível. [1]

## Referências

[1]: https://www.afa.com.ar/sitio/posts/primera-nacional-fixture-para-la-temporada-2026 "AFA — Primera Nacional: fixture para la temporada 2026"
[2]: https://espndeportes.espn.com/futbol/argentina/nota/_/id/16309932/primera-nacional-2026-fixture-fecha-hora-resultados-formato-torneo-b-nacional "ESPN Deportes — Primera Nacional 2026: fixture, datas e resultados"
[3]: https://www.transfermarkt.com.ar/primera-nacional/startseite/wettbewerb/ARG2 "Transfermarkt — visão geral Primera Nacional 2026 e elencos"
