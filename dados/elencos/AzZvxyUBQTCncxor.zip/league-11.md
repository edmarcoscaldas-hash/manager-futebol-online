# Elencos da segunda divisão da Liga Nacional de Futsal — verificação em 12 de novembro de 2026

**País:** Brasil  
**Campeonato:** Liga Nacional de Futsal (LNF), divisão Silver Cresol  
**Divisão:** Segunda divisão / acesso (Silver)  
**Temporada solicitada:** 2026/27  
**Status objetivo:** Não foi localizada uma temporada oficial denominada 2026/27. A Silver foi lançada como competição de temporada anual de 2026; a cobertura oficial consultada em 12 de novembro de 2026 ainda identifica jogos e semifinais como LNF Silver 2026. A notícia da época da criação dizia que o acesso à divisão Gold seria para 2027, não que haveria uma temporada 2026/27. Portanto, elenco de 2026/27 não pode ser confirmado nem reconstruído a partir dos plantéis de 2026.

## Clubes e jogadores

A classificação oficial da LNF Silver consultada no portal da Liga apresenta 16 equipes participantes da edição 2026. Essa lista serve apenas para identificar os clubes da edição anual de 2026, não como lista confirmada de participantes de uma temporada 2026/27. [1] A lista é compatível com a cobertura contemporânea da abertura da competição. [2]

### ACEL (Chopinzinho)

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas.  
**Referência apenas de 2026:** em dezembro de 2025, a LNF publicou elenco anunciado para a temporada 2026: Tomaz Gilberto Ferreira de Farias (Hulk), Willian Berto Pereira Filho, Matheus Gonzalez, Wenderson da Silva Ferrer (Ceará), Marcos Vinícios (Vinisin), Emerson da Rocha Alves, Douglas Rotel Cappa, Breno Felipe Queiroz, Enzo Gimenes Cosialls, João Sabino de Matos Neto, Paulo Sérgio de Souza Pedroso (São Pedro), Everton dos Santos Quirino, Thales Feitosa, Lucas Ian Lobato Monteiro (Lucão), Sérgio Jamur de Souza (Jamur), Ian Barros da Silva, Suelton Marques de Souza, Edison Machado Coelho (Neguinho), Kelven Garcia Rossini e Uelenilson Soares Brito (Elenilson). Trata-se de plantel anunciado para 2026, não evidência para 2026/27. [3]

### América-RN

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas.  
**Referência apenas de 2026:** o anúncio oficial de 2026 nomeou Anderson Rapadura, Arthur, Davi, Café, Caíque, Rogério, Felipe Patu, Bruno, Cimar, Clayton, Dedê, Lenon, Richardson, Rickelb, Betinho e Pedro Pivô. Não se atribui essa lista à temporada 2026/27. [4]

### Apodi Futsal

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. Não foi identificado elenco de 2026/27 em fonte oficial consultada.

### Balsas Futsal

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas.  
**Referência apenas de 2026:** notícia da LNF/ge publicada em março de 2026 identifica renovações de Danilo, Rodriguinho, Leandrinho, Seba e Elvis e contratações de Renan Piauí, Batatinha, Domar e Carlos Recife. É uma relação parcial de movimentações na montagem do elenco, não um plantel completo nem informação sobre 2026/27. [5]

### Blumenau Futsal

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. Não foi identificado elenco de 2026/27 em fonte oficial consultada.

### Camaquã / Vélez Camaquã

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas.  
**Referência apenas de 2026:** cobertura contemporânea reportou renovações de Xitão, PH, Foguinho, Falcão, Pedro, Betinho, Bruninho Loko e Otávio, e chegadas de Genaro, Vincenzo, Guilherme Bandeira, Obina, Salah e Henrique. Trata-se de informação de elenco para a temporada de 2026, não transferível automaticamente para 2026/27. [2]

### Concórdia (ACF)

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. Não foi identificado elenco de 2026/27 em fonte oficial consultada.

### Dracena Futsal

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. Não foi identificado elenco de 2026/27 em fonte oficial consultada.

### Joaçaba Futsal

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. Não foi identificado elenco de 2026/27 em fonte oficial consultada.

### Juventude (Dourados/MS)

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. Não foi identificado elenco de 2026/27 em fonte oficial consultada.

### Lages Futsal

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. Não foi identificado elenco de 2026/27 em fonte oficial consultada.

### São Caetano

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. O portal da Liga mantém página de equipe com área de elenco para a competição, mas a informação acessível nesta pesquisa não confirmou uma relação nominal válida para 2026/27. [6]

### São Lourenço Futsal

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas.  
**Referência apenas de 2026:** o anúncio oficial da Liga para a temporada 2026 lista os goleiros Serjão, Carlos, Felipe dos Santos Von Mühlen e Saraiva; fixos Pirulito, Tiago e Thauan; alas Claudinho, Ian Lucas, Vico, Nathan Barbosa Varandas (Neytan), Gabriel Rosa, Léo Victor Peretti Nunes, Pedro Henrique Rezende Marcolla (Pedrinho) e Marcos Vinícius Agustinho Pedro (Pneu); pivôs Marco, Gesse e Matheus Sampaio Nunes. Comissão técnica omitida. A fonte declara expressamente temporada 2026, não 2026/27. [7]

### São Miguel Futsal

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. A notícia oficial localizada sobre 2026 apenas descreve elenco renovado e jovem, sem relação nominal completa; não sustenta uma lista de jogadores para 2026/27. [8]

### Sport Recife

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. Não foi identificado elenco nominal de 2026/27 em fonte oficial consultada.

### Vasco da Gama

**Elenco 2026/27:** não divulgado/verificável nas fontes consultadas. Não foi identificado elenco nominal de 2026/27 em fonte oficial consultada.

## Observações de cobertura

A pesquisa foi limitada à Liga Nacional de Futsal brasileira e à sua divisão Silver. Foram consultados o portal e as páginas/notícias oficiais da LNF, além de cobertura contemporânea para confirmar a edição e completar referências pontuais. A fonte oficial estabelece que a competição em curso é a **LNF Silver 2026**; portanto, não há base para apresentar os elencos acima como de uma temporada 2026/27. A relação nominal nesta página limita-se a anúncios especificamente identificados como de 2026 e está assinalada como tal. Para os demais clubes, e para todos os clubes no recorte temporal solicitado, a lista de jogadores permanece sem confirmação pública verificável nesta pesquisa. Não foram incluídos treinadores ou integrantes da comissão técnica como jogadores.

## Referências

[1]: https://lnfoficial.com.br/ "Portal oficial da Liga Nacional de Futsal — classificação LNF Silver 2026"
[2]: https://gauchazh.clicrbs.com.br/esportes/futsal/noticia/2026/04/segunda-divisao-da-liga-futsal-comeca-com-16-equipes-cmnhjrv8y01i2013mn6bvj66p.html "GZH — Segunda divisão da Liga Nacional de Futsal começa em abril de 2026"
[3]: https://lnfoficial.com.br/noticias/acel-chopinzinho-anuncia-elenco-e-competicoes-para-a-temporada-2026/ "LNF — ACEL-Chopinzinho anuncia elenco para a temporada 2026"
[4]: https://lnfoficial.com.br/noticias/america-aposta-alto-no-futsal-e-apresenta-elenco-com-ambicao-de-titulos-em-2026/ "LNF — América apresenta elenco para 2026"
[5]: https://lnfoficial.com.br/noticias/tabela-da-lnf-silver-e-divulgada-confira-os-jogos-do-balsas/ "LNF — Balsas: movimentações do elenco e tabela da LNF Silver 2026"
[6]: https://lnfoficial.com.br/equipes/sao-caetano/ "LNF — página de equipe do São Caetano"
[7]: https://lnfoficial.com.br/noticias/sao-lourenco-apresenta-elenco-e-comissao-tecnica-para-a-temporada-2026/ "LNF — São Lourenço apresenta elenco para 2026"
[8]: https://lnfoficial.com.br/noticias/sao-miguel-futsal-intensifica-preparacao-para-estreia-na-lnf-silver/ "LNF — São Miguel prepara estreia na LNF Silver"
[9]: https://www.cnnbrasil.com.br/esportes/outros-esportes/liga-nacional-de-futsal-anuncia-clubes-para-estreia-da-divisao-silver/ "CNN Brasil — anúncio da LNF Silver e acesso à Gold em 2027"
