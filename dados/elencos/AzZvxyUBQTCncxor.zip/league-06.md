# Saudi First Division League — 2026/27

- **País:** Arábia Saudita
- **Campeonato:** Saudi First Division League (Yelo League)
- **Divisão:** segunda divisão
- **Temporada/status em 12 de novembro de 2026:** a temporada está em andamento. A página Transfermarkt da competição seleciona expressamente 26/27 e lista 18 clubes; suas páginas individuais mostram posições na liga. Portanto, não se trata de uma temporada ainda por começar. A página oficial SAFF consultada contém seletor 2026–2027, mas o conteúdo extraído exibe jogos e classificação de 2021/22 e não valida roster atual.
- **Critério de nomes:** abaixo estão os jogadores reais que puderam ser lidos nos extratos consultados das páginas de elenco 26/27. A extração de várias páginas foi truncada pelo limite de leitura, de modo que as listas são **parciais**, não um registro completo de cada plantel. Não se inferem nomes ausentes nem se importam jogadores da temporada anterior. Comissão técnica não incluída.

## Participantes e jogadores identificados

### Al-Ula FC
**Jogadores identificados:** Abdulquddus Atiah; Ahmed Al-Jubaya; Faris Afandy; Yoann Barbet; Ammar Al-Dohaim; Yousef Haqawi; Abdulrahman Al-Obaid; Yasser Yaqoub; André Horta; Mohammed Al-Majhad; Damyan Yordanov; Abdulmajeed Al-Sulayhim; Bader Al-Omair; Abdulaziz Al-Hatila; Zaid Al-Anazi; Michael; Sumayhan Al-Nabit; Ayman Al-Khulaif; Fahad Al-Jumaiya; Sylla Sow; Romell Quioto; Abdulfattah Adam; Aseel Abdulrazaq.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-ula-fc/kader/verein/107818/saison_id/2026) (extrato parcial; a página indica elenco de 23 e temporada 26/27).

### Damac FC
**Jogadores identificados:** Moataz Al-Baqaawi; Ahmed Al-Rashidi; Naser Al-Ghamdi; Ali Al-Shaqiqi; Abdelkader Bedrane; Hassan Rabei; Noor Al-Rashidi; Abdullah Al-Yousif; Sanousi Al-Hawsawi; Yahya Sunbul; Jawad Al-Hassan; Riyadh Yami; Osama Al-Khalaf; Ahmed Namazi; Ahmed Omar; Morlaye Sylla; Issam Al-Qarni; Naif Al-Ghamdi; Khalid Hazazi.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/damac-fc/kader/verein/50532/saison_id/2026) (extrato parcial; a página indica elenco de 26 e temporada 26/27).

### Al-Najma SC
**Jogadores identificados:** Bader Al-Khamali; Salim Gabous; Belal Al-Dawaa; Diogo Queirós; Mubarak Al-Rajeh; Khalid Al-Shuwayyi; Khaled Al-Shammari; Mohammed Al-Kunaydiri; Khaled Al-Khathlan; Rayan Al-Ghamdi; Nabil Dunga; Afonso Taira; Eyad Madani; João Novais; Mohammed Suhluli; Jathub Al-Dhafieri; Abdulelah Al-Shammari.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-najma-sc/kader/verein/32328/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Wehda FC
**Jogadores identificados:** Jassim Al-Ashban; Abdullah Al-Oaisher; Abdulrahman Al-Shammari; Bander Whaeshi; Ali Al-Salem; Husein Al-Shuwaish; Rawaf Al-Maqadi; Reda Abdullah; Ahmed Al-Omaisi; Yahya Khurmi; Saad Al-Qahtani; Adil Khadhari; Waleed Saber; Dino Halilovic; Ahmed Al-Jaweed; Salem Al-Maqadi; Muralha; Fahad Al-Taleb; Mohammed Al-Qunayan.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-wehda-fc/kader/verein/17209/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Raed SFC
**Jogadores identificados:** Mohamed Al-Otaibi; Raed Ozaybi; Feras Al-Rajhi; Abdulrahman Sahhari; Redouane Mennioui; Mohammed Dakhilallah Al-Dawsari; Bandar Al-Shamrani; Ziyad Al-Refaei; Munif Doshy; Bader Al-Shardi; Hassan Al-Asmari; Tamim Al-Shuqayran; Claude Gnolou; Solomon Tweh; Yousef Al-Harbi; Omar Shami; Mohamed Al-Sufyani.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-raed-sfc/kader/verein/22381/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Zulfi SFC
**Jogadores identificados:** Saad Al-Saleh; Aqbah Al-Mushawh; Muhannad Al-Shehri; Saud Al-Tumbukti; Suwailem Al-Manhali; Ali Abu Shaheen; Ali Abdulhadi Al-Nakhli; Abdulrahman Al-Hajri; Bader Fallatah; Ali Daqarshawi; Ricardo Ryller; Ahmed Al-Anzy; Mohammed Baker; Abdulaziz Al-Shereid; Maher Al-Mutairi; Motair Al-Zahrani; Dejvi Bregu; Mohannad Semreen; Demba Diallo; Majed Madani; Al-Waleed Zayed.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-zulfi-sfc/kader/verein/85118/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Tai FC
**Jogadores identificados:** Saleh Al-Ohaymid; Mohammed Al-Dhulayfai; Amar Al-Amar; Mateo Les; Mohammed Al-Mutair; Nawaf Al-Zaaqi; Hussein Fraij; Abdulkarim Sultan; Muhannad Al-Harthi; Abdulaziz Al-Alawi; Abdullah Ibrahim Al-Dossary; Nawaf Al-Qamiri; Saud Al-Bawardi; Eduardo Henrique; Hasan Al-Habib; Nabil Alioui; Hamad Salem Al-Shammari; Khalid Majrashi.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-tai-fc/kader/verein/40079/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Jabalain FC
**Jogadores identificados:** Mohammed Al-Waked; Abdulrahman Al-Ghubaini; Naif Al-Hussaini; Ibrahim Al-Nakhli; Fahad Al-Harbi; Ghassan Hawsawi; Abdulelah Al-Bukhari; Nawaf Al-Mutairi; Hussain Al-Nuweqi; Ahmed Al-Muhaimeed; Zaid Salem Al-Shammari; Ibrahim Al-Nakhli; Yannick Semedo; Hassan Al-Majhad; Abdulmalik Al-Marwani; Carlos Daniel; Ênio; Rasheed Akanbi; Khaled Sattam Al-Shammari; Sattam Al-Roqi.

**Nota:** a fonte lista dois registros chamados Ibrahim Al-Nakhli, com perfis distintos; ambos foram mantidos como aparecem, sem tentar deduplicar.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-jabalain-fc/kader/verein/68028/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Okhdood Club
**Jogadores identificados:** Rakan Al-Najjar; Ali Al-Ameri; Saad Al-Qarni; Alex; Hassan Al-Harbi; Saif Balhareth; Mohammed Al-Hassaniyah; Faisal Al-Hadri; Ali Al-Makrami; Nawaf Al-Hawsawi; Yousef Al-Zaraia; Mohammed Abu Abd; Ibrahim Ashi; Abdullah Hazazi; Nasser Al-Bishi; Ahmed Al-Daghrir; Rui Pedro; Mohammed Al-Jahif; Saud Salem.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-okhdood-club/kader/verein/71665/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Orobah FC
**Jogadores identificados:** Hatem Al-Juhani; Rafi Al-Ruwaili; Saud Al-Ruwaili; Paulo Vitor; Ziyad Al-Hunaiti; Rabie Hawsawi; Raed Faraj; Hamed Al-Maqati; Ali Al-Sultan; Loay Al-Shahrani; Ammar Al-Harfi; Khaled Zakaria; Abdulaziz Al-Harabi; Fahad Al-Rashidi; Mohammed Krishan; Farraj Al-Rasheed; Qassem Al-Hussain; Mohammed Al-Mohaini; Rayan Al-Hazmi; Abdellah Zoubir.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-orobah-fc/kader/verein/39536/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Jeddah SC
**Jogadores identificados:** Fares Al-Johani; Yasser Al-Mosailem; Naif Asiri; Faisal Othman; Fahad Al-Sahafi; Mohammed Naji; Ahmed Al-Shamrani; Hassan Al-Jubairi; Carlos Jiménez; Abdulrahman Al-Rio; Rayan Fallatah; Awadh Al-Eissa; Mohammed Zamzami; Medwin Biteghé; Alhussain Bin Mahfouz; Ahmed Maher Adam; Martin Sroler; Mohammed Al-Dhafiri; Rafi Matmi; Hazzaa Al-Ghamdi.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/jeddah-sc/kader/verein/58858/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Anwar Club
**Jogadores identificados:** Khaled Shrahili; Nawaf Al-Dous; Fawaz Rabie; Chamseddine Derradji; Mohammed Abdulwahab Al-Zahrani; Fahad Al-Muneef; Rashid Al-Mutairi; Mohammed Al-Ghamdi; Abdullah Mansour Al-Rashidi; Majed Sharrahi; Abdullah Al-Samti; Mohammed Al-Hazmi; Kack Gabriel; Ahmed Bahusayn; Rashed Al-Salem; Anas Al-Qahtani; Rédha Bensayah; Sime Grzan; Khalid Kaabi; Mohammed Al-Harthi.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-anwar-club/kader/verein/75312/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Jandal SC
**Jogadores identificados:** Abdulrahman Hadl Al-Shammari; Mohammad Al-Bariah; Hashim Al-Saedi; Thibaut Peyre; Jamaan Al-Dosari; Mishal Haddad; Mansour Al-Shammari; Yasser Fallatah; Masoud Bakheet; Anwar Al-Ruwaili; Clench Loufilou; Hussein Al-Eissa; Abdulaziz Majrashi; Nawaf Al-Sehimai; Hassimi Fadiga; Saleh Al-Harthi; Omar Al-Rashed; João Silva.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-jandal-sc/kader/verein/78886/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Adalah FC
**Jogadores identificados:** Mohammed Sultan Al-Dawsari; Mohammed Al-Biladi; Koffi Kouamé; André Teixeira; Ahmed Al-Muwallad; Khalid Al-Muziel; Ammar Al-Basha; Mohammed Al-Hejji; Haider Al-Haji; Mohammed Al-Saeed; Salman Al-Omaish; Sultan Faqihi; Abdullah Al-Rashidi; Khaled Al-Hamdhi; Mohammed Al-Musallam; Ali Al-Abbad; Hassan Al-Mohammed; Abdullah Khalifah Al-Dossary; David Tijanic; Riyadh Al-Ibrahim; Hussain Al-Nattar.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-adalah-fc/kader/verein/55544/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Bukiryah FC
**Jogadores identificados:** Motaz Akjah; Mansour Jawhar; Faisal Al-Shammari; Fernando Piñero; Manaf Abuyabes; Mousa Al-Hamidi Al-Harbi; Bandar Baajaj; Hattan Ahmed; Hazza Asseri; Rayan Sharahili; Hussain Al-Zabdani; Meshaal Sané; Abdulrahman Hawsawi; Hicham Faik; Mohammed Al-Mahmoudi; Abdulrahman Al-Barakah; Yazeed Jathmi; Osamah Al-Marwani; Ibrahim Al-Sunaytan; Nasser Kaabi; Yassine Zakir.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-bukiryah-fc/kader/verein/68748/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Saqer FC
**Jogadores identificados:** Fares Al-Shammari; Azzam Al-Hussayen; Hani Al-Nahedh; Vinicius Milani; Abdulrahman Al-Qasim; Hussein Hawsawi; Nawaf Al-Mubarak; Salman Al-Saeed; Hamed Al-Mousa; Dawood Al-Tarif; Abdulmajeed Al-Enezi; Hassan Al-Balawi; Moayed Al-Dawas; Hassan Sufyani; João Erick; Sulaiman Al-Dulaylan; Manawa Emmanuel Kpatai; Nawaf Al-Reshoodi; Malik Hamza; Jasin Assehnoun; Mohanad Al-Shudukhi.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-saqer-fc/kader/verein/95443/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Al-Jeel Club
**Jogadores identificados:** Abdullah Al-Saleh; Hussain Al-Tuti; Ibrahim Al-Hafith; Abdullah Al-Oboud; Dilsinho; Abdullah Al-Suwaie; Saud Fallatah; Fawaz Al-Hamad; Osama Al-Johar; Hani Al-Sebyani; Ahmed Kaabi; Ibrahim Jaafari; Rayan Al-Rajeh; Mohammed Al-Fuhaid; Abdulrahman Al-Faleh; Mohammed Al-Duhailan; Bader Al-Saad; Léo Tilica; Saud bin Zaydan; Thaar Al-Otaibi; Yasser Daribi.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/al-jeel-club/kader/verein/55761/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

### Hajer Club
**Jogadores identificados:** Basil Al-Numair; Basil Al-Bahrani; Abdullah Al-Bahri; Ayoub Derbal; Bakary Coulibaly; Ali Al-Eissa; Murtadha Al-Burayh; Abdullah Al-Yousef; Abdullah Sultan Al-Zori; Nasser Khalifah; Hamad Al-Harbi; Abdullah Al-Makki; Khader Al-Haj; Faisal Al-Asmari; Hassan Jafari; Omar Al-Suhaimi; Osama Al-Mubaireek; Karrar Al-Qanbar; Wadhah Zaidi; Khalid Al-Ibrahim; Albert Amoah; Ryan Al-Bloushi; Ali Al-Mayyad; Waleed Ghazwani.

**Fonte de elenco 26/27:** [Transfermarkt](https://www.transfermarkt.us/hajer-club/kader/verein/32343/saison_id/2026) (extrato parcial; elenco listado com temporada 26/27).

## Observações de cobertura

A lista dos 18 participantes foi obtida na página da competição Transfermarkt selecionada para 26/27. Os 18 links individuais acima usam `saison_id=2026` e exibem a temporada 26/27 nos próprios seletores; páginas também mostram atividade de liga/posicionamento. Isso dá evidência específica de temporada e evita transplantar automaticamente o elenco de 25/26, mas Transfermarkt é uma fonte secundária, não uma confirmação oficial dos registros federativos.

A página pública oficial da SAFF para a competição foi consultada. Apesar de oferecer seleção de temporadas até 2026–2027, o conteúdo retornado foi de uma classificação e partidas de 2021–2022, então não a usei para declarar plantéis nem participantes de 26/27. Não localizei uma página oficial de elenco 26/27 capaz de corrigir ou validar os nomes compilados aqui.

Os extratos de elenco foram truncados na leitura da página em diversas equipes. Assim, cada seção acima conserva apenas os nomes efetivamente visíveis no extrato; pode haver mais jogadores nas páginas completas. Também há possíveis homônimos e variantes de transliteração. Este levantamento não afirma que os nomes acima formam os elencos completos, nem que sejam as inscrições oficiais finais.

## Fontes principais

- Lista de clubes e seletor 26/27: [Saudi First Division League — Transfermarkt](https://www.transfermarkt.us/saudi-first-division-league/startseite/wettbewerb/SA2L)
- Página oficial da competição, SAFF: [Saudi League 1st Division](https://www.saff.com.sa/en/championship.php?id=73)
- Elencos individuais: links específicos por clube nas respectivas seções acima.
