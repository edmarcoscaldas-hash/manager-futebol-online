# New Zealand National League masculina — temporada de 2027

**País:** Nova Zelândia  
**Campeonato:** Dettol National League (competição masculina)  
**Divisão:** primeira divisão nacional / principal competição doméstica de clubes  
**Temporada/status em 12 de novembro de 2026:** temporada inaugural no novo formato, prevista para começar no fim de março de 2027. A competição ainda não começou. A Federação confirmou uma liga nacional de 12 clubes, em turno e returno, seguida por finais. Os participantes foram definidos com base nos resultados regionais de 2022–2026; Western Springs garantiu a 12.ª vaga no playoff em setembro de 2026. [1] [2] [3]

## Elencos: cobertura e limite de verificação

Foram identificados os 12 clubes participantes. Na pesquisa das fontes oficiais da New Zealand Football e nas fontes públicas localizadas para a confirmação dos participantes, não foi possível encontrar listas oficiais de jogadores especificamente identificadas como elencos da temporada 2027. Como a temporada só começa em março de 2027 e não há confirmação pública de rosters 2027 nas fontes consultadas, não atribuo aos clubes jogadores de 2026 nem de anos anteriores. Portanto, abaixo, “nenhum nome verificado” significa que não foi possível confirmar nomes como integrantes do elenco 2027; não significa que os clubes não tenham jogadores registrados ou contratados.

A lista dos participantes e o resultado do playoff são cobertos por New Zealand Football e pela publicação neozelandesa Friends of Football. Para cada clube, a cobertura de elenco é incompleta: nenhum nome foi incluído sem fonte que o associe à temporada 2027. A fonte oficial da liga consultada publica o formato e a qualificação, mas não apresenta páginas de roster da temporada. [1] [2] [3]

## Auckland City FC

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. Não foi localizada fonte oficial de elenco 2027; não foram transportados nomes de temporadas anteriores.  
**Fonte de participação/formato:** [New Zealand Football — composição e qualificação da liga de 2027](https://www.nzfootball.co.nz/newsarticle/163883?newsfeedId=1275538); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Auckland FC (equipe masculina de reservas)

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. A confirmação de que a equipe de reservas participa não constitui uma lista nominal de jogadores da temporada.  
**Fonte de participação/formato:** [New Zealand Football — composição e qualificação da liga de 2027](https://www.nzfootball.co.nz/newsarticle/163883?newsfeedId=1275538); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Auckland United FC

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. Não foi localizada fonte oficial de elenco 2027; não foram transportados nomes de temporadas anteriores.  
**Fonte de participação/formato:** [New Zealand Football — formato da competição](https://www.nzfootball.co.nz/newsarticle/168426); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Birkenhead United AFC

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. Não foi localizada fonte oficial de elenco 2027; não foram transportados nomes de temporadas anteriores.  
**Fonte de participação/formato:** [New Zealand Football — formato da competição](https://www.nzfootball.co.nz/newsarticle/168426); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Cashmere Technical FC

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. Não foi localizada fonte oficial de elenco 2027; não foram transportados nomes de temporadas anteriores.  
**Fonte de participação/formato:** [New Zealand Football — formato da competição](https://www.nzfootball.co.nz/newsarticle/168426); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Coastal Spirit FC

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. Não foi localizada fonte oficial de elenco 2027; não foram transportados nomes de temporadas anteriores.  
**Fonte de participação/formato:** [New Zealand Football — formato da competição](https://www.nzfootball.co.nz/newsarticle/168426); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Eastern Suburbs AFC

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. Não foi localizada fonte oficial de elenco 2027; não foram transportados nomes de temporadas anteriores.  
**Fonte de participação/formato:** [New Zealand Football — formato da competição](https://www.nzfootball.co.nz/newsarticle/168426); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Miramar Rangers AFC

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. Não foi localizada fonte oficial de elenco 2027; não foram transportados nomes de temporadas anteriores.  
**Fonte de participação/formato:** [New Zealand Football — formato da competição](https://www.nzfootball.co.nz/newsarticle/168426); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Napier City Rovers FC

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. Não foi localizada fonte oficial de elenco 2027; não foram transportados nomes de temporadas anteriores.  
**Fonte de participação/formato:** [New Zealand Football — formato da competição](https://www.nzfootball.co.nz/newsarticle/168426); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Wellington Olympic AFC

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. Não foi localizada fonte oficial de elenco 2027; não foram transportados nomes de temporadas anteriores.  
**Fonte de participação/formato:** [New Zealand Football — formato da competição](https://www.nzfootball.co.nz/newsarticle/168426); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Wellington Phoenix (equipe masculina de reservas)

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. A confirmação de que a equipe de reservas participa não constitui uma lista nominal de jogadores da temporada.  
**Fonte de participação/formato:** [New Zealand Football — composição e qualificação da liga de 2027](https://www.nzfootball.co.nz/newsarticle/163883?newsfeedId=1275538); [Friends of Football — clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Western Springs AFC

**Jogadores nomeados do elenco 2027 publicamente verificados:** nenhum. O clube conquistou a vaga final no playoff de setembro de 2026; os jogadores citados em relatos dessa partida não são tratados como elenco 2027 sem confirmação explícita.  
**Fonte de participação/formato:** [New Zealand Football — formato da competição](https://www.nzfootball.co.nz/newsarticle/168426); [Friends of Football — resultado do playoff e clubes de 2027](https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/).

## Referências

[1]: https://www.nzfootball.co.nz/newsarticle/168426 "New Zealand Football: detalhes do novo formato nacional a partir de 2027"
[2]: https://www.nzfootball.co.nz/newsarticle/163883?newsfeedId=1275538 "New Zealand Football: qualificação da National League masculina para 2027"
[3]: https://www.friendsoffootballnz.com/2026/09/21/western-springs-complete-line-up-for-2027-mens-national-league/ "Friends of Football: Western Springs completa a lista de clubes masculinos de 2027"
