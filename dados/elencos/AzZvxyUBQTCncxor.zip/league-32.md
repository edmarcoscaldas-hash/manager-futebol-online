# Botola Pro D2 (Botola 2) — Marrocos, 2026/27

- **País:** Marrocos
- **Campeonato:** Botola Pro D2 (também chamada Botola 2)
- **Divisão:** segunda divisão nacional
- **Temporada/status em 12 de novembro de 2026:** temporada 2026/27 em andamento. A página contemporânea de classificação registra seis partidas disputadas por cada equipe. A FRMF mantém páginas oficiais de classificação e calendário da D2; a cobertura jornalística contemporânea informou início das competições profissionais em 24 de setembro de 2026. [1] [2] [3]

## Nota de cobertura

A classificação 2026/27 consultada em 12/11/2026 identifica 16 participantes, listados abaixo. A pesquisa não localizou páginas oficiais de elenco/roster da FRMF ou dos clubes com listas nominais verificáveis para esta temporada. Também não encontrou base confiável que publicasse um plantel completo e claramente datado de 2026/27 para qualquer uma das equipes. Para evitar misturar temporadas ou atribuir jogadores sem evidência, nenhuma lista de jogadores foi inventada ou transposta de temporadas anteriores. Em cada seção, portanto, “não verificados” significa que não foi possível confirmar publicamente nomes como integrantes do elenco 2026/27 a partir das fontes consultadas; não significa que o clube não tenha jogadores registrados. Os nomes dos clubes são da classificação da temporada atual. [2] [3]

## Union Yacoub El Mansour

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação 2026/27 de [365Scores](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## Wydad Fes

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação 2026/27 de [365Scores](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## Olympique Dcheira

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação 2026/27 de [365Scores](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## Ittihad Khemisset (Ittihad Zemmouri Khemisset)

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação 2026/27 de [365Scores](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); temporada 2026/27 no [Elbotola](https://www.elbotola.com/en/analytics/season/3glrw7hww3oqdyj).

## USM Oujda

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação 2026/27 de [365Scores](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## Stade Marocain

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação 2026/27 de [365Scores](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); temporada 2026/27 no [Elbotola](https://www.elbotola.com/en/analytics/season/3glrw7hww3oqdyj).

## Olympique Safi

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação e jogos de [365Scores — Botola 2 2026/27](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## Mouloudia Oujda

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação e jogos de [365Scores — Botola 2 2026/27](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## Jeunesse Sportive El Massira (JSM Laâyoune)

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação e jogos de [365Scores — Botola 2 2026/27](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## Chabab Ben Guerir

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação 2026/27 de [365Scores](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); temporada 2026/27 no [Elbotola](https://www.elbotola.com/en/analytics/season/3glrw7hww3oqdyj).

## Olympique Khouribga

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação e jogos de [365Scores — Botola 2 2026/27](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## KAC Kenitra

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação e jogos de [365Scores — Botola 2 2026/27](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## Chabab Khénifra

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação e jogos de [365Scores — Botola 2 2026/27](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## US Boujaad

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação e jogos de [365Scores — Botola 2 2026/27](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## SCC Mohammédia

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação e jogos de [365Scores — Botola 2 2026/27](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## Riadi Salmi

- **Jogadores 2026/27 publicamente verificáveis:** nenhum nome de elenco confirmado nesta pesquisa.
- **Fontes:** classificação e jogos de [365Scores — Botola 2 2026/27](https://www.365scores.com/en-us/football/league/botola-2-5651/standings); página oficial da [FRMF — Botola Pro D2](https://frmf.ma/fr/botola-pro/d2).

## Referências

[1]: https://frmf.ma/fr/botola-pro/d2 "FRMF — Botola Pro D2"
[2]: https://www.365scores.com/en-us/football/league/botola-2-5651/standings "365Scores — classificação Botola 2 2026/27"
[3]: https://www.elbotola.com/en/analytics/season/3glrw7hww3oqdyj "Elbotola — Botola 2 2026/27"
[4]: https://www.elbotola.com/en/article/2026-08-28-18-28-789.html "Elbotola — anúncio da data de início da temporada profissional 2026/27"
