# Saudi Pro League 2026/27 — clubes e jogadores listados

- **País:** Arábia Saudita
- **Campeonato:** Saudi Pro League (Roshn Saudi League)
- **Divisão:** 1ª divisão
- **Temporada/status em 12 nov. 2026:** temporada 2026/27 em andamento. O site oficial exibe equipes com jogos disputados e classificação (até 12 jogos nas páginas consultadas), além de roster de jogadores por clube. A listagem abaixo registra os nomes exibidos nas páginas oficiais de elenco consultadas nessa data; é uma fotografia de roster publicado, não garantia de que sejam todos os jogadores registrados ou elegíveis na federação.

A página oficial da SPL relaciona 18 clubes. As páginas individuais abaixo mostram o plantel em grupos de goleiros, defensores, meio-campistas e atacantes; para facilitar, os jogadores são apresentados em uma lista única por clube. A comissão técnica foi excluída. Nomes reproduzidos na forma latina ou árabe que a página apresenta; eventuais variações de transliteração não foram harmonizadas. [1] [2]

## Abha

**Jogadores:** Donovan Léon; Abdulrahman Al-Bouq; Mustafa Malayekah; Moayad Binyan; Jurien Gaari; Khaled Al-Shamrani; Abdullah Al-Fahad; Abdou Diallo; Mohammed Al-Dossary; Abdulbasit Hindi; Nawaf Al-Ghulaimish; Safwan Al-Johani; Basil Al-Sayyali; Faisal Al-Subiani; Feras Al-Ghamdi; Nasser Al-Daajani; Mohammed Al-Hamsal; Bader Al-Mutairi; Majed Dawran; Loreintz Rosier; Mohammed Al-Zaid; Mateo Borrell; Ammar Al-Yuhaybi; Ali Al-Mubarki; Kamil Boumedmed; Nabil Fekir; Alimami Gory; Georges-Kévin Nkoudou; Abdulkarim Darisi; Koshaim Al-Qahtani; Michy Batshuayi.

**Fonte oficial (plantel):** [elenco Abha — SPL](https://www.spl.com.sa/ar/teams/abha/squad).

## Al-Ahli

**Jogadores:** Abdulrahman Al-Sanbi; Edouard Mendy; Abdullah Abdo; Salman Al-Jadani; Zakaria Hawsawi; Roger Ibañez; Mohammed Suleiman; Saeed Baattia; Abubacarr Kinteh; Ali Majrashi; Merih Demiral; Mohammed Abdulrahman; Saad Balobaid; Rayan Hamed; Ibrahima Diaby; Valentin Atangana; Eduard Spertsyan; Artem Bondarenko; Ibrahim Azzam; Faisal Fallatah; Ziyad Al-Johani; Wael Al-Johani; Ziyad Mallah; Naif Masoud; Ramez Al-Attar; Francisco Trincão; Feras Al-Brikan; Meshal Al-Mutairi; Galeno; Ivan Toney; Matheus Gonçalves; Abdullah Radif; Saleh Abu Al-Shamat; Salem Abdullah.

**Fonte oficial (plantel):** [elenco Al-Ahli — SPL](https://www.spl.com.sa/ar/teams/al-ahli/squad).

## Al-Ettifaq

**Jogadores:** Marek Rodák; Abdulbasit Hawsawi; Ahmad Al-Rehaili; Turki Baljoush; Abdullah Madu; Jack Hendry; Pedro Henrique; Meshal Al-Alaeli; Madallah Al-Olayan; Radi Al-Otaibi; Abdullah Al-Khateeb; Marzouq Tambakti; Meshal Sibyani; Álvaro Medrán; Ondrej Duda; Riyadh Sharahili; Abdoulaye Kanté; Bersant Celina; Yasir Al-Shammari; Abdulelah Hawsawi; Rayane Messi; Talal Haji; Khalid Al-Ghannam; Moussa Dembélé; Abdullah Al-Bishi; Jordan Larsson; Ziyad Al-Ghamdi; Matija Gluščević; Ali Al-Essa; Sultan Haroun.

**Fonte oficial (plantel):** [elenco Al-Ettifaq — SPL](https://www.spl.com.sa/ar/teams/al-ettifaq/squad).

## Al-Faisaly

**Jogadores:** Fernando Pacheco; Abdulelah Nassief; Mohammed Al-Hasawi; Yaseen Barnawi; Khaled Al-Harbi; Abdoulaye Seck; Andrei Girotto; Mohammed Saadoun Al-Shammari; Mohammed Al-Shanqiti; Mohammed Jahfali; Hussain Al-Zarie; Abdullah Subayt; Saud Haddad; Eid Al-Muwallad; Flávio Medeiros; Abdulrahman Al-Safari; Jaime Seoane; Abdulaziz Al-Bishi; Abdulrahman Al-Sharif; Ayman Fallatah; Yousef Al-Mozairib; Théo Bongonda; André Jordy Ella; Christian Bassogog; Abdullah Al-Mogren; Dayo Joyce Osho; Wael Kadan; Faisal Al-Fahad; Ahmed Abdu.

**Fonte oficial (plantel):** [elenco Al-Faisaly — SPL](https://www.spl.com.sa/ar/teams/al-faisaly/squad).

## Al-Fateh

**Jogadores:** Adrian Šemper; Habib Al-Watyan; Ibrahim Al-Abood; Waleed Al-Anzi; Kennedy Boateng; Ziyad Al-Jari; Faisal Darisi; Abdulelah Al-Khaibari; Marwane Saadane; Robin Kelder; Abdulrahman Al-Khaibari; Ali Al-Amin; Muntathir Al-Shaqaq; Abdulaziz Al-Suwailem; Sattam Al-Tambakti; Ali Al-Hassan; Mihai Lixandru; Lukáš Haraslín; Abdulaziz Al-Fawaz; Hossam Essadak; Mehdi Al-Aboud; Mohammed Al-Sahihi; Zaydou Youssouf; Faisal Al-Abdulwahed; Othman Al-Othman; Fahad Al-Zubaidi; Wilfried Kanga; Mourad Batna; Jefferson Ramos; João Sorriso; Ali Al-Masoud; Saad Al-Sharfa.

**Fonte oficial (plantel):** [elenco Al-Fateh — SPL](https://www.spl.com.sa/ar/teams/al-fateh/squad).

## Al-Fayha

**Jogadores:** Abdulraouf Al-Duqayl; Sattam Al-Shammari; Osama Al-Thumayri; Orlando Mosquera; Makhir Al-Rashidi; Turki Al-Jaadi; Paulo Oliveira; Ziyad Al-Sahafi; Mohammed Al-Baqawi; Ahmed Bamasud; Omar Colley; Ali Al-Harshan; Mohammed Al-Dowaish; Hamid Hazzazi; Abdulhadi Al-Harajin; Hugo Moura; Ali Al-Hussain; Nawaf Al-Harthi; Mansor Al-Beshe; Abdullah Al-Qahtani; Al-Baraa Adawi; Alfa Semedo; Yago Souza; Fahad Al-Hubayshi; Abdullah Al-Anzi; Danyal Al-Habeeb; Malek Al-Abadalmanam; Fashion Sakala; Lázaro Vinícius; Jason Remeseiro; Sultan Al-Jabri; Mohammed Hakami; Rayan Al-Mutairi; Mouath Al-Habib.

**Fonte oficial (plantel):** [elenco Al-Fayha — SPL](https://www.spl.com.sa/ar/teams/al-fayha/squad).

## Al-Hazem

**Jogadores:** Yazan Al-Ruwaili; Bruno Varela; Ibrahim Zaied; Majed Al-Ghamdi; Jindřich Staněk; Saud Al-Rashed; Mohamed Amine Ben Hmida; Sultan Tanker; Mohammed Al-Jamaan; Farhan Al-Azzmi; Abdullah Al-Shanqiti; Ahmed Al-Nakhli; Abdurahman Al-Dakheel; Abdulaziz Al-Harbi; Jaser Muneer Shleaah Ateeq; Hassan Idris; Mory Konaté; Amir Sayoud; Bonheur Mugisha; Abdulaziz Al-Dhuwayhi; Aboubacar Bah; Sofiane Bendebka; Ahmed Al-Shamrani; Ayman Al-Hujaili; Nawaf Al-Bishri; Elton-Ofoi Acolatse; Afimico Pululu; Waleed Al-Shanqiti; Amadou Bamba Dieng; Aboubacar Diakité; Mohammed Al-Hamdani; Khalid Abduljawad.

**Fonte oficial (plantel):** [elenco Al-Hazem — SPL](https://www.spl.com.sa/ar/teams/al-hazem/squad).

## Al-Hilal

**Jogadores:** Rayan Al-Dossary; Mohammed Al-Rubaie; Mohammed Al-Owais; Yassine Bounou; Mohammed Mahzari; Kalidou Koulibaly; Yusuf Akçiçek; Theo Hernández; Moteb Al-Harbi; Saad Al-Muthary; Meshal Al-Dawood; Mohammed Al-Sarnoukh; Ali Lajami; Hassan Al-Tambakti; Hamad Al-Tuhayfan; Nasser Al-Dawsari; Rúben Neves; Murad Al-Hawsawi; Sergej Milinković-Savić; Mohammed Kanno; Salem Al-Dawsari; Saimon Bouabré; Nawaf Al-Habashi; Abdullah Sufuq; Suhayb Al-Zaid; Gabriel Martinelli; Ollie Watkins; Sultan Mandash; Crysencio Summerville; Sabri Dahal; Mohamed Meïté.

**Fonte oficial (plantel):** [elenco Al-Hilal — SPL](https://www.spl.com.sa/ar/teams/al-hilal/squad).

## Al-Ittihad

**Jogadores:** Predrag Rajković; Mohammed Al-Absi; Osama Al-Mermesh; Danilo Pereira; Jan-Carlo Simić; Saad Al-Mosa; Muhannad Al-Shanqiti; Hassan Kadesh; Ahmed Sharahili; Faris Abdi; Ahmed Al-Julaydан; Muath Fagihy; Mohammed Barnawi; Richard Ríos; Mukhtar Ali; Houssem Aouar; Mahamadou Doumbia; Georginio Wijnaldum; Farhah Al-Shamrani; Dion Lopy; Mohammed Fallatah; Rakan Kaabi; Hamed Al-Ghamdi; Roger Fernandes; George Ilenikhena; Saleh Al-Shehri; Youssef En-Nesyri; Marwan Al-Sahafi; Ahmed Al-Ghamdi; Steven Bergwijn.

**Fonte oficial (plantel):** [elenco Al-Ittihad — SPL](https://www.spl.com.sa/ar/teams/al-ittihad/squad).

## Al-Khaleej

**Jogadores:** Mohammed Al-Ibrahim; Anthony Moris; Marwan Al-Haidari; Abdullah Al-Ammar; Hamad Al-Jayzani; Mohammed Al-Khabrani; Boubacar Kouyaté; Pedro Rebocho; Ahmed Asiri; Ali Al-Shaafi; Abdullah Al-Hafith; Hamid Al-Zahri; Raed Al-Shanqiti; Fawaz Al-Saqoor; Saeed Al-Hamsal; Omar Mascarell; Angelo Fulgini; Majed Kanabah; Bader Munshi; Miguel Crespo; Ali Abdulraouf; Abdoulie Mboge; Joshua King; Mateo Benegas; Saleh Al-Amri; Mansour Hamzi; Nawaf Al-Saadi; Wilson Diogo; Hussain Al-Eissa; Thamer Al-Khaibri; Fahad Al-Rashidi; Musa Barrow.

**Fonte oficial (plantel):** [elenco Al-Khaleej — SPL](https://www.spl.com.sa/ar/teams/al-khaleej/squad).

## Al-Kholood

**Jogadores:** Hamed Al-Shanqiti; Mohammed Al-Shammari; Muhannad Al-Yahya; Edgaras Utkus; Sultan Al-Shehri; Yazan Madani; Odai Slimani; Mansour Camara; Shaquille Pinas; Abdulrahman Al-Obaid; John Buckley; Seydouba Cissé; Iker Kortajarena; Ibrahem Barabaa; Abdulrahman Al-Dosari; Rakan Bin Jamaan; Mohammed Al-Rashdi; Mohammed Samili; Coba Da Costa; Ramzi Solan; Adam Berry; Julien Domingues; Yaseen Al-Zubaidi; Abdullah Al-Ajyan; Loïc Isoumba; Gustavo Rodrigues.

**Fonte oficial (plantel):** [elenco Al-Kholood — SPL](https://www.spl.com.sa/ar/teams/al-kholood/squad).

## Al-Nassr

**Jogadores:** Nawaf Al-Aqidi; Abdulhadi Al-Alwan; Bento Matheus; Abdulrahman Al-Otaibi; Abdulrahman Sufyani; Sultan Al-Ghannam; Mohamed Simakan; Nader Al-Sharari; Abdulelah Al-Amri; Saad Al-Nasser; Nawaf Bu Washl; Iñigo Martínez; Yassine Gays Munsif Sallem; Majed Qasheesh; Awad Aman; Salem Al-Najdi; Hayder Tofee; Samu Costa; Sami Al-Naji; Abdullah Al-Khaibari; Ayman Yahya; Cristiano Ronaldo; Abdullah Al-Hamddan; Sadio Mané; Mohammed Marran; Ângelo Gabriel; Kingsley Coman; Abdulrahman Ghareeb; Rakan Al-Ghamdi; Saad Haqawi; João Félix; Abdulrahman Sufyani.

**Fonte oficial (plantel):** [elenco Al-Nassr — SPL](https://www.spl.com.sa/ar/teams/al-nassr/squad). O roster exibe Abdulrahman Sufyani em duas entradas distintas (linha de zagueiro e atacante); mantido conforme a página.

## Al-Qadsiah

**Jogadores:** Koen Casteels; Ahmed Al-Kassar; Meshari Sunyur; Abdulilah Al-Jwayzan; Jehad Thikri; Nacho Fernández; Yasser Al-Shahrani; Gastón Álvarez; Waleed Al-Ahmad; Mohammed Al-Nakhli; Ali Diabaté; Abdulaziz Al-Qarawi; Mohammed Abu Al-Shamat; Julian Weigl; Turki Al-Ammar; Nahitan Nández; Musab Al-Juwayr; Ali Hazazi; Tijjani Reijnders; Abdulmalik Al-Jaber; Eyad Houssa; Ahmed Al-Siyahi; Abdullah Al-Salem; Mohammed Al-Qahtani; Haitham Asiri; Christopher Bonsu Baah; Mahamadou Sangaré; Mateo Retegui; Julián Quiñones; Abdulaziz Al-Elewai; Suleman Sani.

**Fonte oficial (plantel):** [elenco Al-Qadsiah — SPL](https://www.spl.com.sa/ar/teams/al-qadsiah/squad).

## Al-Riyadh

**Jogadores:** Jan Petek; Milan Borjan; Emad Fidaa; Sultan Al-Essa; Yasser Al-Musa; Hussam Majrashi; Sulaiman Hazazi; Osama Al-Bawardi; Essam Bahri; Hussain Qasim; Rodrigo Abascal; Awad Dahal; Mohammed Al-Khaibari; Ahmed Al-Anizi; Kader Keita; Mahmoud Trezeguet; Faisal Al-Subhi; Hussain Al-Shurafaa; Victor Lekhal; Abdulilah Al-Tale; Salman Matar; Bernard Mensah; Fahad Al-Jayzani; Cheikh Fall; Teddy Okou; Hassan Al-Ali; Hussain Al-Raqwani; Battal Al-Harthi; Leandro Antunes.

**Fonte oficial (plantel):** [elenco Al-Riyadh — SPL](https://www.spl.com.sa/ar/teams/al-riyadh/squad).

## Al-Shabab

**Jogadores:** Mohammed Al-Otaibi; Mory Diaw; Abdulaziz Al-Awardi; Mohammed Al-Mahasnah; Ali Al-Bulayhi; Mohammed Al-Shwirekh; Mamadou Barry; Tin Jedvaj; Ali Makki; Lazar Stojanović; Mohammed Al-Thani; Dhari Al-Anazi; Abdullah Al-Hawsawi; Sultan Al-Anize; Yazeed Al-Dawsari; Awad Al-Nashri; Josh Brownhill; Yannick Carrasco; Thomas Partey; Yacine Adli; Adel Abbas; Ali Al-Asmari; Muqrin Abanumay; Roger Martínez; Daniel Podence; Hammam Al-Hammami; Abdulrahman Al-Obud; Ricardo Mathias; Abdullah Matuq; Abdulaziz Hadhood; Morad Khodari; Hamad Al-Khorayef.

**Fonte oficial (plantel):** [elenco Al-Shabab — SPL](https://www.spl.com.sa/ar/teams/al-shabab/squad).

## Al-Taawoun

**Jogadores:** Abdulrahman Al-Senaid; Mailson dos Santos; Abdullah Al-Jadani; Abdulrahman Al-Ghamdi; Zineddine Belaïd; Bassam Al-Hurayji; Adeeb Al-Hassan; Muteb Al-Mufarrij; Nawaf Al-Hawairy; Nasser Al-Haleel; Jair Collahuazo; Ali Sharahili; Awn Al-Saluli; Nedim Bajrami; Faris Al-Ghamdi; Aschraf El Mahdioui; Oscar Dorley; Rakan Al-Tulayhi; Ibrahim Mahnashi; Mohammed Al-Saedi; Adel Fallatah; Abdulrahman Hindi; Mohammed Al-Kuwaykibi; Parfait Guiagon; Abderrazzaq Hamdallah; Saif Rajab; Mohammed Al-Aqel; Bassem Al-Arini; Abdulrahman Al-Harbi; Younes El-Bahraoui; Marin Petkov.

**Fonte oficial (plantel):** [elenco Al-Taawoun — SPL](https://www.spl.com.sa/ar/teams/al-taawoun/squad).

## Diriyah

**Jogadores:** Nikola Vasilj; Waleed Abdullah; Mansour Al-Sibyani; Amin Al-Bukhari; Abdulaziz Al-Faraj; Saeed Al-Rubaie; Taher Wadi; Hussain Al-Sibyani; Berat Djimsiti; Mohamed Hameran; Khalid Al-Asiri; Qassem Lajami; Chancel Mbemba; Mathys de Carvalho; Idrissa Gana Gueye; Sultan Al-Farhan; Óscar Rodríguez; Enzo Millot; Hussain Al-Qahtani; Abdulelah Al-Malki; Adil Boulbina; Hattan Bahebri; Clayton Diandy; Lovro Chelfi; Darwin Núñez; Abdullah Al-Zaid; Meshari Al-Nemer.

**Fonte oficial (plantel):** [elenco Diriyah — SPL](https://www.spl.com.sa/ar/teams/diriyah/squad).

## NEOM

**Jogadores:** Mohammed Al-Hakim; Marcin Bułka; Abdulrahman Dagriri; Luís Maximiano; Mohammed Al-Burayk; Khalifah Al-Dawsari; Malang Sarr; Abdulmalik Al-Oyayari; Mohannad Abu Taha; Islam Hawsawi; Nathan Zézé; Mohammed Walid; Khaled Al-Rammah; Abbas Al-Hassan; Faisal Al-Ghamdi; Alaa Al-Hejji; Valentin Vada; Abdulaziz Noor; Geovanny Balanta; Amadou Koné; Zassely Lopez Desire Biaka; Giorgos Masouras; Abdulaziz Al-Othman; Saïd Benrahma; Khalil Al-Absi; Ahmed Al-Anazi; Haroune Camara; Muhannad Al-Saad; Alexandre Lacazette.

**Fonte oficial (plantel):** [elenco NEOM — SPL](https://www.spl.com.sa/ar/teams/neom/squad).

## Cobertura e referências

Foram cobertos os 18 clubes listados no diretório oficial da liga e consultadas suas respectivas páginas oficiais de elenco. A SPL é a fonte primária para os nomes; seus perfis de clube identificam também a temporada em curso por meio de classificação e partidas disputadas. Os elencos podem mudar durante a janela de transferências ou por atualizações do site. Casos em que o nome aparece sem perfil clicável foram incluídos apenas quando estavam explicitamente impressos na página do elenco. Não usei elencos de outras temporadas para preencher lacunas.

[1]: https://www.spl.com.sa/ar/teams "Diretório oficial dos clubes da Saudi Pro League"
[2]: https://www.spl.com.sa/standings "Classificação oficial — temporada 2026/27"
[3]: https://www.spl.com.sa/fixtures-results "Calendário e resultados oficiais"
[4]: https://www.transfermarkt.us/saudi-pro-league/startseite/wettbewerb/SA1 "Transfermarkt — Saudi Pro League 26/27, fonte secundária de conferência"
