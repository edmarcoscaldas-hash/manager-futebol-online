# UAE First Division League — temporada 2026/27

- **País:** Emirados Árabes Unidos
- **Campeonato:** UAE First Division League
- **Divisão:** 2ª divisão nacional
- **Status em 12 de novembro de 2026:** temporada iniciada. A cobertura de resultados consultada registra jogos de 6 a 8 de novembro de 2026 e classificação da temporada 2026/27. A competição tem 15 clubes nessa tabela. [1] [2]

## Cobertura e limites

A listagem abaixo cobre todos os 15 participantes exibidos na classificação 2026/27 da Global Sports Archive (GSA). A página oficial UAEFA da competição foi consultada, mas sua versão acessível não apresentou na extração uma relação de elencos 2026/27; tampouco foi localizada ali uma roster page oficial por clube. A GSA confirma o campeonato em andamento, os clubes, placares, estatísticas e escalações de partidas, mas a página geral consultada não fornece um elenco completo e consolidado por clube. [1] [2]

Para não atribuir automaticamente jogadores da temporada passada, os nomes listados por clube abaixo são apenas jogadores que a página GSA da temporada 2026/27 identifica em estatísticas de gols até o momento da consulta. Isso confirma participação estatística na temporada, não que a relação seja o elenco completo. Clubes sem nome confirmado na seção de artilharia visível estão assinalados sem nomes verificáveis neste levantamento; isso não significa que não tenham jogadores inscritos. **Não foi possível estabelecer publicamente uma lista completa de todos os jogadores reais de cada elenco a partir das fontes consultadas.**

## Clubes e jogadores publicamente identificados

### Al Arabi CSC
- **Jogadores confirmados na estatística de gols 2026/27:** Wesley Braga; Yacine Bentayeb; Régis; Cheick Timité. [1]
- **Fonte/nota:** estatísticas da liga GSA; relação parcial, não elenco completo. [1]

### Emirates CSC
- **Jogador confirmado na estatística de gols 2026/27:** Baha' Faisal. [1]
- **Fonte/nota:** estatísticas da liga GSA; relação parcial, não elenco completo. [1]

### Forte Virtus FC
- **Jogador confirmado na estatística de gols 2026/27:** Massiah Dyeidu. [1]
- **Fonte/nota:** estatísticas da liga GSA; relação parcial, não elenco completo. [1]

### Al Orooba SCC
- **Jogadores confirmados na estatística de gols 2026/27:** nenhum nome incluído na lista de artilheiros consultada.
- **Fonte/nota:** clube participante confirmado na classificação; elenco completo não verificado. [1]

### Dibba SCC
- **Jogadores confirmados na estatística de gols 2026/27:** Xhonathan Lajthia; Saymon Cabral. [1]
- **Fonte/nota:** estatísticas da liga GSA; relação parcial, não elenco completo. [1]

### Al Hamriya CSC
- **Jogadores confirmados na estatística de gols 2026/27:** nenhum nome incluído na lista de artilheiros consultada.
- **Fonte/nota:** clube participante confirmado na classificação; elenco completo não verificado. [1]

### Al Dhaid CSC
- **Jogadores confirmados na estatística de gols 2026/27:** Gregory. [1]
- **Fonte/nota:** estatísticas da liga GSA; relação parcial, não elenco completo. [1]

### Palm City FC
- **Jogador confirmado na estatística de gols 2026/27:** Pozuelo. [1]
- **Fonte/nota:** listado como Palm City FC na classificação, com jogos também referidos como 365 FC na ficha de partida; estatísticas da liga GSA, relação parcial. [1]

### Deba Al Hissin SCC
- **Jogadores confirmados na estatística da liga 2026/27:** Mohammad Al Hallak (assistências). [1]
- **Fonte/nota:** nome identificado na estatística de assistências, não na lista visível de artilheiros; relação parcial, não elenco completo. [1]

### Fujairah FC
- **Jogador confirmado na estatística de gols 2026/27:** Sander Benbachir. [1]
- **Fonte/nota:** estatísticas da liga GSA; relação parcial, não elenco completo. [1]

### Al Jazira Al Hamra CSC
- **Jogador confirmado na estatística de gols 2026/27:** Mohannad Khameis (gol de pênalti). [1]
- **Fonte/nota:** estatísticas da liga GSA; relação parcial, não elenco completo. [1]

### Al Bataeh CSC
- **Jogadores confirmados na estatística de gols 2026/27:** Ivonei (assistências); Ruan Santos (gol de pênalti). [1]
- **Fonte/nota:** nomes identificados em estatísticas da liga; relação parcial, não elenco completo. [1]

### Gulf United FC
- **Jogador confirmado na estatística de gols 2026/27:** Benik Afobe. [1]
- **Fonte/nota:** estatísticas da liga GSA; relação parcial, não elenco completo. [1]

### City FC
- **Jogador confirmado na estatística de gols 2026/27:** Anderson Júnior. [1]
- **Fonte/nota:** estatísticas da liga GSA; relação parcial, não elenco completo. [1]

### Al Ittifaq FC
- **Jogadores confirmados na estatística de gols 2026/27:** nenhum nome incluído na lista de artilheiros consultada.
- **Fonte/nota:** clube participante confirmado na classificação; elenco completo não verificado. [1]

## Referências

[1]: https://globalsportsarchive.com/en/soccer/competition/first-division-league-2026-2027/81053 "Global Sports Archive — First Division League 2026/2027"
[2]: https://www.uaefa.ae/en/competition/1685 "UAE Football Association — página da competição"
