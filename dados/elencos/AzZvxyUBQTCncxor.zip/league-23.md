# Eredivisie 2026/27 — clubes e jogadores publicamente listados

**País:** Países Baixos (Holanda)  
**Campeonato:** VriendenLoterij Eredivisie  
**Divisão:** 1ª divisão (Eredivisie)  
**Temporada/status em 12 nov. 2026:** em andamento. A liga divulgou calendário definitivo em junho de 2026; páginas da competição tinham resultados/notícias de novembro de 2026. A temporada começou em agosto de 2026, portanto não é uma projeção da temporada anterior. [1] [2]

## Cobertura e cautelas

Foram consultadas as páginas oficiais de elenco/equipe da Eredivisie para todos os 18 clubes participantes. A lista abaixo reproduz os nomes que apareciam na seção de jogadores (“Team & staf”) no momento da consulta, em 12 nov. 2026, agrupados sem comissão técnica. São elencos públicos da competição, não uma certificação de registro/inscrição individual da KNVB; páginas podem omitir atletas da base, emprestados ou jogadores não listados, e podem mudar ao longo da temporada. Por isso, “todos” aqui significa todos os jogadores nominalmente exibidos nessas páginas oficiais consultadas, não toda pessoa eventualmente vinculada ao clube. Não foram usados nomes de elencos de anos anteriores para completar lacunas.

A liga confirma os 18 clubes no programa definitivo e vincula páginas oficiais de cada clube. [1] As páginas de equipe citadas por clube são a fonte nominal dos jogadores. A comissão técnica foi excluída.

## Clubes e jogadores

### ADO Den Haag
**Jogadores listados:** Kilian Nikiema, Sem Eekhout, Caleb Kramer, Niclas Thiede, Othniel Raterink, Pascal Mulder, Matteo Waem, Jonas Jensen-Abbew, Illaijh de Ruijter, Milan Hokke, Sékou Oumar Sylla, Lasse Wilhelm, Sanyika Bergtop, Jan Žambůrek, Mylian Jiménez, Finn de Bruin, Jalen Hawkins, Álex Pozo, Juho Kilo, Alexander Veselov, Dani van Loenen, Matěj Šín, Daryl van Mieghem, Jesse Bal, Evan Rottier, Luka Reischl, Cameron Peupion, Ichnygel Thomas, Yannick Eduardo, Donát Bárány. [3]

### Ajax
**Jogadores listados:** Aymean El Hani, Marc-André ter Stegen, Joeri Heerkens, Maarten Paes, Charlie Setford, Lucas Rosa, Anton Gaaei, Owen Wijndal, Thilo Kehrer, Caio Henrique, Youri Baas, Daley Blind, Jofre Torrents, Aaron Bouwman, Dies Janse, Jinairo Johnson, Sofyan Amrabat, Julian Brandt, Oscar Gloukh, Davy Klaassen, Jorthy Mokio, Yves Bissouma, Mohamed Abdalla, Abdellah Ouazane, Simon Adingra, Kasper Dolberg, Viktor Tsygankov, Oliver Edvardsen, Steven Berghuis, Marcos Leonardo, Rayane Bounida, Diego Pugno, Tolu Arokodare. [4]

### AZ
**Jogadores listados:** Rome-Jayden Owusu-Oduro, Hobie Verhulst, Jari de Busser, Jeroen Zoet, Ismail Ka, Seiya Maikuma, Wouter Goes, Lewis Schouten, Mateo Chávez, Andrea Natali, Elijah Dijkstra, Wesley Hoedt, Denso Kasius, Rion Ichihara, Mees de Wit, Peer Koopmeiners, Jordy Clasie, Kees Smit, Calvin Stengs, Stije Resink, Valdemar Byskov, Dave Kwakman, Julian Oerip, Hessel de Wit, Weslley Patati, Mexx Meerdink, Ro-Zangelo Daal, Bendegúz Kovács, Jizz Hornkamp, Ayoub Oufkir, Wassim Bouziane, Jerolldino Bergraaf. [5]

### Excelsior Rotterdam
**Jogadores listados:** Stijn van Gassel, Celton Biai, Tijmen Holla, Rick Meissen, Casper Widell, Jan Plug, Simon Janssen, Osman Turay, Marlon van de Wetering, Daniël van Vianen, Irakli Yegoian, Noah Naujoks, Valentin Sulzbacher, Lennard Hartjes, Yacqub Finey, Giuliano Cairo, Ágúst Þorsteinsson, Quinten Kraaivanger, Eric da Silva Moreira, Aymen Sliti, Mario Domínguez, Alireza Jahanbakhsh, Kasey Bos, David Garden, Ilano Silva Timas, Nesto Groen. [6]

### FC Groningen
**Jogadores listados:** Etienne Vaessen, Lovro Štubljar, Pelle Boevink, Rijk Janse, Daan Erdman, Wouter Prins, Thijmen Blokzijl, Mark Csinger, Marco Rente, Nikolas Brandis, Elvis van der Laan, Malcolm Jeng, Tyrique Mercera, Hans Hateboer, Jesper Mosselaar, Travis Hernes, Tika de Jonge, Jorg Schreuders, Alvin Nordin, David van der Werff, Tygo Land, Pelle Clement, Jismerai Dillema, Jahelille Hall, Brynjólfur Willumsson, Jacob Ondrejka, Oskar Zawada, Nils Eggens, Thom van Bergen, Ryan Metu. [7]

### FC Twente
**Jogadores listados:** Lars Unnerstall, Joël Drommel, Remko Pasveer, Yannick Gerritsen, Michał Rosiak, Robin Pröpper, Ruud Nijstad, Stav Lemkin, Krzysztof Kurowski, Bart van Rooij, Aske Adelgaard, Max Bruns, Jip Meilink, Nigel Groenewald, Ramiz Zerrouki, Daouda Weidmann, Kristian Hlynsson, Jordy Bawuah, Thomas van den Belt, Benjamin Nagel, Gijs Besselink, Marko Pjaca, Wout Weghorst, Younes Taha, Daan Rots, Filip Thorvaldsen, Lucas Vennegoor of Hesselink, Sondre Ørjasæter, Naci Ünüvar. [8]

### FC Utrecht
**Jogadores listados:** Vasilis Barkas, Sergio Padt, Mees Eppink, Kevin Gadellaa, Siebe Horemans, Matisse Didden, Nikolas Panagiotou, Guus Offerhaus, Jakov Medić, Neville Ogidi Nwankwo, Niklas Vesterlund, Jamie Schuldes, Per Kloosterboer, Viggo Plantinga, Ferdinand Pohl, Arthur Zagré, Victor Jensen, Joris van Overeem, Dani de Wit, Alonzo Engwanda, Kevin Paredes, Dave van den Berg, Oualid Agougil, Artem Stepanov, Yoann Cathline, Ángel Alarcón, Adrian Blake, Sem van Duijn, Miliano Jonathans, Noah Ohio, Noureddine Amrabat, Emmanuel Owen, Marius Broholm. [9]

### Feyenoord
**Jogadores listados:** Tjark Ernst, Florian Kastenmeier, Mannou Berger, Liam Bossin, Bart Nieuwkoop, Thomas Beelen, Tsuyoshi Watanabe, Gijs Smal, Jeremiah St. Juste, Jordan Bos, Javi López, Mats Deijl, Givairo Read, Tijme Wessels, Mika Mármol, Dani Slory, Jakub Moder, Gjivai Zechiël, Luciano Valente, Sem Steijn, Tobias van den Elshout, Thijs Kraaijeveld, Oussama Targhalline, Charles Vanhoutte, Theodoris Deligiannidis, Gonçalo Borges, Reiss Nelson, Nacho Ferri, Anis Hadj Moussa, Gaoussou Diarra, Jivayno Zinhagel, Shaqueel van Persie, Jerayno Schaken. [10]

### Fortuna Sittard
**Jogadores listados:** Luuk Koopmans, Mattijs Branderhorst, Kaylen Reitmaier, Siebe Wylin, Rodrigo Guth, Iván Márquez, Syb van Ottele, Jasper Dahlhaus, Ivo Pinto, Nick de Groot, Daley Sinkgraven, Justin Hubner, Alhaji Bah, Yassin Oukili, Sven Simons, Édouard Michut, Shiloh ’t Zand, Philip Brittijn, Kevin van Burgsteden, Moussa Gbemou, Gani Büyükhan, Mohamed Ihattaren, Kristoffer Peterson, Anthony Descotte, Ole Romeny, Lequincio Zeefuik, David Stockbrink. [11]

### Go Ahead Eagles
**Jogadores listados:** Kjetil Haug, Nick Marsman, Jasper Cillessen, Thomas Hulleman, Nando Verdoni, Alfons Sampsted, Gerrit Nauber, Joris Kramer, Dean James, Tino Jukić, Eus Waayers, Giovanni van Zwam, Julius Dirksen, Tomás Galvez, Pim Saathof, Terence Lantveld, Evert Linthorst, Søren Tengstedt, Robbin Weijenberg, Melle Meulensteen, Yassir Salah Rahmouni, Stefan Ingi Sigurðarson, Oskar Sivertsen, Victor Edvardsen, Mathis Suray, Richonell Margaret, Thibo Baeten, Erik Flataker, Dani Tijman, Ofosu Boakye. [12]

### N.E.C. Nijmegen
**Jogadores listados:** Gonzalo Crettaz, Nikolas Polster, Freek Entius, Joep Geneste, Philippe Sandler, Perr Schuurs, Mitchel Bakker, Bram Nuytinck, Tobias Storm, Ahmetcan Kaplan, Deveron Fonville, Yassin Moslih, Almugera Kabar, Gabriel Brás, Darko Nejašmić, Isak Hansen-Aarøen, Tjaronn Chery, Willum Willumsson, Dennis Geiger, Noé Lebreton, Sam de Laat, Jamiro Monteiro, Merijn van de Wiel, Emre Mor, Dušan Tadić, Kaj Sierhuis, Adam Tahaui, Bryan Linssen, Kevin Kers, Ayodele Thomas, Clément Bischoff. [13]

### PEC Zwolle
**Jogadores listados:** Jasper Schendelaar, Tom de Graaff, Duke Verduin, Torben Bos, Sherel Floranus, Olivier Aertssen, Tijs Velthuis, Jan Bürger, Nick Viergever, Simon Graves, Damian van der Haar, Milan Westerhuis, Dylan Ruward, Tobias Sommer, Odysseus Velanas, Gabriel Reiziger, Thijs Oosting, Jadiel Pereira da Gama, Ryan Thomas, Nick Fichtinger, Gilles van der Wal, Givaro Rahajaan, Filip Krastev, Younes Namli, Elias Sørensen, Koen Kostons, Dylan Mbayo, Sydney van Hooijdonk, Ibrahim Cissoko. [14]

### PSV
**Jogadores listados:** Nick Olij, Matěj Kovář, Khadim Ngom, Tijn Smolenaars, Lutsharel Geertruida, Yarek Gąsiorowski, Armando Obispo, Ryan Flamingo, Sergiño Dest, Mauro Júnior, Kiliann Sildillia, Fabian Merién, Paul Wanner, Filip Kostić, Guus Til, Sven Mijnans, Jerdy Schouten, Kodai Sano, Noah Fernandez, Ayoni Santos, Shuryjano Cornecion, Ivan Perišić, Ruben van Bommel, Ricardo Pepi, Sami Ouaissa, Alassane Pléa, Esmir Bajraktarević, Mikkel Hansen, Dennis Man, Sam Lammers, Amir Bouhamdi. [15]

### SC Cambuur
**Jogadores listados:** Tjalling van Keimpema, Thijs Jansen, Jasper Meijster, Luca Plogmann, Matthijs Kalisvaart, Reen Zandstra, Jorn Berkhout, Ismaël Baouf, Jamal Amofa, Billy van Duijl, Rik Mulders, Lucas Jetten, Morgan Costarelli, Amar Bakkati, Buddy Vogelzang, Louka Vanderbruggen, Kick Eerhart, Devid Bouah, Wout Asselman, Nicky Souren, Rafik el Arguioui, Ethan Apkakou, Wiebe van der Heide, Daan Visser, Mathieu Maertens, Wessel van der Goot, Damian Westerhof, Sami Bouhoudane, Skye Vink, Ilyes Hamache, Nicolas Binder, Fabian Kvam, Danyello Look, Wiebe Kooistra, Iwan Henstra, Jason Çeka. [16]

### sc Heerenveen
**Jogadores listados:** Sten Kremers, Bernt Klaverboer, Timo Schreuder, Andries Noppert, Mees Hilgers, Maas Willemsen, Sam Kersten, Mats Egbring, Vasilios Zagaritis, Darling Bladi, Hristiyan Petrov, Jimte Scholten, Oliver Braude, Dirk Proper, Maxence Rivera, Ringo Meerveld, Levi Smans, Marcus Linday, Nolhan Courtens, Anass Bouziane, Dylan Vente, Luca Oyen, Roberts Uldriķis, Jacob Trenskow, Marko Farji, Lanroy Machine, Kirayno Schaken. [17]

### Sparta Rotterdam
**Jogadores listados:** Rik Suur, Pascal Kuiper, Duncan Lindhout, Michael Brouwer, Filip Bednarek, Bas Kuipers, Teo Quintero, Lushendry Martes, Boyd Reith, Rolando Martins Indi, Giannino Vianello, Marvin Young, Nick Verschuren, Max de Ligt, Isaac Babadi, Julian Baas, Jens Toornstra, Alwande Roaldsøy, Robin van Cruijsen, Cédric Hatenboer, Mitchell van Bergen, Andrej Kostić, Casper Terho, Milan Zonneveld, Shunsuke Mito, Joel Ideho. [18]

### Telstar
**Jogadores listados:** Ronald Koeman Jr., Finn Mulder, Daan Reiziger, Jeff Hardeveld, Gerald Alders, Abdelnour Soualhia, Nigel Ogidi Nwankwo, Sem Valk, Gabrielle Caschili, Rojendro Oudsten, Marvin Peersman, Prince Aning, Isaiah Ahmed, Tyrone Owusu, Harrie Kuster, Nils Rossen, Noach Shenkman, Rui Mendes, Emirhan Demircan, Jelani Seedorf, Nökkvi Þórisson, Fabiano Rust, Fofin Turay, Patrick Brouwer, Arjany Martha. [19]

### Willem II
**Jogadores listados:** Thomas Didillon-Hödl, Wouter van der Steen, Maxime Delanghe, Karst de Leeuw, Tygo Kotte, Alessandro Ciranni, Finn Stam, Justin Hoogma, Hidde ter Avest, Jens Mathijsen, Amine Et-Taïbi, Maxim Dekker, Nathan Tjoe-A-On, Mats Lemmens, Calvin Twigt, Kasper Boogaard, Jari Schuurman, Anass Zarrouk, Uriel van Aalst, Thijs Muller, Per van Loon, Vito van Crooij, Amine Lachkar, Divano Iglesias, S. Wermenbol, Julian van Esdonk, Ismael Mouhoul, Tonny Vilhena, Jaden Slory, Devin Haen, Armin Culum, Chidozie Obi, Thomas Verheydt, Luca Maal, Eser Gürbüz. [20]

## Referências

[1]: https://eredivisie.nl/nieuws/definitief-programma-2026-27/ "Programa definitivo Eredivisie 2026/27 e lista oficial de clubes"
[2]: https://eredivisie.nl/nieuws/data-en-tijden-najaar-vriendenloterij-eredivisie-bekendgemaakt/ "Calendário do outono 2026"
[3]: https://eredivisie.nl/competitie/clubs/ado-den-haag/ "Elenco ADO Den Haag"
[4]: https://eredivisie.nl/competitie/clubs/ajax/ "Elenco Ajax"
[5]: https://eredivisie.nl/competitie/clubs/az/ "Elenco AZ"
[6]: https://eredivisie.nl/competitie/clubs/excelsior/ "Elenco Excelsior Rotterdam"
[7]: https://eredivisie.nl/competitie/clubs/fc-groningen/ "Elenco FC Groningen"
[8]: https://eredivisie.nl/competitie/clubs/fc-twente/ "Elenco FC Twente"
[9]: https://eredivisie.nl/competitie/clubs/fc-utrecht/ "Elenco FC Utrecht"
[10]: https://eredivisie.nl/competitie/clubs/feyenoord/ "Elenco Feyenoord"
[11]: https://eredivisie.nl/competitie/clubs/fortuna-sittard/ "Elenco Fortuna Sittard"
[12]: https://eredivisie.nl/competitie/clubs/go-ahead-eagles/ "Elenco Go Ahead Eagles"
[13]: https://eredivisie.nl/competitie/clubs/nec/ "Elenco N.E.C. Nijmegen"
[14]: https://eredivisie.nl/competitie/clubs/pec-zwolle/ "Elenco PEC Zwolle"
[15]: https://eredivisie.nl/competitie/clubs/psv/ "Elenco PSV"
[16]: https://eredivisie.nl/competitie/clubs/cambuur/ "Elenco SC Cambuur"
[17]: https://eredivisie.nl/competitie/clubs/sc-heerenveen/ "Elenco sc Heerenveen"
[18]: https://eredivisie.nl/competitie/clubs/sparta-rotterdam/ "Elenco Sparta Rotterdam"
[19]: https://eredivisie.nl/competitie/clubs/telstar/ "Elenco Telstar"
[20]: https://eredivisie.nl/competitie/clubs/willem-ii/ "Elenco Willem II"
