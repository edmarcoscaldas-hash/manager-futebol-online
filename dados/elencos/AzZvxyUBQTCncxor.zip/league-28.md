# Serie B — Itália

- **País:** Itália
- **Campeonato:** Serie BKT
- **Divisão:** 2ª divisão
- **Temporada/status:** 2026/27 em andamento; calendário oficial já enumera 38 rodadas e em 12/11/2026 está em pausa internacional de 9–17 novembro. A liga indicou início em 21/22 agosto de 2026 e encerramento entre 14–16 maio 2027.
- **Cobertura:** usei a lista nominal oficial “Lista giocatori Stagione 2026/2027” da Lega B, agrupada por equipe. São jogadores registrados/listados pela liga naquela temporada, não uma lista definitiva de todo atleta sob contrato; o cadastro dinâmico pode mudar e nomes não listados não foram inferidos. Não usei elencos de anos anteriores nem comissão técnica.

## Clubes e jogadores

### Arezzo

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Alessandro Arena, Christian Bucchi, Andrea Cagnano, Alessandro Capello, Alberto Cerri, Luca Chierico, Marco Chiosa, Pietro Cianci, Gianmarco Cipriani, Lorenzo Coccia, Mauro Coppolaro, Filippo De Col, Matías Emilio Casarosa, Gian Marco Ferrari, Amoris Galli, Flavio Giampieretti, Matteo Gilli, Gennaro Iaccarino, Julián Illanes Minucci, Artur Ioniţă, Giuseppe Kevin Leone, Federico Malvestuto, Davide Mancini, Leonardo Mancuso, Aleandro Adalberto Manes, Shaka Mawuli Eklu, Marlon Mena Martínez, Patrick Moreschini, Alessandro Nunziante, Marco Olivieri, Emiliano Pattarello, Mario Ravasio, Alessandro Renzi, Samuele Righetti, Mattia Sala, Andrea Seculin, Samuele Sussi, Camillo Tavernelli, Fabio Tito, Luca Trombini, Muhamed Serifo Varela Djamanca, Mattia Viviani, Francesco Șerban.

### Ascoli

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Gennaro Acampora, Giuseppe Agostinone, Manuel Alagna, Davide Barosi, Don José Henricus Bolsius, Matteo Luigi Brunori Sandri, Rok Bržan, Mohammed Amine Chakir, Luca Conti, Giovanni Corradini, Gian Marco Crespi, Marcos Curado, Simone D'Uffizi, Samuele Damiani, Giacomo De Pieri, Ferdinando Del Sole, Rocco Dente, Filippo Diamanti, Federico Agustín Gattoni, Gabriele Gori, Kevin Gorica, Abdoul Razack Guiébré, Luca Lo Scalzo, Damiano Menna, Tommaso Pantaleo Milanese, Manuel Nicoletti, Andrea Oliveri, Sergiu Perciun, Matteo Raffaelli, Matteo Ricci, Nicholas Rizzo, Antonio Russo, Andrea Silipo, Francesco Giuseppe Tomei, Lorenzo Venuti, Samuele Vitale.

### Avellino

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Emanuele Manolo Pio Adamo, Thomas Berenbruch, Michele Besaggio, Tommaso Biasci, Tommaso Cancellotti, Walid Cheddira, Mattia Della Rocca, Alessandro Di Bitonto, Luca Di Maggio, Sebastiano Vlad Di Paolo, Patrick Enrici, Giacomo Faticanti, Andrea Favilli, Daniel Fila, Alessandro Fontanarosa, Antony Iannarilli, Roberto Insigne, Armando Izzo, Francesco Maisto, Tommaso Martinelli, Filippo Missori, Brando Moruzzi, Alessandro Nesta, Martin Njøten Palumbo, Luca Palmiero, Luca Pandolfi, Cosimo Francesco Patierno, Raffaele Russo, Marco Sala, Jacopo Sassi, Dimitris Sounas, Michael Venturi, Lorenco Šimić.

### Benevento

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Vincenzo Battista, Pietro Beruatto, Luca Caldirola, Raffaele Cantisani, Lorenzo Carfora, Raffaele Celia, Michele Cerqua, Luigi Cherubini, Christian Dalle Mura, Matteo Del Gaudio, Matteo Donatiello, Manuel Esposito, Antonio Ferrara, Antonio Floro Flores, Logan Gaspar Queiroz de Freitas, Marco Giugliano, Christian Kouan Oulaï, Davide Lamesta, Mattia Maita, Mattia Mannini, Guglielmo Mignani, David Chidozie Okereke, Claudio Panzarino, Edoardo Pierozzi, Antonio Prisco, Giacomo Ricci, Raffaele Romano, Pietro Saio, Francesco Paolo Salvemini, Emanuele Schimmenti, Stefano Scognamillo, Leonardo Sernicola, Antonis Siatounis, Pier Luigi Simonetti, Cheikh Alioune Sylla, Angelo Talia, Marco Tumminello, Gianmarco Vannucchi, Simone Verdi.

### Carrarese

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Fabio Abiuso, Giulio Baroncelli, Niccolò Belloni, Mattia Bencaster, Nicholas Bonfanti, Matthias Braunöder, Giulio Cianti, Gabriele Cioffi, Elhadj Moustapha Cisse, Nicolò Cudrig, Gonçalo do Lago Pontes Esteves, Mattia Finotto, Vincenzo Fiorillo, Giovanni Gabriele Garofani, Tommaso Guercio, Yanis Khafi, Filippo Liberati, Bruno Loureiro Batista, Tommaso Macchioni, Giacomo Marconi, Jacopo Martini, Filippo Melegoni, Colin Obasanya Dagba, Filippo Oliana, Giuseppe Padovano, Guido Pagliuca, Gabriele Parlanti, Pietro Pinelli, Semuel Pizzignacco, Nicola Ravaglia, Filippo Reale, Niccolò Romagnoli, Lorenzo Romani, Jonas Jakob Rouhi, Tommaso Rubino, Fabio Andrea Ruggeri, Nicolás Adrián Schiavi, Luka Topalović, David Vujevic.

### Catanzaro

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Salvatore Accursi, Cristian Antonio Agnelli, Gabriele Alesi, Matias Antonini Lui, Gabriel Arditi, Ervin Bashi, Edoardo Borrelli, Nicolò Buso, Antonio Candela, Federico Cassa, Marco D'Alessandro, Federico Di Francesco, Mehdi Emile Dorval, Ruggero Frosinini, Alejo Garnica, Samuel Giovane, Giorgio Gorgone, Pietro Iemmello, Marco Imperiale, N'Dri Philippe Koffi, Vito Lorenzo Madia, Christian Marietta, Michele Mignani, Nicola Mosti, Simone Pafundi, Emanuele Pecorino, Jacopo Petriccione, Mirko Pigliacelli, Andrej Pogačar, Niccolò Postiglione, Francesco Reita, Marco Ruggero, Sayha Seha, Raul Tassoni, Franck Tchaouna, Franky Tchaouna, Solomon Tãkeacãbã Loubao, Bruno Verrengia, Giovanni Volpe.

### Cesena

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Filippo Bertaccini, Dimitri Bisoli, Emil Bohinen, Maat Daniel Caprini, Enea Casadei, Matteo Casadei, Andrea Ciofi, Luca D'Andrea, Marco Dalla Vecchia, Antonio David, Alessandro Debenedetti, Alessandro Diamanti, Xavello Djave Lyam Druiventak, Luca Ferretti, Antonio Fiori, Niccolò Fontana, Gianluca Frabotta, Matteo Francesconi, Filippo Galvagno, Jacopo Gelli, Simone Gianfanti, Matteo Guidi, Mihajlo Ilić, Jonathan Lee Klinsmann, Matteo Lontani, Vittorio Magni, Massimiliano Mangraviti, Tommaso Mazzi, Mark Natta, Riccardo Pagano, Matteo Piacentini, Simone Pieraccini, Maurizio Junior Rossetti, Luca Schirone, Cristian Shpendi, Alessandro Siano, Simone Vergassola, Ibrahima Wade Papa, Davide Zamagni.

### Cremonese

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Federico Agazzi, Tommaso Barbieri, Ronie Barros Cabezas, Federico Baschirotto, Tommaso Berti, Matteo Bianchetti, Filippo Rino Bignamini, Federico Bonazzoli, Eddy Cabianca, Michele Collocolo, Francesco Conti, Manuel De Luca, Salvatore Elia, Marco Festa, Andrea Fulignati, Fabio Gerli, David Gharabaghi Stückler, Marco Giampaolo, Alberto Grassi, Gabriel Herzuah, Riccardo Liberali, Adrian Lickūnas, Adin Ličina, Dachi Lordkipanidze, Simone Lottici Tessadri, Sebastiano Luperto, Simone Marsi, Fellipe Jack Ozilio Moreira Pacheco, Marco Nasti, Fabio Pecchia, Giuseppe Pezzella, Simone Pontisso, Yuri Rocchetti, Morten Thorsby, Jari Vandeputte, Riccardo Villa, Alessandro Vogliacco, Milan Đurić.

### Empoli

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Matteo Andreoletti, Diego Antonini, Samsondeen Babalola, Filippo Bandinelli, Luca Belardinelli, Dawid Bembnista, Roberto Berizzi, Flavio Junior Bianchi, Edoardo Biondini, Federico Brancolini, Danilo Busiello, Thomas Campaniello, Cristian Cauz, Lars Joseph Ceesay, Niccolò Corrado, Marco Curto, Duccio Degli Innocenti, Lapo Deli, Filippo Distefano, Matteo Gerard Egan, Emiliano Filippis, Mattia Huqi, Gabriele Indragoli, Luca Magnino, Florijan Mežnar, Salvatore Monaco, Andrea Orlandi, Samuele Perisan, Bohdan Popov, Simone Romagnoli, Tommaso Rugani, Edoardo Saporiti, Jacopo Seghetti, Stiven Shpendi, Andrea Sodero, Nazzareno Tarantino, Samuele Tavanti, Lorenzo Tosto, Gerard Yepes Laut, Karim Zedadka.

### H. Verona

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Mel Rubén Yoris Akalé, Caleb Ansah Ekuban, Marco Baroni, Leorat Bega, Rafik Belghali, Antoine Joseph Emmanuel Bernede, Domagoj Bradarić, Nicolò Calabrese, Salvatore Cerbone, Fallou Cham, Mattia Compagnon, Juan Manuel Cruz, Paweł Marek Dawidowicz, Davide De Battisti, Andrias Edmundsson, Abdoulrahmane Harroui, Edoardo Iannoni, Grigoris Kastanos, Seid Korač, Andréa Paul Le Borgne, Nicola Leali, Nunzio Lella, Charlys Matheus Lima Pontes, Daniel Fernando Mosquera Bonilla, Samuele Mulattieri, Daniel Oladele Akinbiyi Oyegoke, Simone Perilli, Arthur Rampineli Borghi, Dailon Rocha Livramento do Rosário, Amin Sarr, Suat Serdar, Kacper Sezonienko, Tobias Slotsager, Tomáš Suslov, Martin Sønder Frese, Noe Mael Tagne, Giacomo Toniolo, Ioan Vermeșan, Gabriele Zappa.

### Juve Stabia

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Cristian Andreoni, Federico Artioli, Matteo Baldi, Thomas Battistella, Cesare Beggi, Marco Bellich, Davide Bettella, Pietro Boer, Davide Buglio, Luigi Caccavo, Leonardo Candellone, Francesco D'Amore, Pietro De Giorgio, Antonio Di Nardo, Terrence John Douglas, Francesco Gallea Beidi, Nermin Karić, Justin Kumi, Edoardo Lonardo, Alessandro Louati, Tommaso Maggioni, Fabio Maistro, Saná Eusébio Mango Fernandes, Marco Meli, Gregorio Morachioli, Nicola Patanè, Daniel Perin, Christian Pierobon, Nicola Pietrangeli, Enrico Piovanello, Kevin Piscopo, Manuel Ricciardi, Romeo Sandrucci, Giulio Scuderi, Giuseppe Sibilli, Alessandro Signorini, Emanuele Torrasi, Paolo Vismara, Ante Vuković.

### L.R. Vicenza

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Filippo Alessio, Fabrizio Bagheria, Mattia Basso, Alessandro Bellemo, Nicolò Brighenti, Ettore Broggian, Lorenzo Caferri, Filippo Carobbio, Marco Carraro, Michele Cavion, Tommaso Corazza, Filippo Costa, Giuseppe Cuomo, Matteo Della Morte, Riccardo Gagno, Fabio Gallo, Maxime Jean Roberto Leverbe, Riccardo Marchizza, Silvio Merkaj, Gabriele Moncini, Claudio Morra, Andrea Papetti, Giulio Pellizzari, Alessandro Pietrelli, Armand Rada, Nicola Rauti, Thomas Sandon, Raul Talarico, Elia Tantalocchi, Frank Cédric Tsadjout, Mattia Valoti, Matteo Vescovi, Loris Zonta.

### Mantova

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Yassin Banna, Francesco Bardi, Badr Bayou, Fahem Benssouna Ali Benaïssa-Yahia, Davide Bragantini, Ismael Cajazzo, Alessio Castellini, Stefano Cella, Federico Chinetti, Tommaso Del Lungo, Giacomo Fedel, Alessandro Gamberini, Manuel Gasparini, Luca Gemello, Ettore Gliozzi, Lorenzo Ignacchiti, Rareş Andrei Ilie, Jean-Pierre Longonda Itamba Mboyo, Sambaly Keïta, Rachid Kouda, Eman Košpo, Žan Majer, Cristian Marai, Andrea Massolini, Davis Mensah, Andrea Meroni, Francesco Antonio Modesto, Flavio Paoletti, Nicolò Radaelli, Francesco Ruocco, Jonathan Silva Pertinhes, Matteo Spinaccè, Bodin Tomašević, Simone Trimboli, Filippo Vesentini, Vanja Vlahović, David Wieser.

### Modena

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Davide Adorni, Giuseppe Ambrosino Di Bruttopilo, Pietro Arnaboldi, Luca Bacchin, Andrea Belotti, Gady-Pierre Beyuku Bowutankoyi, Alessandro Bianco, Kleis Bozhanaj, Gastn Brugman Duarte, Antonio Rubén Cannoni Miranda, Giuseppe Caso, Leandro Chichizola, Leonardo Consiglio, Paulo Daniel Dentello Azzi, Treasure Egharevba, Tito Maria Fabbri, Francesco Folino, Brando Fontana, Daniele Galloppa, Antonio Imputato, Abdullah Laidani, Pedro Manuel Lobo Peixoto Mineiro Mendes, Joris Manquant, Andrea Maran, Daniele Montevago, Steven Folly Nador, Bryant Nieling, Martino Odero, Giacomo Olzer, Diego Ronco, Simone Santoro, Wisdom Serebour Acquah, Alessandro Sersanti, Daniel Tonoli, Francesco Filippo Zampano, Stênio Zanetti Toledo.

### Padova

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Gabriele Artistico, Jacopo Bacci, Antonio Barreca, Tommaso Bordoni, Mattia Bortolussi, Cristian Buonaiuto, Nicola Antonio Calabro, Alessandro Julian Capelli, Gianluca Caprari, Lorenzo Carissoni, Matteo Cocchi, Alessandro Dellavalle, Francesco Di Mariano, Carlo Faedo, Giulio Favale, Pietro Fusi, Nicolas Galazzi, Giovanni Giunti, Kevin Lasagna, Matteo Lovato, Diego Marcolini, Luca Moro, Louis Moise Nascimento Mouquet, Christian Diego Pastina, Marco Pompetti, Simone Scaglia, Alessandro Seghetti, Filippo Lorenzo Sgarbi, Enrico Silletti, Alessandro Sorrentino, Jonnathan Kevin Varas Marcillo, Luca Zanimacchia, Emanuele Zuelli.

### Palermo

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Tommaso Augello, Hernani Azevedo Júnior, Nils Balagušs, Francesco Balsamo, Mattia Bani, Federico Barba, Alexis Blin, Andrea Bozzolan, Tommaso Cassandro, Pietro Ceccaroni, Paolo Cozzi, Maurizio D'Angelo, Nahuel Estévez Álvarez, Mattia Fortin, Alessandro Gabrielloni, Claudio Amarildo Gomes, Emanuel Quartsin Gyasi, Filippo Inzaghi, Jesse Pekka Joronen, Jérémy Le Douaron, Giangiacomo Magnani, Luca Mazzitelli, Manfredi Nespola, Antonio Palumbo, Patryk Peda, Mattia Perin, Niccolò Pierozzi, Joel Julius Ilmari Pohjanpalo, Filippo Ranocchia, Jacopo Segre, Gabriel Tadeu Strefezza Rebelato, Dennis Tørset Johnsen, Dominic Vavassori.

### Pisa

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Samuele Angori, Brando Bettazzi, Paolo Bianco, Louis Thomas Buffon, Arturo Calabresi, Simone Canestrelli, Antonio Aldo Caracciolo, Alessandro Confente, Niccolò Conti, Francesco Coppola, Omar Correia, Daniel Tyrell Denoon, Tomás do Lago Pontes Esteves, Ichem Ferrah, Jacopo Frosali, Tommaso Guizzo, Malthe Højholt, Jeremy Kandje Mbambi, Giuseppe Leone, Leonardo Loria, Felipe Ignacio Loyola Olea, Mehdi Pascal Marcel Léris, Antonio Manicone, Tommaso Simone Marras, Stefano Moreo, Andrea Petagna, Rosen Petkov Bozhinov, Gabriele Piccinini, Filippo Maria Pittarello, Andrea Primasso, Emanuele Rao, Simone Scuffet, Mattéo Tramoni, Mateus Henrique Vanzelli Lusuardi, İsak Vural, Henrik Wendel Meister, Simone Zanon, Adrian Šemper.

### Sampdoria

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Oliver Abildgaard Nielsen, Ștefan Mateo Amarandei, Tjaš Begić, Manuel Cicconi, Francesco Conti, Bernardo Corradi, Leonardo Cosi, Luca D'Angelo, Filippo Delli Carri, Fabio Depaoli, Alessandro Di Pardo, Karim Diop, Gerald Donegà, Salvatore Esposito, Alex Ferrari, Jordan Ferri, Giuseppe Forte, Stefan Gartenmann, Simone Ghidotti, Liam Henderson, Lorenzo Insigne, Yann Dorgelès Isaac Karamoh, Antonino La Gumina, Tobias Lauritsen, Antoine Makoumbou, Samuele Massolo, Melingo Kevin Mbabu, Bjorn Thomas Meijer, Lorenzo Mezzotero, Noà Mondani, Andrey Nikolaev Krastev, Lorenzo Paratici, Federico Piermattei, Luca Ravanelli, Alessandro Pio Riccio, Leo Rodella, Nicholas Scardigno, Nikola Sekulov, Danel Sinani, Gennaro Tutino, Yari Verschaeren, Peter Vindahl Jensen, Joao Visentin, Mattia Viti.

### Südtirol

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Lorenzo Anghelè, Bjarki Steinn Bjarkason, Riccardo Bocchini, Dhirar Brik, Rareş Cătălin Burnete, Daniele Casiraghi, Federico Davi, Simone Davì, Hamza El Kaouakibi, Vasco Rafael Fortes Lopes, Marco Romano Frigerio, Andrea Giorgini, Marco Iuliano, Tommaso Laureti, Jannik Leitner, Kenny Meddy Mixtur, Salvatore Andrea Molina, Alvin Obinna Okoro, Mattia Pellini, Alessandro Plizzari, Lukas Ploner, Davide Possanzini, Niklas Anton Juhana Pyyhtiä, Fabio Rispoli, Elias Schrott, Giacomo Stabile, Riccardo Stivanello, Fabian Tait, Simone Tronchin, Rok Vadjunec, Marco Varnier, Aljoša Vasić, Davide Veroli, Frédéric Shtjefan Veseli, Kevin Zeroli.

### V. Entella

**Fonte nominal:** [Lista oficial de jogadores da Lega B — temporada 2026/2027](https://www.legab.it/seriebkt/giocatori).

Mattia Alborghetti, Tommaso Annoni, Davide Bariti, Leonardo Benedetti, Matteo Casarotto, Andrea Chiappella, Simone Colombi, Giacomo Corona, Gabriele Costa, Luigi Cuppone, Francesco D'Alterio, Federico Del Frate, Stefano Di Mario, Lucas Martello Felippe Nascimento, Francesco Forte, Andrea Franzoni, Bernat Guiu Vilanova, Marwane Kritta, Ivan Marconi, Francesco Mezzoni, Mattia Motolese, Luca Parodi, Nicolas Previtali, Niccolò Squizzato, Matteo Tassara, Mattia Tirelli, Andrea Tiritiello, Edoardo Torrielli, Riccardo Turicchia, Mattia Valori, Luca Vignali.

## Observações de cobertura

A própria página da liga identifica expressamente a temporada 2026/2027 e apresenta linhas individuais com nome, equipe e estatísticas da competição. A lista é dinâmica e contém jogadores que podem ter zero partidas; por isso, ela comprova listagem/associação na temporada, não necessariamente inscrição regulatória completa ou disponibilidade atual. Os 20 participantes foram verificados no seletor da página oficial do calendário.

## Referências

- [Calendário oficial Serie BKT 2026/27](https://www.legab.it/seriebkt/calendario) — temporada, participantes e rodada corrente.
- [Datas oficiais Serie BKT 2026/27](https://www.legab.it/news/ecco-le-date-della-serie-bkt-2026-2027) — datas de início/fim e pausa de novembro.
- [Lista oficial de jogadores 2026/27](https://www.legab.it/seriebkt/giocatori) — jogadores agrupados por equipe.
