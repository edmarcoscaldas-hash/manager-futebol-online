# Ligue 1 McDonald’s — França, 2026/27

**País:** França  
**Campeonato:** Ligue 1 McDonald’s  
**Divisão:** 1ª divisão masculina (Ligue 1)  
**Status em 12 de novembro de 2026:** temporada em curso. A LFP informa que começou em 21 de agosto de 2026 e termina em 29 de maio de 2027; a rodada 10 foi disputada no fim de semana de 7 de novembro. [1]

## Escopo e cobertura dos elencos

A LFP relaciona 18 participantes, e o calendário oficial identifica os confrontos da primeira rodada para os 18. [1] [2] As listas abaixo não representam elencos completos: registrei apenas nomes que apareceram diretamente nas páginas de elenco Transfermarkt selecionadas para 2026/27 e cujo conteúdo foi disponibilizado na consulta. A extração dessas páginas não expôs todas as linhas do elenco em todas as consultas; por isso, não completei nomes por memória nem com informação de temporada anterior.

Foram localizadas e abertas páginas de elenco 2026/27 para nove clubes (PSG, Monaco, Strasbourg, Lyon, Rennes, Lille, Lens, Paris FC e Marseille). Para esses, abaixo estão apenas os nomes visíveis no conteúdo consultado, não uma garantia de elenco integral. Para os outros nove clubes, a fonte pública consultada permitiu confirmar participação, mas não obter nesta pesquisa uma relação individual verificável de jogadores. A página agregadora WorldFootball consultada lista apenas 17 equipes e diverge do calendário oficial da LFP; não foi usada para decidir a lista de participantes. [3]

## Clubes participantes e jogadores publicamente verificáveis

### Angers SCO

**Jogadores:** não listado nesta pesquisa.  
**Cobertura:** participação confirmada pela LFP; página de elenco individual 2026/27 não coberta. [1] [2]

### AJ Auxerre

**Jogadores:** não listado nesta pesquisa.  
**Cobertura:** participação confirmada pela LFP; página de elenco individual 2026/27 não coberta. [1] [2]

### AS Monaco

**Jogadores identificados na página 2026/27 consultada:** Philipp Köhn, Lukas Hradecky, Jules Stawiecki, Christian Mawissa, Sadibou Sané, Mohammed Salisu, Eric Dier, Samuel Nibombe, Nazinho, Vanderson, Jordan Teze, Denis Zakaria, Lamine Camara, Mamadou Coulibaly, Pape Cabral, Edan Diop, Anis Soubeir, Aleksandr Golovin, Stanis Idumbo, Mathys Detourbet.  
**Cobertura:** lista parcial; página do elenco marcada como temporada 26/27. [4]

### Stade Brestois 29

**Jogadores:** não listado nesta pesquisa.  
**Cobertura:** participação confirmada pela LFP; página de elenco individual 2026/27 não coberta. [1] [2]

### Le Havre AC

**Jogadores:** não listado nesta pesquisa.  
**Cobertura:** participação confirmada pela LFP; página de elenco individual 2026/27 não coberta. [1] [2]

### RC Lens

**Jogadores identificados na página 2026/27 consultada:** Robin Risser, Mathieu Gorgelin, Régis Gurtner, Ilan Jourdren, Ismaëlo Ganiou, Samson Baidoo, Jean-Clair Todibo, Kyllian Antonio, Nidal Celik, Souleymane Sagnan, Maik Nawrocki, Jonathan Gradit, Matthieu Udol, Jhoanner Chávez, Saud Abdulhamid, Ruben Aguilar, Yacine Titraoui, Andrija Bulatovic, Michaël Cuisance, Amadou Haidara, Mezian Mesloub.  
**Cobertura:** lista parcial; página do elenco marcada como temporada 26/27. [5]

### LOSC Lille

**Jogadores identificados na página 2026/27 consultada:** Berke Özer, Orlando Gill, Nathan Ngoy, Alexsandro, Isaac Cossier, Tanguy Nianzou, Romain Perraud, Calvin Verdonk, Tiago Santos, Loun Srdanovic, Maxima Goffi, Ngal'ayel Mukau, Nabil Bentaleb, Benjamin André, Maurits Kjærgaard, Hákon Arnar Haraldsson, Başar Önal, Osame Sahraoui, Soriba Diaoune, Tiago Morais.  
**Cobertura:** lista parcial; página do elenco marcada como temporada 26/27. [6]

### OGC Nice

**Jogadores:** não listado nesta pesquisa.  
**Cobertura:** participação confirmada pela LFP; página de elenco individual 2026/27 não coberta. [1] [2]

### Olympique Lyonnais

**Jogadores identificados na página 2026/27 consultada:** Dominik Greif, Rémy Descamps, Justin Bengui, Lassine Diarra, Moussa Niakhaté, Ruben Kluivert, Felix Bacher, Noham Kamara, Clinton Mata, Abner, Nicolás Tagliafico, Mohamed Ouédraogo, Zachary Athekame, Steeve Kango, Tyler Morton, Tanner Tessmann, Paul Akouokou, Mads Bidstrup, Khalis Merah, Corentin Tolisso, Pavel Sulc, Noah Nartey.  
**Cobertura:** lista parcial; página do elenco marcada como temporada 26/27. [7]

### Olympique de Marseille

**Jogadores identificados na página 2026/27 consultada:** Jeffrey de Lange, Théo Vermot, Jelle Van Neck, Nayef Aguerd, CJ Egan-Riley, Bamo Meïté, Derek Cornelius, Emerson, Ulisses Garcia, Alexi Koum, Timothy Weah, Kelyann Bezahaf, Pierre-Emile Højbjerg, Tochukwu Nnadi, Geoffrey Kondogbia, Nouhoum Kamissoko, Himad Abdelli, Angel Gomes, Faris Moumbagna.  
**Cobertura:** lista parcial; página do elenco marcada como temporada 26/27. [8]

### Paris FC

**Jogadores identificados na página 2026/27 consultada:** Obed Nkambadio, Kevin Trapp, Diego Coppola, Moustapha Mbow, Otávio, Samir Chergui, Yoan Koré, Nhoa Sangui, Emmanuel Mbemba, Thibault De Smet, Adama Camara, Hamari Traoré, Maxime Lopez, Pierre Lees-Melou, Patrick Zabi, Rudy Matondo, Vincent Marchetti, Pablo Pagis.  
**Cobertura:** lista parcial; página do elenco marcada como temporada 26/27. [9]

### Paris Saint-Germain

**Jogadores identificados na página 2026/27 consultada:** Matvey Safonov, Lucas Chevalier, Alessandro Longoni, Willian Pacho, Ilya Zabarnyi, Marquinhos, Lucas Beraldo, Nuno Mendes, Lucas Hernández, Lucas Digne, Achraf Hakimi, David Boly, Vitinha, João Neves, Warren Zaïre-Emery, Senny Mayulu, Fabián Ruiz, Dro Fernández, Khvicha Kvaratskhelia, Mika Godts, Quentin Ndjantou, Désiré Doué, Maghnes Akliouche.  
**Cobertura:** lista parcial; página do elenco marcada como temporada 26/27. [10]

### Stade Rennais FC

**Jogadores identificados na página 2026/27 consultada:** Brice Samba, Nicolas Lemaître, Kilian Belazzoug, Charlie Cresswell, Abdelhamid Ait Boudlal, Anthony Rouault, Gonçalo Oliveira, Quentin Merlin, Mahamadou Nagida, Przemyslaw Frankowski, Bryan Reynolds, Mahdi Camara, Djaoui Cissé, Valentin Rongier, Adrien Thomasson, Ludovic Blas, Sebastian Szymański, Ayanda Sishuba, Henrick Do Marcolino, Issa Soumaré, Mousa Al-Tamari.  
**Cobertura:** lista parcial; página do elenco marcada como temporada 26/27. [11]

### RC Strasbourg Alsace

**Jogadores identificados na página 2026/27 consultada:** Filip Jørgensen, Milosz Piekutowski, Karim Coulibaly, Ismaël Doukouré, Lucas Høgsberg, Jeyland Mitchell, Hermann Malonga, Oso, Mateo Del Blanco, Genesis Antwi, Dário Essugo, Diogo Sousa, Maxi Oyedele, Samir El Mourabet, Pape Demba Diop, Sékou Mara.  
**Cobertura:** lista parcial; página do elenco marcada como temporada 26/27. [12]

### Toulouse FC

**Jogadores:** não listado nesta pesquisa.  
**Cobertura:** participação confirmada pela LFP; página de elenco individual 2026/27 não coberta. [1] [2]

### FC Lorient

**Jogadores:** não listado nesta pesquisa.  
**Cobertura:** participação confirmada pela LFP; página de elenco individual 2026/27 não coberta. [1] [2]

### ESTAC Troyes

**Jogadores:** não listado nesta pesquisa.  
**Cobertura:** participação confirmada pela LFP; página de elenco individual 2026/27 não coberta. [1] [2]

### Le Mans FC

**Jogadores:** não listado nesta pesquisa.  
**Cobertura:** participação confirmada pela LFP; página de elenco individual 2026/27 não coberta. [1] [2]

## Referências

[1]: https://ligue1.com/en/articles/l1_article_5292-the-2026-27-ligue-1-mcdonald-s-calendar-is-released "Calendário e datas oficiais Ligue 1 2026/27"
[2]: https://ligue1.com/en/calendar/ligue1 "Calendário oficial Ligue 1"
[3]: https://www.worldfootball.net/competition/co71/france-ligue-1/teams/ "WorldFootball, equipes Ligue 1"
[4]: https://www.transfermarkt.com/as-monaco/kader/verein/162/saison_id/2026 "AS Monaco, elenco 2026/27"
[5]: https://www.transfermarkt.com/rc-lens/kader/verein/826/saison_id/2026 "RC Lens, elenco 2026/27"
[6]: https://www.transfermarkt.com/losc-lille/kader/verein/1082/saison_id/2026 "LOSC Lille, elenco 2026/27"
[7]: https://www.transfermarkt.com/olympique-lyon/kader/verein/1041/saison_id/2026 "Olympique Lyonnais, elenco 2026/27"
[8]: https://www.transfermarkt.com/olympique-marseille/kader/verein/244/saison_id/2026 "Olympique de Marseille, elenco 2026/27"
[9]: https://www.transfermarkt.com/paris-fc/kader/verein/10004/saison_id/2026 "Paris FC, elenco 2026/27"
[10]: https://www.transfermarkt.com/fc-paris-saint-germain/kader/verein/583/saison_id/2026 "Paris Saint-Germain, elenco 2026/27"
[11]: https://www.transfermarkt.com/stade-rennais-fc/kader/verein/273/saison_id/2026 "Stade Rennais, elenco 2026/27"
[12]: https://www.transfermarkt.com/rc-strasburg-alsace/kader/verein/667/saison_id/2026 "RC Strasbourg, elenco 2026/27"
