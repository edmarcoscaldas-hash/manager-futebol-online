# Bundesliga 2026/27 — participantes e jogadores publicamente verificáveis

- **País:** Alemanha
- **Campeonato:** Bundesliga
- **Divisão:** 1ª divisão
- **Temporada/status:** 2026/27 em andamento em 12 de novembro de 2026. A página oficial apresenta resultados/agenda da 9ª rodada e uma tabela 2026–27 com 18 clubes e oito partidas computadas por equipe. [1] [2]
- **Cobertura:** A lista de participantes foi verificada integralmente na página oficial de clubes. O diretório oficial consultado mostra elencos explicitamente agrupados por clube, mas a extração pública acessível nesta consulta termina no início da seção Eintracht Frankfurt. Portanto, abaixo estão os nomes da página oficial nos 15 clubes cujo bloco foi integralmente exposto; Frankfurt aparece apenas em parte. Para Mainz 05 e Augsburg não foi possível verificar uma lista de elenco na extração consultada. Não apresento como completos clubes cujos dados não foram disponibilizados, e não usei elencos de temporadas anteriores como substituto. Os nomes seguem a grafia e as categorias de posição do diretório da liga; comissão técnica excluída. [1] [3]

## FC Bayern München

Manuel Neuer, Sven Ulreich, Jannis Bärtl, David Podar-Stiube, Jonas Urbig; Dayot Upamecano, Minjae Kim, Jonathan Tah, Nathaniel Brown, Alphonso Davies, Hiroki Ito, Sacha Boey, Cassiano Kiala, Josip Stanišić; Joshua Kimmich, Tom Bischof, Jamal Musiala, Konrad Laimer, Ismael Saibari, Erblin Osmani, Bara Sapoko Ndiaye, Lennart Karl, Aleksandar Pavlović, David Santos Daiber, Maycon Cardozo; Serge Gnabry, Harry Kane, Luis Díaz, Michael Olise, Bastian Assomo, Noah Codjo-Evora, Tim Binder. [3]

## Borussia Dortmund

Gregor Kobel, Patrick Drewes, Silas Ostrzinski, Alexander Meyer; Waldemar Anton, Nico Schlotterbeck, Ramy Bensebaini, Joane Gadou, Daniel Svensson, Julian Ryerson, Kauã Prates, Filippo Mane, Luca Reggiani; Jobe Bellingham, Felix Nmecha, Carney Chukwuemeka, Ethan Nwaneri, Konstantinos Karetsas, Marcel Sabitzer, Emre Can, Joey Veerman, Justin Lerma, Enzo dos Santos, Giannis Konstantelias, Mussa Kaba; Serhou Guirassy, Maximilian Beier, Fabio Silva, Samuele Inácio, Mathis Albert. [3]

## 1. FC Union Berlin

Frederik Rønnow, Carl Klaus, Matheo Raab, Fritz Gagzow; Felix Uduokhai, Andrik Markgraf, Zeno van den Bosch, Marvin Friedrich, Leopold Querfeld, Tom Rothe, Derrick Köhn, Josip Juranović, Christopher Trimmel, Stanley Nsoki; Aljoscha Kemlein, Rani Khedira, Woo-yeong Jeong, András Schäfer, Janik Haberer, Michel Aebischer, Tim Skarke, Robert Skov, Kastriot Imeri, Duje Slišković, Linus Güther; Oliver Burke, Livan Burcu, Andrej Ilić, Marin Ljubičić, Emmanuel Latte Lath, Mekhi Gray, Julien Friedrich. [3]

## Borussia Mönchengladbach

Moritz Nicolas, Tobias Sippel, Jan Olschowsky, Daniel Batz, Maximilian Neutgens; Fabio Chiarodia, Kevin Diks, Jan Leszczyński, Kō Itakura, Daiki Hashioka, David Herold, Yukhym Konoplia, Lukas Ullrich, Joe Scally, Lion Schweers; Kevin Stöger, Enzo Leopold, Franck Honorat, Florian Neuhaus, Philipp Sander, Jens Castrop, Nicolas Kühn, Robin Hack, Fritz Fleck, Mathieu Nguefack, Wael Mohya, Hugo Bolin, Zento Uno; Isac Lidberg, Tim Kleindienst, Shuto Machino, Josiah Uwakhonye, Iaia Manco Danfa. [3]

## Hamburger SV

Daniel Heuer Fernandes, Sander Tangvik, Elias Lahti, Fernando Dickes; David Møller Wolfe, Zakaria El Ouahdi, Warmed Omari, Jordan Torunarigha, Nicolás Capaldo, Miro Muheim, Sebastiaan Bornauw, Louis Lemke, Joel Agyekum, Shafiq Nandja, Jason Bissi-Mouelle; Bilal Nadir, Martin Adeline, Albert Sambi Lokonga, Immanuël Pherai, Albert Grønbæk, Fábio Vieira, Nicolai Remberg, Kofi Amoako, Kelvin Ojo; Terem Moffi, Yussuf Poulsen, Bakery Jatta, Otto Stange, Patson Daka, Alexander Røssing-Lelesiit. [3]

## 1. FC Köln

Marvin Schwäbe, Ron-Robert Zieler, Martin James, Matthias Köbbing; Joël Schmied, Borna Sosa, Timo Hübers, Gideon Mensah, Jahmai Simpson-Pusey, Luka Lochoshvili, Sebastian Sebulonsen, Rav van den Berg, Jonathan Friemel, Assad Kotya Fofana; Tom Krauß, Ellyes Skhiri, Ísak Jóhannesson, Saïd El Mala, Reigan Heskey, Alessio Castro-Montes, Paul Okon-Engstler, Jan Thielmann, Gil Neves, Fayssal Harchaoui, Linton Maina; Luca Waldschmidt, Ragnar Ache, Imad Rondić, Malek El Mala, Thijs Dallinga, Marius Bülter, Mikey Moore. [3]

## SV Werder Bremen

Karl Hein, Markus Kolke, Alexander Schlager, Stefan Smarkalev; Olivier Deman, Oskar Wójcik, Niklas Stark, Amos Pieper, Mitchell Weiser, Arthur, Moussa Ndiaye, Felix Agu, Marco Friedl, Mick Schmetgens, Luca Höcker, Mats Heitmann, Ramiz Hamouda; Jens Stage, Senne Lynen, Ludovit Reis, Eren Dinkçi, Chuki, Dariusz Stalmach, Skelly Alvero, Darwin Soylu, Arian Römers, Youri Regeer; Keke Topp, Niclas Füllkrug, Justin Njinmah, Marco Grüll, Kenny Emmanuel Quetant, Cedric Itten, Salim Musah, Paul Erevbenagie, Karlo Šimić. [3]

## FC Schalke 04

Loris Karius, Kevin Müller, Johannes Siebeking; Hasan Kuruçay, Timo Becker, Robin Gosens, Adrian Gantenbein, Nikola Katić, Tomáš Kalas, Anton Donkor, Vitalie Becker, Maximilian Wöber, Mertcan Ayhan; Ron Schallenberg, Satoshi Tanaka, Janik Bachmann, Dejan Ljubičić, Soufiane El-Faouzi, Adil Aouchiche, Finn Porath, Junior Dina Ebimbe, Max Grüger, Luca Vozar, Edion Gashi; Hee Chan Hwang, Moussa Sylla, Edin Džeko, Bryan Lasme, Emil Højlund, Kenan Karaman, Junior Adamu, Jean Paul Ndiaye, Zaid Tchibara. [3]

## SV Elversberg

Frank Lehmann, Elias Etringer, Nicolas Kristof, Tim Boss; Nicholas Mickelson, Florian Le Joncour, Luis Seifert, Lukas Pinckert, Lasse Günther, Luca Sirch, Jan Gyamerah, Maximilian Rohr, Felix Keidel; Amara Condé, Maurice Krattenmacher, Łukasz Poręba, Noah Darvich, Raïf Adam, Frederik Schmahl, Lukas Petkov, Tom Zimmerschied, Francis Onyeka; Noel Futkeu, Luca Pfeiffer, Luca Schnellbacher, Cole Campbell, David Mokwa. [3]

## SC Paderborn 07

Markus Schubert, Nahuel Noll, Florian Pruhs; Ruben Müller, Jonah Sticker, Nyamekye Awortwie-Grant, Laurin Curda, Felix Götze, Jano ter Horst, Niklas Mohr, Tjark Scheller, Clemens Lippmann, Marcel Hoffmeier, Tristan Zobel; Santiago Castaneda, Tom Baack, Oliver Batista Meier, Luka Durić, Mattes Hansen, Raphael Obermair, Sebastian Klaas, Laurin Ulrich, Gabriel Vidović, Timur Gayret, Vigo Wernet; Rayan Philippe, Sven Michel, Marvin Pieringer, Albert Millgramm, Steffen Tigges, Stefano Marino, Lasse Eickel, Deniz Zeitler. [3]

## RB Leipzig

Ørjan Nyland, Leopold Zingerle, Maarten Vandevoordt; Abdoul Koné, Maxime Estève, Willi Orbán, Lukas Klostermann, David Raum, Castello Lukeba, Max Finkgräfe, Benjamin Henrichs; Ezechiel Banzuzi, Assan Ouédraogo, Brajan Gruda, Nicolas Seiwald, Christoph Baumgartner, Ridle Baku, Rocco Reitz, Neil El Aynaoui, Andrija Maksimović, Benno Kaltefleiter, Viggo Gebel; Antonio Nusa, Marc Guiu, Johan Bakayoko, Tidiam Gomis, Christopher Nkunku, Rômulo, Samba Konaté. [3]

## VfB Stuttgart

Fabian Bredlow, Marius Funk, Dennis Seimen, Stefan Drljača; Ameen Al-Dakhil, Ramon Hendriks, Josha Vagnoman, Maximilian Mittelstädt, Luca Jaquez, Leonidas Stergiou, Lorenz Assignon, Dan-Axel Zagadou, Jeff Chabot, Finn Jeltsch, Maximilian Herwerth, Alexander Groiß, Dominik Nothnagel; Angelo Stiller, Chris Führich, Bilal El Khannouss, Atakan Karazor, Grischa Prömel, Nikolas Nartey, Ertugrul Yigit, Jarzinho Malanga, Yanik Spalt; Tiago Tomás, Ermedin Demirović, Dženan Pejčinović, Jamie Leweling, Deniz Undav, Justin Diehl, Leo Sauer. [3]

## TSG Hoffenheim

Oliver Baumann, Lúkas Petersson, Luca Philipp; Robin Hranáč, Sean Dulic, Ozan Kabak, Bernardo, Valentin Gendrey, Albian Hajdari, Koki Machida, Natnael Abraha, Vladimír Coufal, Mats Rots, Tristan Spranger; Leon Avdullahu, Patrick Wimmer, Luis Engelns, Nathan De Cat, Wouter Burger, Bambasé Conté, Alexander Prass, Andrej Kramarić, Cajetan Lenz, Oskar Hencke, Tiago Poller, Valentin Lässig, Klaus Gjasula, Yasin Zor; Max Moerstedt, Adam Hložek, Fisnik Asllani, Adam Daghim, Tim Lemperle, Jykese Fields, Lion Wagenbach. [3]

## Bayer 04 Leverkusen

Mark Flekken, Janis Blaswich, Niklas Lomb; Facundo Medina, Miguel Gutiérrez, Jarell Quansah, Loïc Badé, Edmond Tapsoba, Tim Oermann, Lucas Vázquez, Guéla Doué, Ben Hawighorst; Ezequiel Fernández, Jonas Hofmann, Robert Andrich, Malik Tillman, Kennet Eichhorn, Aleix García, Ibrahim Maza, Kenan Doganay, Gabriel Minutillo; Afonso Moreira, Martin Terrier, Patrik Schick, Moussa Diaby, Victor Boniface, Nathan Tella, Eliesse Ben Seghir, Christian Kofane, Dustin Buck, Montrell Culbreath. [3]

## Sport-Club Freiburg

Mio Backhaus, Florian Müller, Jannik Huth; Philipp Lienhart, Anthony Jung, Lukas Kübler, Berkay Yilmaz, Matthias Ginter, Philipp Treu, Christian Günter, Jordy Makengo, Max Rosenfelder, Bruno Ogbus; Patrick Osterhage, Maximilian Eggestein, Yuito Suzuki, Yannik Engelhardt, Niklas Beste, Rihito Yamamoto, Florent Muslija, Vincenzo Grifo, Rouven Tarnutzer; Derry Scherhant, Lucas Höler, Cyriaque Irié, Igor Matanović, Mateo Zelic, Keisuke Gotō. [3]

## Eintracht Frankfurt

**Cobertura parcial:** o diretório oficial acessível na extração mostrou apenas estes jogadores antes de terminar abruptamente a seção do clube: Noah Atubolu, Jens Grahl, Amil Siljevic, Kauã Santos e Elias Baum. Este fragmento não representa o elenco completo. [3]

## FC Augsburg

**Elenco não verificável nesta consulta:** o clube consta entre os participantes oficiais da temporada, mas a extração disponível do diretório de jogadores não chegou a um bloco de elenco do Augsburg. Nenhum nome é listado sem verificação 2026/27. [1] [3]

## 1. FSV Mainz 05

**Elenco não verificável nesta consulta:** o clube consta entre os participantes oficiais da temporada, mas a extração disponível do diretório de jogadores não chegou a um bloco de elenco do Mainz 05. Nenhum nome é listado sem verificação 2026/27. [1] [3]

## Fontes

[1]: https://www.bundesliga.com/en/bundesliga/clubs "Clubes da Bundesliga 2026–27"
[2]: https://www.bundesliga.com/en/bundesliga/table/2026-2027 "Tabela oficial Bundesliga 2026–27"
[3]: https://www.bundesliga.com/en/bundesliga/player "Diretório oficial de jogadores da Bundesliga"
