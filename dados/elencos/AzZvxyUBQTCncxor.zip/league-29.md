# J1 League 2026/27 — clubes e elencos publicamente verificáveis

- **País:** Japão
- **Campeonato:** Meiji Yasuda J.League
- **Divisão:** J1 League (1ª divisão)
- **Temporada/status em 12 de novembro de 2026:** temporada 2026/27 em andamento. O calendário divulgado prevê partidas de agosto de 2026 a junho de 2027; notícia oficial de FC Tokyo publicada em 12 de novembro anuncia jogos ainda por disputar no mês. [1] [2]

## Cobertura e ressalva sobre os jogadores

A J.League publicou em 16 de julho de 2026 seu guia oficial de jogadores 2026/27, com links individuais para os 20 clubes da J1 listados abaixo. [3] Assim, a temporada não está sem elencos públicos. Porém, durante esta pesquisa, as páginas individuais de elenco da J.League carregaram apenas a estrutura de navegação e a indicação “Loading” no extrator de páginas, sem disponibilizar os nomes. Não foi possível confirmar e transcrever, com segurança, o conjunto completo de jogadores de cada clube. Para cumprir a instrução de não inventar nem usar automaticamente elencos da temporada anterior, não apresento nomes não verificados. Os links oficiais diretos de cada elenco estão registrados abaixo; a cobertura dos clubes é completa quanto à identificação e às fontes de elenco, mas a extração nominal completa não foi viável nesta execução.

As páginas são guias oficiais de jogadores da J.League para 2026/27, não páginas de temporadas antigas. O comunicado oficial da liga também confirma expressamente que se trata do guia da temporada 2026/27. [3] As fontes registradas são exclusivamente da J.League e do clube participante FC Tokyo, sem pesquisa de outras ligas.

## Clubes participantes

### Kashima Antlers

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Kashima](https://www.jleague.jp/club/kashima/player).

### Mito HollyHock

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Mito](https://www.jleague.jp/club/mito/player).

### Urawa Reds

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Urawa](https://www.jleague.jp/club/urawa/player).

### JEF United Chiba

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Chiba](https://www.jleague.jp/club/chiba/player).

### Kashiwa Reysol

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Kashiwa](https://www.jleague.jp/club/kashiwa/player).

### FC Tokyo

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — FC Tokyo](https://www.jleague.jp/club/ftokyo/player).

### Tokyo Verdy

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Tokyo Verdy](https://www.jleague.jp/club/tokyov/player/).

### FC Machida Zelvia

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Machida](https://www.jleague.jp/club/machida/player/).

### Kawasaki Frontale

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Kawasaki](https://www.jleague.jp/club/kawasakif/player).

### Yokohama F. Marinos

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Yokohama F. Marinos](https://www.jleague.jp/club/yokohamafm/player/).

### Shimizu S-Pulse

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Shimizu](https://www.jleague.jp/club/shimizu/player).

### Nagoya Grampus

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Nagoya](https://www.jleague.jp/club/nagoya/player/).

### Kyoto Sanga FC

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Kyoto](https://www.jleague.jp/club/kyoto/player/).

### Gamba Osaka

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Gamba Osaka](https://www.jleague.jp/club/gosaka/player).

### Cerezo Osaka

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Cerezo Osaka](https://www.jleague.jp/club/cosaka/player).

### Vissel Kobe

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Kobe](https://www.jleague.jp/club/kobe/player).

### Fagiano Okayama

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Okayama](https://www.jleague.jp/club/okayama/player).

### Sanfrecce Hiroshima

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Hiroshima](https://www.jleague.jp/club/hiroshima/player).

### Avispa Fukuoka

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Fukuoka](https://www.jleague.jp/club/fukuoka/player).

### V-Varen Nagasaki

- **Jogadores:** não transcritos; conferir o guia oficial 2026/27 em [elenco J.League — Nagasaki](https://www.jleague.jp/club/nagasaki/player).

## Fontes

[1]: https://www.fctokyo.co.jp/en/news/details/336594/ "FC Tokyo — agenda da J1 League 2026/27"
[2]: https://www.fctokyo.co.jp/en/news/details/342582/ "FC Tokyo — notícia de 12 de novembro de 2026"
[3]: https://www.jleague.jp/news/article/34439/ "J.League — publicação do guia de jogadores 2026/27"
