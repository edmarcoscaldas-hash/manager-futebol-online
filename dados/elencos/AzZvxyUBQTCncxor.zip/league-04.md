# 2. Bundesliga 2026/27 — clubes e jogadores

**País:** Alemanha  
**Campeonato:** 2. Bundesliga (2. Fußball-Bundesliga)  
**Divisão:** segunda divisão masculina  
**Temporada/status:** 2026/27 em andamento em 12 de novembro de 2026; a página oficial da competição identifica clubes da temporada 2026–2027, a tabela tem jogos disputados e a página oficial de calendário mostra jornadas já realizadas e futuras. [1] [2] [3]

## Escopo e critério de elenco

A lista de participantes abaixo é a relação oficial da liga para 2026/27. Para os jogadores, usei a seção “Squad” das páginas de cada clube no site oficial Bundesliga.com, consultadas para a temporada corrente. São jogadores nomeados na página de elenco, agrupados conforme a posição indicada pela liga; comissão técnica foi excluída. As páginas são bases dinâmicas e podem mudar durante a temporada. A relação deve ser entendida como o elenco publicado na consulta, não como lista de inscritos congelada em uma data de registro.

A relação pública da liga tem 18 clubes. Não transcrevo nomes que não estejam publicados na seção de elenco da respectiva página. [1]

## Clubes e elencos

### VfL Wolfsburg

**Jogadores publicados:** Timon Wellenreuther, Pavao Pervan, Jakub Zielinski, Dušan Perniš, Kilian Fischer, Hauke Wahl, Rogério, Jonas Adjetey, Joakim Mæhle, Mathys Angély, Aaron Zehnter, Saël Kumbedi, Cleiton, Vinicius Souza, Bence Dárdai, Pharell Hensel, Muhammed Damar, Maximilian Arnold, Yannick Gerhardt, Mattias Svanberg, Aster Vranckx, Elvis Rexhbeçaj, Kento Shiogai, Fraser Hornby, Fabian Reese, Alexander Bernhardsson, Robert Glatzel, Alessio Besio, Bruno Katz, Trevor Benedict. [4]

### 1. FC Heidenheim 1846

**Jogadores publicados:** Frank Feller, Thomas Dähne, Paul Tschernuth, Felix Mark, Marnon Busch, Tim Siersleben, Patrick Mainka, Jonas Föhrenbach, Oualid Mhamdi, Leart Paçarada, Michael Heule, Adam Kölle, Jan Schöppner, Paul Hennrich, Christian Conteh, Julian Niehues, Mathias Honsak, Luca Kerber, Sirlord Conteh, Torben Leis, Marko Zrilić, Budu Zivzivadze, Maximilian Breunig, Alessandro Vogt, Marcel Costly, Mikkel Kaufmann, Yannik Wagner. [5]

### FC St. Pauli

**Jogadores publicados:** Ben Voll, Simon Spari, Dimitar Mitov, Rony Jansson, David Nemeth, Marcus Mathisen, Arkadiusz Pyrka, Tomoya Andō, Lars Ritzka, Louis Oppie, Adam Dźwigała, Jannik Westphal, Gisli Thórdarson, Eric Smith, Erik Ahlstrand, Joel Chima Fujita, Mathias Rasmussen, Sam Klein, Connor Metcalfe, Mathias Pereira Lage, Marwin Schmitz, Nick Schmidt, Youssoupha Niang, Abdoulie Ceesay, Branimir Hrgota, Scott Banks, Taichi Hara, Martijn Kaars, Ricky-Jade Jones, Haron Sabah. [6]

### Hannover 96

**Jogadores publicados:** Pascal Loretz, Leo Weinkauf, Jonas Schwanke, Boris Tomiak, Jean Hugonet, Virgil Ghiță, Karl Steinmann, Bastian Allgeier, Ime Okon, Hayate Matsuda, Maurice Neubauer, Joschua Siewert, Manuel Braun, Waniss Taïbi, Marcel Hartel, Franz Roggow, Husseyn Chakroun, Mwisho Mhango, Noah Engelbreth, Stefán Teitur Thórdarson, Yunus Ünal, Lars Gindorf, Kolja Oudenne, Asuma Ikari, Alexander Vogel, Jasper Reinhold, Emir Sahiti, Mustapha Bundu, Benjamin Källman, Benedikt Pichler, Tom Hobrecht, Taycan Etçibaşı, Denis Husser, Taycan Kurt, Merlin Sinanović. [7]

### SV Darmstadt 98

**Jogadores publicados:** Marcel Schuhen, Benedikt Börner, Alexander Brunst, Florian Kleinhansl, Grayson Dettoni, Patric Pfeiffer, Meldin Drešković, Raoul Petretta, Aleksandar Vukotić, William Mikelbrencis, Matthias Bader, Christopher Lannert, Max Pfister, Yannik Lührs, Marco Richter, Nicolas Verkooijen, Ibrahim El Kadiri, Fabian Nürnberger, Hiroki Akiyama, Kai Klefisch, Merveille Papela, Lars Kehl, Carlo Sickinger, Lance Duijvestijn, Tom Noah Steineck, Milian Herbst, Manolo Merx, Noah Weißhaupt, Luca Marseiler, Ho-jae Lee, Fynn-Luca Lakenmacher, Milan Smit, Yosuke Furukawa. [8]

### 1. FC Kaiserslautern

**Jogadores publicados:** Julian Krahl, Yannick Onohiol, Enis Kamga, Simon Asta, Alex Murphy, Maxwell Gyamfi, Kelven Frees, Jacob Rasmussen, Mika Haas, Ivan Knežević, Paul Joly, Jan Elvedi, Fabian Kunze, Marlon Ritter, Semih Şahin, Naatan Skyttä, Titus Henseler, Mário Sauer, Samet Acar, Leon Robinson, David Schramm, Erik Müller, Owen Gibs, Dion Hofmeister, Kian Scheer, Ben Jungfleisch, Ivan Prtajin, Ibrahim Kanaté, Erencan Yardımcı, Mërgim Berisha, Thierry Tazemeta, Miloš Luković. [9]

### Hertha BSC

**Jogadores publicados:** Konstantin Heide, Marius Gersbeck, Tim Goller, Julian Eitschberger, Mads Pedersen, Niklas Kolbe, Jerome Kalil Diallo, Márton Dárdai, Mayson Grothe, Pascal Klemens, Deyovaisio Zeefuik, Linus Gechter, Kevin Sessa, Oluwaseun Victor Adewumi, Boris Mamuzah Lum, Paul Seguin, Soufian Gouram, Selim Telib, Josip Brekalo, Gustaf Nilsson, Sebastian Grønning, Luca Schuler, Farid Alfa-Ruprecht, Jón Dagur Thorsteinsson, Niklas Hildebrandt, Jelani Agendia. [10]

### 1. FC Nürnberg

**Jogadores publicados:** Jan Reichert, Robin Lisewski, Christian Mathenia, Nicolas Ortegel, Alexios Kalogeropoulos, Styopa Mkrtchyan, Andrea Ceresoli, Mikayil Faye, Fynn Otto, Ioannis Masouras, Tim Janisch, Kristian Mandić, Eric Porstner, Tobias Heß, Khalid Abu El Haija, Adam Markhiyev, Javier Fernández, Julian Justvan, Marko Soldić, Rafael Lubach, Finn Becker, Can Moustfa, Marc Kornwachs Barjuan, Winners Osawe, Rayan Ghrieb, Sigurd Haugen, William Bøving, Piet Scobel, Mohamed Alì Zoma, Adriano Grimaldi. [11]

### VfL Bochum 1848

**Jogadores publicados:** Timo Horn, Tino Casali, Hugo Rölleke, Sean Klaiber, Philipp Strompf, Yiğit Karademir, Karol Mets, Oliver Olsen, Michael Steinwender, Leon Sawas, Maximilian Wittek, Enis Çokaj, Jean-Manuel Mbom, Berkan Taz, Koji Miyoshi, Mats Pannewig, Charlie Patiño, Tom Meyer, Alessandro Crimaldi, Lasse Isbruch, Aurel Wagbe, Christian Rasmussen, Jarne Steuckers, Gerrit Holtmann, Daniel Hanslik, Babis Drakas, Mansour Ouro-Tagba, Philipp Hofmann, Luis Pick. [12]

### Karlsruher SC

**Jogadores publicados:** Hans Christian Bernat, Ferdinand Gebert, Robin Himmelmann, Sebastian Jung, Deniz Ofli, Héliton, Paul Scholl, Christoph Kobald, Sandro Trémoulet, Marcel Franke, Viktor Bergh, Rafael Pinto Pedrosa, Hyeokkyu Kwon, Santeri Väänänen, Kevin Wiethaup, Marvin Wanitzek, Tim Civeja, Lilian Egloff, Danyal Zor, Moritz Broschinski, Noel Eichinger, Shio Fukuda, Eymen Laghrissi, Louey Ben Farhat, John Davis Meyer, Jason Ponente-Ramirez. [13]

### SG Dynamo Dresden

**Jogadores publicados:** Tim Schreiber, Lennart Grill, Daniel Mesenhöler, Elias Bethke, Kenneth Schmidt, Brooklyn Ezeh, Ahmet Muhamedbegović, Alexander Rossipal, Lars Bünning, Lukas Boeder, Jonas Sterner, Till Neininger, Thomas Keller, Friedrich Müller, Simon Straudi, Nicolai Rapp, Luca Herrmann, Jakob Lemmer, Robert Wagner, Tobias Raschl, Patrice Čović, Niklas Hauptmann, Kennedy Okpala, Vincent Vermeij, Kaan İnanoğlu, Nils Fröling, Ben Bobzien, Christoph Daferner. [14]

### Holstein Kiel

**Jogadores publicados:** Timon Weiner, Marcel Engelhardt, Lio Rothenhagen, Ben Schmit, Frederik Roslyng, Niko Takahashi, Sebastian Schonlau, Noah Madsen, Ivan Nekić, Lasse Rosenboom, David Zec, Hiroki Sekine, Leon Parduzi, Caspar Medlin, John Tolkin, Steven Skrzybski, Guillermo Balzi, Jonas Therkelsen, Kasper Davidsen, Andu Kelati, Adrián Kaprálik, Moritz Reimers, Taisei Abe, Ikem Ugoh, Jonas Meffert, Tayar Tasdelen, Till Wiese, Mark Richter Monserrat, Hamza Muqaj, Giorgi Kvilitaia, Gyan de Regt, Faride Alidou, Phil Harres. [15]

### DSC Arminia Bielefeld

**Jogadores publicados:** Jonas Kersken, Leo Oppermann, Philip Hildesheim, Felix Hagmann, Joel Felix, Maximilian Bauer, Henri Koudossou, Arne Sicker, Maximilian Großer, Leon Schneider, Tim Handwerker, Marvin Mehlem, Sam Schreck, Jannik Rochelt, Lukas Kunze, Stefano Russo, Benjamin Boakye, Leon Jensen, Marius Wörl, Till Wegener, Daniel Richter, Eyyüb Yasar, David Min, Joel Grodowski, Monju Momuluh, Isaiah Young, Vincent Ocansey. [16]

### 1. FC Magdeburg

**Jogadores publicados:** Dominik Reimann, Noah Kruth, Robert Kampa, Anselmo García MacNulty, Eldin Džogović, Tobias Müller, Paul Jaeckel, Herbert Bockhorn, Daniel Heber, Lubambo Musonda, Tarek Chahed, Pierre Nadjombe, Emmanuel Iyoha, Moritz-Broni Kwarteng, Felipe Chávez, Tony Reitz, Falko Michel, Torben Müsel, Leon Mergner, Luka Hyryläinen, Roko Šimić, Alexander Nollenberger, Chunghyun Lee, Kevin Manthey, Mateusz Żukowski, Baris Atik, Doyoung Yoon, Richmond Tachie, Magnus Baars. [17]

### Eintracht Braunschweig

**Jogadores publicados:** Ron-Thorben Hoffmann, Benjamin Uphoff, Nick Bodon, Noah Katterbach, Andi Hoti, Frederik Jäkel, Kevin Ehlers, Fabio Di Michele Sanchez, Isidoros Koutsidis, Sanoussy Ba, Lukas Frenkert, Damjan Kovacevic, Florian Flick, Yann Sturm, Mehmet Can Aydın, Samuele Di Benedetto, Max Marie, Junior Zé, Lino Tempelmann, Sidi Sané, Tristan Wagner, Robin Heußer, Sidney Raebiger, Hugo Luis Afonso, Maximilian Entrup, Jovan Mijatović, Aaron Opoku, Jan Urbich. [18]

### SpVgg Greuther Fürth

**Jogadores publicados:** Florian Hellstern, Christian Ortag, Silas Prüfrock, Lukas Reich, Elias Benkara, Maxim Dal, Loris Giandomenico, Jannis Heuer, Jannik Dehm, Luca Itter, Krisztián Keresztes, Hendry Blank, Raul Mariţa, Jakob Krautkrämer, Sacha Bansé, Shinta Appelkamp, Ole Pohlmann, Aaron Keller, Paul Will, Omar Megeed, Doni Arifi, Felix Klaus, Philipp Müller, Faton Ademi, Mehmet Avlayici, Olgherto Balliu, Dennis Srbeny, Jordan, Benjamin Zank, Mika Wallentowitz, Omar Sillah. [19]

### FC Energie Cottbus

**Jogadores publicados:** Marcel Lotka, Kevin Kratzsch, Max Böhnke, Malte Wilke, King Manu, Henry Rorig, Tim Campulka, Ryan Malone, Luca Erlein, Fousseny Doumbia, Anderson Lucoqui, Leon Guwara, Jannis Zaydan, Joey Taubeneck, Dominik Pelivan, Jonas Hofmann, Lukas Michelbrink, Tolcay Ciğerci, Julian Guttau, Jannis Boziaris, Axel Borgmann, Fabian Balg, Leonardo Bittencourt, Aaron Reschke, Christian Kinsombi, Lucas Copado, Moritz Hannemann, Dmytro Bogdanov, Erik Engelhardt, Justin Butler. [20]

### VfL Osnabrück

**Jogadores publicados:** Niklas Sauter, Jonas Krumrey, Lowe Bjerlestam, Luca Böggemann, Joel Abu Hanna, Theo Janotta, Jannik Müller, Niklas Wiemann, Robin Fabinski, Konrad Faber, Patrick Kammerbauer, Elias Bakatukanda, Jonathan Gómez, Jonathan Wensing, Bryan Henning, Leonhard Münst, Adem Bukvic, Bjarke Jacobsen, Luca Raimund, Leon Flach, Adrian Beck, Tony Lesueur, Fridolin Wagner, Luca Kröger, Daniel Kofi Kyereh, Ismail Badjie, Robin Meißner, Leon Opitz, Bernd Riesselmann. [21]

## Observações de cobertura

A liga oficial lista os 18 participantes e disponibiliza uma página “Squad” em cada página individual de clube; a temporada está inequivocamente identificada como 2026/27 e em curso, portanto não se trata de reaproveitamento automático da temporada anterior. A cobertura de nomes é a lista publicamente exibida pela fonte oficial da liga na consulta. A fonte não esclarece que a lista representa todos os atletas profissionalmente contratados ou todos os jogadores registrados nas federações; por isso não trato o conjunto como cadastro legal exaustivo. Recomenda-se consultar as páginas dinâmicas dos clubes para atualizações posteriores à data desta pesquisa. Não foram pesquisadas outras ligas.

## Referências

[1]: https://www.bundesliga.com/en/2bundesliga/clubs "Bundesliga.com — clubes, temporada 2026–2027"
[2]: https://www.bundesliga.com/en/2bundesliga/table "Bundesliga.com — tabela 2026/27"
[3]: https://www.bundesliga.com/en/2bundesliga/matchday "Bundesliga.com — calendário e resultados 2026/27"
[4]: https://www.bundesliga.com/en/2bundesliga/clubs/vfl-wolfsburg "VfL Wolfsburg — página de clube e elenco"
[5]: https://www.bundesliga.com/en/2bundesliga/clubs/1-fc-heidenheim-1846 "1. FC Heidenheim — página de clube e elenco"
[6]: https://www.bundesliga.com/en/2bundesliga/clubs/fc-st-pauli "FC St. Pauli — página de clube e elenco"
[7]: https://www.bundesliga.com/en/2bundesliga/clubs/hannover-96 "Hannover 96 — página de clube e elenco"
[8]: https://www.bundesliga.com/en/2bundesliga/clubs/sv-darmstadt-98 "SV Darmstadt 98 — página de clube e elenco"
[9]: https://www.bundesliga.com/en/2bundesliga/clubs/1-fc-kaiserslautern "1. FC Kaiserslautern — página de clube e elenco"
[10]: https://www.bundesliga.com/en/2bundesliga/clubs/hertha-bsc "Hertha BSC — página de clube e elenco"
[11]: https://www.bundesliga.com/en/2bundesliga/clubs/1-fc-nuernberg "1. FC Nürnberg — página de clube e elenco"
[12]: https://www.bundesliga.com/en/2bundesliga/clubs/vfl-bochum-1848 "VfL Bochum — página de clube e elenco"
[13]: https://www.bundesliga.com/en/2bundesliga/clubs/karlsruher-sc "Karlsruher SC — página de clube e elenco"
[14]: https://www.bundesliga.com/en/2bundesliga/clubs/sg-dynamo-dresden "Dynamo Dresden — página de clube e elenco"
[15]: https://www.bundesliga.com/en/2bundesliga/clubs/holstein-kiel "Holstein Kiel — página de clube e elenco"
[16]: https://www.bundesliga.com/en/2bundesliga/clubs/dsc-arminia-bielefeld "Arminia Bielefeld — página de clube e elenco"
[17]: https://www.bundesliga.com/en/2bundesliga/clubs/1-fc-magdeburg "1. FC Magdeburg — página de clube e elenco"
[18]: https://www.bundesliga.com/en/2bundesliga/clubs/eintracht-braunschweig "Eintracht Braunschweig — página de clube e elenco"
[19]: https://www.bundesliga.com/en/2bundesliga/clubs/spvgg-greuther-fuerth "Greuther Fürth — página de clube e elenco"
[20]: https://www.bundesliga.com/en/2bundesliga/clubs/fc-energie-cottbus "Energie Cottbus — página de clube e elenco"
[21]: https://www.bundesliga.com/en/2bundesliga/clubs/vfl-osnabrueck "VfL Osnabrück — página de clube e elenco"
