# Premier League 2026/27 — clubes e jogadores

- **País:** Inglaterra
- **Campeonato:** Premier League
- **Divisão:** 1ª divisão (nível máximo do futebol inglês)
- **Temporada/status:** 2026/27; em andamento em 12 de novembro de 2026. A publicação oficial de todos os 380 jogos é de 19 de outubro de 2026, e a rodada inaugural foi marcada para 21 de agosto de 2026. [1] [2]

## Cobertura e critério

A Premier League publicou em 22 de setembro a relação de números de camisa dos 20 clubes após o fechamento da janela de verão. A liga explica que a relação abrange atletas das listas de 25 e jovens que já apareceram ou ainda poderiam aparecer em uma equipe principal. A lista abaixo reproduz os nomes e números atribuídos na fonte, não inclui comissão técnica e não afirma que todos estejam inscritos na lista de 25 ou disponíveis para jogar. [3]

A cobertura alcança os 20 clubes participantes segundo essa publicação oficial. É um retrato datado de 22 de setembro de 2026, não uma atualização em tempo real; mudanças posteriores podem não estar refletidas. Não deve ser entendida como cadastro exaustivo de todo atleta elegível das academias. A página da liga para cada clube está indicada junto à sua relação. [3]

## Arsenal

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/3/arsenal/overview).

Jogadores nomeados (número de camisa):

- 1. David Raya
- 2. William Saliba
- 3. Cristhian Mosquera
- 4. Ben White
- 5. Piero Hincapie
- 6. Gabriel Magalhaes
- 7. Bukayo Saka
- 8. Martin Odegaard
- 10. Eberechi Eze
- 12. Jurrien Timber
- 13. Kepa Arrizabalaga
- 14. Viktor Gyokeres
- 15. Ezri Konsa
- 17. Christos Tzolis
- 20. Noni Madueke
- 22. Ethan Nwaneri
- 23. Mikel Merino
- 29. Kai Havertz
- 30. Illan Meslier
- 33. Riccardo Calafiori
- 36. Martin Zubimendi
- 39. Bruno Guimaraes
- 41. Declan Rice
- 49. Myles Lewis-Skelly
- 56. Max Dowman

## Aston Villa

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/7/aston-villa/overview).

Jogadores nomeados (número de camisa):

- 1. Zion Suzuki
- 2. Matty Cash
- 3. Victor Lindelof
- 4. Taylor Harwood-Bellis
- 5. Tyrone Mings
- 6. Ross Barkley
- 7. John McGinn
- 8. Boubacar Kamara
- 10. Emiliano Buendia
- 11. Nicolas Jackson
- 13. Matteo Ruggeri
- 14. Pau Torres
- 17. Alejandro Garnacho
- 18. Tammy Abraham
- 19. Ibrahim Mbaye
- 22. Ian Maatsen
- 24. Amadou Onana
- 26. Lamare Bogarde
- 27. Leon Goretzka
- 29. Aaron Wan-Bissaka
- 35. Joao Gomes
- 39. Brian Madjo
- 40. Marco Bizot
- 42. James Wright
- 44. Johan Manzambi
- 45. Triston Rowe
- 47. Alysson
- 48. Modou Keba Cisse
- 49. Bradley Burrowes
- 53. George Hemmings
- 74. Luka Lynch

## AFC Bournemouth

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/91/bournemouth/overview).

Jogadores nomeados (número de camisa):

- 1. Djordje Petrovic
- 2. Julian Araujo
- 3. Adrien Truffert
- 4. Lewis Cook
- 5. James Hill
- 6. Julio Soler
- 7. David Brooks
- 8. Alex Scott
- 9. Evanilson
- 10. Ryan Christie
- 11. Ben Gannon-Doak
- 12. Tyler Adams
- 14. Antonio Silva
- 15. Adam Smith
- 16. Marcus Tavernier
- 17. Fraser Forster
- 18. Bafode Diakite
- 19. Justin Kluivert
- 20. Michele Di Gregorio
- 21. Amine Adli
- 22. Junior Kroupi
- 24. Juanlu Sanchez
- 27. Alex Toth
- 28. Max Aarons
- 29. Daniel Jebbison
- 30. Alvaro Rodriguez
- 37. Rayan
- 44. Veljko Milosavljevic
- 47. Ben Winterburn

## Brentford

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/94/brentford/overview).

Jogadores nomeados (número de camisa):

- 1. Caoimhin Kelleher
- 2. Aaron Hickey
- 3. Rico Henry
- 4. Sepp van den Berg
- 6. Yehor Yarmoliuk
- 7. Kevin Schade
- 8. Mathias Jensen
- 9. Igor Thiago
- 10. Josh Dasilva
- 11. Dango Ouattara
- 12. Hakon Valdimarsson
- 13. Callum Wilson
- 14. Fabio Carvalho
- 17. Antoni Milambo
- 18. Mamadou Sangare
- 19. Jaidon Anthony
- 20. Kristoffer Ajer
- 22. Nathan Collins
- 23. Keane Lewis-Potter
- 24. Mikkel Damsgaard
- 25. El Hadji Malick Diouf
- 27. Vitaly Janelt
- 31. Ellery Balcombe
- 33. Michael Kayode
- 36. Kim Ji-Soo
- 39. Gustavo Nunes
- 44. Jannik Schuster
- 48. Benjamin Fredrick
- 59. Caelan Avenell

## Brighton & Hove Albion

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/36/brighton-and-hove-albion/overview).

Jogadores nomeados (número de camisa):

- 1. Bart Verbruggen
- 3. Jaouen Hadjam
- 4. Pascal Struijk
- 5. Lewis Dunk
- 7. Kaoru Mitoma
- 8. Jack Hinshelwood
- 9. Stefanos Tzimas
- 10. Georginio Rutter
- 11. Yankuba Minteh
- 12. Promise David
- 13. Pascal Gross
- 14. Chema Andres
- 15. Ibrahim Osman
- 19. Charalampos Kostoulas
- 20. Costinha
- 21. Olivier Boscagli
- 22. Amario Cozier-Duberry
- 23. Jason Steele
- 24. Ferdi Kadioglu
- 25. Diego Gomez
- 26. Yasin Ayari
- 27. Mats Wieffer
- 28. Evan Ferguson
- 29. Maxim De Cuyper
- 30. Michael Svoboda
- 33. Matt O'Riley
- 35. Malick Yalcouye
- 36. Zadok Yohanna
- 38. Tom McGill
- 39. Femi Azeez
- 44. Luka Vuskovic
- 49. Nehemiah Oriola

## Chelsea

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/8/chelsea/overview).

Jogadores nomeados (número de camisa):

- 1. Emiliano Martinez
- 2. Marco Palestra
- 3. Wesley Fofana
- 4. Valentin Barco
- 5. Maxence Lacroix
- 6. Levi Colwill
- 7. Pedro Neto
- 9. Joao Pedro
- 10. Cole Palmer
- 11. Jamie Gittens
- 14. Jordan Henderson
- 17. Morgan Rogers
- 18. Danny Welbeck
- 21. Jorrel Hato
- 22. Emmanuel Emegha
- 23. Geovany Quenda
- 24. Reece James
- 25. Moises Caicedo
- 27. Malo Gusto
- 28. Teddy Sharman-Lowe
- 29. Pep Chavarria
- 30. Aaron Anselmino
- 32. Mahdi Nicoll-Jazuli
- 34. Josh Acheampong
- 37. Olutayo Subuloye
- 39. Mike Penders
- 41. Estevao
- 44. Gabriel Slonina
- 45. Romeo Lavia

## Coventry City

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/9/coventry-city/overview).

Jogadores nomeados (número de camisa):

- 2. Ethan Pinnock
- 3. Jay Dasilva
- 4. Bobby Thomas
- 5. Jack Rudoni
- 6. Matt Grimes
- 7. Tatsuhiro Sakamoto
- 8. Caleb Yirenkyi
- 9. Ellis Simms
- 10. Ephron Mason-Clark
- 11. Haji Wright
- 12. Stephen Mfuni
- 13. Ben Wilson
- 14. Taiwo Awoniyi
- 16. Frank Onyeka
- 18. Loum Tchaouna
- 19. Carl Rushworth
- 20. Kaine Kesler-Hayden
- 21. Jake Bidwell
- 22. Joel Latibeaudiere
- 23. Brandon Thomas-Asante
- 24. Aurele Amenda
- 25. Dan Bentley
- 26. Luke Woolfenden
- 27. Milan van Ewijk
- 28. Josh Eccles
- 29. Victor Torp
- 34. Yann Gboho
- 38. Gustavo Hamer
- 49. Sidiki Cherif

## Crystal Palace

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/31/crystal-palace/overview).

Jogadores nomeados (número de camisa):

- 1. Dean Henderson
- 3. Tyrick Mitchell
- 4. Chadi Riad
- 5. Axel Disasi
- 6. Jaydee Canvot
- 7. Ismaila Sarr
- 8. Jefferson Lerma
- 9. Eddie Nketiah
- 10. Yeremy Pino
- 11. Dwight McNeil
- 12. Zavier Gozo
- 14. Jean-Philippe Mateta
- 17. Takehiro Tomiyasu
- 18. Daichi Kamada
- 19. Will Hughes
- 20. Adam Wharton
- 21. Honest Ahanor
- 22. Jorgen Strand Larsen
- 23. Quinten Timber
- 24. Dario Osorio
- 25. Anan Khalaili
- 26. Chris Richards
- 27. Matheus Franca
- 28. Cheick Doucoure
- 29. Evann Guessand
- 30. Oscar Mingueza
- 31. Remi Matthews
- 33. Ben Chilwell
- 44. Walter Benitez

## Everton

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/11/everton/overview).

Jogadores nomeados (número de camisa):

- 1. Jordan Pickford
- 2. Ainsley Maitland-Niles
- 4. Jarrad Branthwaite
- 5. Michael Keane
- 6. James Tarkowski
- 8. Kiernan Dewsbury-Hall
- 10. Jack Grealish
- 11. Thierno Barry
- 12. Mark Travers
- 15. Jake O'Brien
- 16. Vitalii Mykolenko
- 19. Tyrique George
- 20. Tyler Dibling
- 22. Brennan Johnson
- 23. Christian Norgaard
- 24. Charly Alcaraz
- 30. Hayden Hackney
- 31. Tom King
- 34. Merlin Rohl
- 37. James Garner
- 45. Harrison Armstrong
- 47. Fraser Barnsley

## Fulham

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/54/fulham/overview).

Jogadores nomeados (número de camisa):

- 1. Bernd Leno
- 2. Kenny Tete
- 3. Calvin Bassey
- 4. Jorge Cuenca
- 5. Joachim Andersen
- 6. Harrison Reed
- 7. Gonzalo Garcia
- 8. Cesar Palacios
- 9. Rodrigo Muniz
- 10. Tom Cairney
- 11. Kevin
- 14. Oscar Bobb
- 15. Hugo Larsson
- 16. Sander Berge
- 17. Alex Iwobi
- 18. Jonah Kusi-Asare
- 19. Shea Charles
- 20. Manuel Angel
- 21. Timothy Castagne
- 22. David Affengruber
- 23. Benjamin Lecomte
- 24. Josh King
- 30. Ryan Sessegnon
- 32. Emile Smith Rowe
- 33. Antonee Robinson
- 35. Macaulay Zepa
- 36. Alex Borto
- 39. Michael Allen
- 44. Luc De Fougerolles

## Hull City

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/88/hull-city/overview).

Jogadores nomeados (número de camisa):

- 1. Jack Butland
- 2. Lewie Coyle
- 3. Ryan Giles
- 4. Charlie Hughes
- 5. Hidemasa Morita
- 6. Semi Ajayi
- 7. Sorba Thomas
- 8. Eliot Matazo
- 9. Oliver McBurnie
- 10. Mohamed Belloumi
- 11. Joe Gelhardt
- 12. Dillon Phillips
- 14. Jens Hjerto-Dahl
- 15. John Egan
- 17. Paddy McNair
- 18. Brooke Norton-Cuffy
- 19. Konstantinos Tzolakis
- 21. Elliot Stroud
- 22. Lucas Herrington
- 23. Matt Targett
- 25. Matt Crooks
- 27. Regan Slater
- 28. Ilyas Ansah
- 29. Lucas Gourna-Douath
- 32. Nobel Mendy
- 33. Abdulkadir Omur
- 42. Tim Iroegbunam
- 50. Mohamed-Ali Cho

## Ipswich Town

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/40/ipswich-town/overview).

Jogadores nomeados (número de camisa):

- 1. Alex Palmer
- 2. Darnell Furlong
- 3. Leif Davis
- 4. Cedric Kipre
- 5. Azor Matusiwa
- 6. Issa Diop
- 7. Abdul Fatawu
- 8. Sindre Egeli
- 9. Zian Flemming
- 10. Julio Enciso
- 11. Jaden Philogene
- 12. Florentino
- 14. Jack Taylor
- 19. Emersonn
- 20. Kasey McAteer
- 23. Sasa Lukic
- 24. Jacob Greaves
- 25. Exequiel Palacios
- 26. Dara O'Shea
- 27. David Button
- 28. Christian Walton
- 29. Chuba Akpom
- 32. Marcelino Nunez
- 33. Anis Mehmeti
- 37. Kjell Scherpen
- 38. Daizen Maeda
- 42. Abdoul Ouattara
- 47. Jack Clarke

## Leeds United

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/2/leeds-united/overview).

Jogadores nomeados (número de camisa):

- 1. James Trafford
- 2. Jayden Bogle
- 3. Gabriel Gudmundsson
- 4. Ethan Ampadu
- 5. Tarik Muharemovic
- 6. Joe Rodon
- 7. Daniel James
- 8. Sean Longstaff
- 9. Dominic Calvert-Lewin
- 10. Harry Wilson
- 11. Brenden Aaronson
- 14. Lukas Nmecha
- 15. Jaka Bijol
- 16. Michael Zetterer
- 18. Anton Stach
- 19. Noah Okafor
- 21. Alex Cairns
- 22. Ao Tanaka
- 23. Jean-Matteo Bahoya
- 24. James Justin
- 26. Melvin Bard
- 30. Nico Elvedi
- 44. Ilia Gruev
- 48. Rory Mahady
- 50. Alfie Cresswell
- 65. Jayden Lienou
- 72. Callum Mills

## Liverpool

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/14/liverpool/overview).

Jogadores nomeados (número de camisa):

- 1. Alisson Becker
- 2. Joe Gomez
- 3. Wataru Endo
- 4. Virgil van Dijk
- 5. Jeremy Jacquet
- 6. Milos Kerkez
- 7. Florian Wirtz
- 8. Dominik Szoboszlai
- 9. Alexander Isak
- 10. Alexis Mac Allister
- 12. Conor Bradley
- 14. Federico Chiesa
- 15. Giovanni Leoni
- 18. Cody Gakpo
- 21. Kostas Tsimikas
- 22. Hugo Ekitike
- 23. Victor Munoz
- 25. Giorgi Mamardashvili
- 28. Freddie Woodman
- 29. Bradley Barcola
- 30. Jeremie Frimpong
- 33. Ronald Araujo
- 38. Ryan Gravenberch
- 42. Trey Nyoni
- 44. Luke Chambers
- 52. Isaac Mabaya
- 53. James McConnell
- 56. Vitezslav Jaros
- 67. Lewis Koumas
- 73. Rio Ngumoha
- 76. Jayden Danns
- 95. Harvey Davies

## Manchester City

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/43/manchester-city/overview).

Jogadores nomeados (número de camisa):

- 1. Gianluigi Donnarumma
- 3. Ruben Dias
- 5. Elliot Anderson
- 6. Marc Guehi
- 7. Iliman Ndiaye
- 8. Mateo Kovacic
- 9. Erling Haaland
- 10. Rayan Cherki
- 11. Jeremy Doku
- 13. Marcus Bettinelli
- 17. Enzo Fernandez
- 21. Rayan Ait-Nouri
- 22. Vitor Reis
- 24. Josko Gvardiol
- 27. Matheus Nunes
- 28. Geronimo Rulli
- 30. Claudio Echeverri
- 32. Ayyoub Bouaddi
- 33. Nico O'Reilly
- 37. Allan
- 42. Antoine Semenyo
- 45. Abdukodir Khusanov
- 47. Phil Foden
- 56. Ryan McAidoo
- 61. Kaden Braithwaite
- 82. Rico Lewis

## Manchester United

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/1/manchester-united/overview).

Jogadores nomeados (número de camisa):

- 1. Senne Lammens
- 2. Diogo Dalot
- 3. Noussair Mazraoui
- 4. Matthijs de Ligt
- 5. Harry Maguire
- 6. Lisandro Martinez
- 7. Mason Mount
- 8. Bruno Fernandes
- 9. Marcus Rashford
- 10. Matheus Cunha
- 11. Joshua Zirkzee
- 12. Karl Darlow
- 13. Patrick Dorgu
- 15. Leny Yoro
- 16. Amad Diallo
- 17. Andrey Santos
- 18. Youri Tielemans
- 19. Bryan Mbeumo
- 20. Carlos Baleba
- 22. Tom Heaton
- 23. Luke Shaw
- 25. Manuel Ugarte
- 26. Ayden Heaven
- 30. Benjamin Sesko
- 31. Shea Lacey
- 37. Kobbie Mainoo
- 38. Jack Fletcher
- 39. Tyler Fletcher
- 41. Harry Amass
- 45. Dermot Mee

## Newcastle United

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/4/newcastle-united/overview).

Jogadores nomeados (número de camisa):

- 1. Nick Pope
- 2. Tino Livramento
- 3. Lewis Hall
- 4. Sven Botman
- 5. Fabian Schar
- 6. Nico Gonzalez
- 7. Joelinton
- 8. Aladji Bamba
- 9. Yoane Wissa
- 10. William Osula
- 11. Harvey Barnes
- 12. Malick Thiaw
- 14. Sean Steur
- 17. Bazoumana Toure
- 19. Anthony Elanga
- 20. Matias Fernandez-Pardo
- 21. Lukas Hornicek
- 23. Jacob Murphy
- 24. Ewen Jaouen
- 28. Joe Willock
- 29. Mark Gillespie
- 31. Aidan Harris
- 33. Dan Burn
- 37. Amar Dedic
- 41. Jacob Ramsey
- 51. Leo Shahar
- 67. Lewis Miley

## Nottingham Forest

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/17/nottingham-forest/overview).

Jogadores nomeados (número de camisa):

- 2. Ousmane Diomande
- 3. Neco Williams
- 4. Morato
- 5. Murillo
- 6. Ibrahim Sangare
- 7. Callum Hudson-Odoi
- 8. Nicolas Dominguez
- 9. Chris Wood
- 10. Morgan Gibbs-White
- 11. Igor Jesus
- 12. John Victor
- 14. Dan Ndoye
- 15. Arnaud Kalimuendo
- 19. Liam Delap
- 21. Xaver Schlager
- 22. Ryan Yates
- 23. Jair Cunha
- 24. James McAtee
- 25. Luca Netz
- 26. Matz Sels
- 27. Daniel Munoz
- 31. Nikola Milenkovic
- 33. Steven Benda
- 34. Ola Aina
- 37. Nicolo Savona
- 44. Zach Abbott
- 63. Aaron Bott

## Sunderland

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/56/sunderland/overview).

Jogadores nomeados (número de camisa):

- 4. Kevin Danso
- 5. Dan Ballard
- 6. Dayann Methalie
- 7. Chemsdine Talbi
- 8. Alan Browne
- 9. Brian Brobbey
- 10. Nilson Angulo
- 11. Chris Rigg
- 12. Thomas Meunier
- 13. Luke O'Nien
- 14. Romaine Mundle
- 15. Omar Alderete
- 17. Reinildo Mandava
- 18. Wilson Isidor
- 19. Habib Diarra
- 20. Nordi Mukiele
- 21. Simon Moore
- 22. Robin Roefs
- 27. Noah Sadiki
- 28. Enzo Le Fee
- 29. Jules Ahoka
- 31. Melker Ellborg
- 32. Trai Hume
- 34. Granit Xhaka
- 37. Jocelin Ta Bi
- 39. Malick Fofana
- 57. Tymur Tutierov

## Tottenham Hotspur

**Fontes:** [relação oficial 2026/27](https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season); [página do clube na Premier League](https://www.premierleague.com/en/clubs/6/tottenham-hotspur/overview).

Jogadores nomeados (número de camisa):

- 3. Andy Robertson
- 4. Tosin Adarabioyo
- 5. Marcos Senesi
- 6. Jan Paul van Hecke
- 7. Xavi Simons
- 8. Conor Gallagher
- 10. James Maddison
- 11. Mathys Tel
- 13. Destiny Udogie
- 14. Archie Gray
- 15. Lucas Bergvall
- 16. Sandro Tonali
- 17. Savio
- 18. Mateus Fernandes
- 19. Dominic Solanke
- 20. Mohammed Kudus
- 21. Dejan Kulusevski
- 22. Omar Marmoush
- 23. Pedro Porro
- 27. Mykhailo Mudryk
- 28. Wilson Odobert
- 30. Rodrigo Bentancur
- 31. Antonin Kinsky
- 33. Ben Davies
- 37. Micky van de Ven
- 39. Martin Dubravka
- 40. Brandon Austin
- 47. Mikey Moore
- 51. Jacob Knightbridge
- 68. Luca Williams-Barnett

## Referências

[1]: https://www.premierleague.com/en/news/4675097/all-380-fixtures-for-202627-premier-league-season "Premier League: todos os 380 jogos de 2026/27"
[2]: https://www.premierleague.com/en/news/4468487/dates-for-202627-premier-league-season-confirmed "Premier League: datas confirmadas para 2026/27"
[3]: https://www.premierleague.com/en/news/4725682/all-20-premier-league-clubs-squad-numbers-for-202627-season "Premier League: números de elenco dos 20 clubes em 2026/27"
