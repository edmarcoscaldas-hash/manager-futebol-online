# Motsepe Foundation Championship — África do Sul, 2026/27

**País:** África do Sul  
**Campeonato:** Motsepe Foundation Championship (também referida como National First Division)  
**Divisão:** segunda divisão profissional  
**Temporada/status em 12 de novembro de 2026:** em andamento. A PSL anunciou que a competição começaria em 21 de agosto de 2026; a página oficial já apresentava resultados de setembro e notícia de 20 de setembro identificada como jornada 5 da temporada 2026/27. [1] [2]

## Cobertura e critério

A lista abaixo registra os 16 clubes da edição 2026/27. A participação foi conferida contra a página de temporada e os jogos/resultados atuais da PSL; a lista completa de nomes também é exibida na página de temporada de referência secundária [3]. A página oficial da liga consultada apresenta jogos, resultados e notícias, mas não disponibiliza links de plantel/roster para cada clube. Nesta pesquisa não foi localizada uma página oficial de elenco da PSL ou de clube que identificasse, com confirmação inequívoca para 2026/27, os jogadores de todos os participantes. Por isso, não atribuo a 2026/27 listas de temporadas anteriores, nem trato nomes em escalações de partidas como elencos completos. As seções dos clubes identificam explicitamente essa lacuna; **não há nomes de jogadores confirmados para listar neste levantamento**. Comissão técnica não foi incluída.

## Clubes e jogadores publicamente verificáveis

### Cape Town City FC
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Gomora United
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Highbury
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Hope FC
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável. Publicações sociais com números de camisa ou jogadores não foram usadas como confirmação de roster completo.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Hungry Lions FC
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Leicesterford City FC
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Lerumo Lions
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Magesi FC
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável para a temporada.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Midlands Wanderers
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### NWU Soccer Institute / North West University
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável. A PSL apresenta o nome North West University em seus jogos.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Orbit College FC
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Real Native FC
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável. A PSL usa a denominação Real Native FC para o clube nos jogos da temporada.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### University of Pretoria FC / Pretoria University FC
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável. A PSL usa também a forma Pretoria University FC na página de jogos.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Upington City
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### Venda FC
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

### The Bees
- **Jogadores confirmados em elenco 2026/27 localizado:** nenhum nesta pesquisa; não foi encontrada roster page oficial verificável.
- **Fonte de participação/resultados:** [PSL — Motsepe Foundation Championship](https://www.psl.co.za/tournament/national-first-division) [2].

## Referências

[1]: https://psl.co.za/news/article/5615294-psl-confirms-the-202627-season-calend "PSL confirms the 2026/27 season calendar"
[2]: https://www.psl.co.za/tournament/national-first-division "PSL Motsepe Foundation Championship — jogos, resultados e notícias"
[3]: https://en.wikipedia.org/wiki/2026%E2%80%9327_National_First_Division "2026–27 National First Division — lista de clubes"
