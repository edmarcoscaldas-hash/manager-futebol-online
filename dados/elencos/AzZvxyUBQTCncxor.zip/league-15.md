# Egyptian Premier League 2026/27 — clubes e elencos verificáveis

- **País:** Egito.
- **Campeonato:** Egyptian Premier League (EPL; الدوري المصري الممتاز).
- **Divisão:** primeira divisão.
- **Temporada/status:** 2026/27 está em andamento em 12 de novembro de 2026. A temporada começou em 20–21 de agosto; a classificação e os resultados publicados já indicam oito partidas disputadas por equipe. [1] [2]

## Nota de cobertura

A relação dos 20 participantes está confirmada por fontes da temporada. O índice do Transfermarkt identifica a edição 26/27 e fornece páginas individuais de elenco com contagem de jogadores. Não foi possível conferir, nome a nome, todos os registros contra listas oficiais de cada clube ou uma lista oficial integral da liga. O portal da liga consultado não expôs rosters completos por equipe. Para não atribuir nomes incorretos nem reciclar automaticamente a temporada anterior, este relatório não reproduz como integrais listas nominais que não foram verificadas. As seções abaixo cobrem os 20 participantes e apontam páginas específicas de elenco 2026/27; a referência externa é indicada como tal, não como validação independente de cada jogador. [2] [3]

A Ahram Online confirma o formato e os clubes promovidos/rebaixados antes do início da temporada; a lista dos 20 clubes e as páginas individuais de elenco com temporada indicada provêm do índice do campeonato no Transfermarkt. [1] [2]

## Clubes participantes e páginas de elenco 2026/27

### Al Ahly FC
- Jogadores nomeados neste relatório: **nenhum**; ver nota de cobertura.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/al-ahly-fc/kader/verein/7/saison_id/2026) — 37 jogadores indicados.

### Pyramids FC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/pyramids-fc/kader/verein/44664/saison_id/2026) — 34 jogadores.

### Zamalek SC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/zamalek-sc/kader/verein/664/saison_id/2026) — 35 jogadores.

### Cleopatra FC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/cleopatra-fc/kader/verein/57439/saison_id/2026) — 32 jogadores.

### El Masry SC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/el-masry-sc/kader/verein/9094/saison_id/2026) — 34 jogadores.

### Bank El Ahly
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/bank-el-ahly/kader/verein/62448/saison_id/2026) — 31 jogadores.

### Zed FC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/zed-fc/kader/verein/47010/saison_id/2026) — 38 jogadores.

### El Sharkia Enppi FC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/enppi-sc/kader/verein/9218/saison_id/2026) — 42 jogadores.

### Wadi Degla FC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/wadi-degla-fc/kader/verein/18234/saison_id/2026) — 35 jogadores.

### Ittihad Alexandria SC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/ittihad-alexandria-sc/kader/verein/3963/saison_id/2026) — 36 jogadores.

### El Mokawloon SC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/el-mokawloon-sc/kader/verein/3369/saison_id/2026) — 34 jogadores.

### Smouha SC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/smouha-sc/kader/verein/23387/saison_id/2026) — 32 jogadores.

### Suez Petrojet FC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/petrojet/kader/verein/10957/saison_id/2026) — 30 jogadores.

### Modern Sport Club
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/modern-sport-club/kader/verein/68770/saison_id/2026) — 34 jogadores.

### Ghazl El Mahalla
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/ghazl-el-mahalla/kader/verein/13446/saison_id/2026) — 34 jogadores.

### Qanah FC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/qanah-fc/kader/verein/24297/saison_id/2026) — 31 jogadores.

### Tala'ea El Gaish
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/talaea-el-gaish/kader/verein/9219/saison_id/2026) — 32 jogadores.

### El Gouna FC
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/el-gouna-fc/kader/verein/20572/saison_id/2026) — 35 jogadores.

### Petrol Asyut
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/petrol-asyut/kader/verein/16216/saison_id/2026) — 33 jogadores.

### Abo Qir Fertilizers
- Jogadores nomeados neste relatório: **nenhum**.
- [Elenco Transfermarkt 2026/27](https://www.transfermarkt.com/abo-qir-fertilizers/kader/verein/39575/saison_id/2026) — 36 jogadores.

## Referências

[1]: https://english.ahram.org.eg/News/573720.aspx "Ahram Online — participantes e calendário previsto para 2026/27"
[2]: https://www.transfermarkt.com/aigyptiaki-premier-league/startseite/wettbewerb/EGY1 "Transfermarkt — Egyptian Premier League, temporada 2026/27"
[3]: https://egyptianproleague.com/league "Portal oficial da Egyptian Pro League"
