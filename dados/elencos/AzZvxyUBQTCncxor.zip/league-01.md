# Elencos da South African Premiership 2026/27

- **País:** África do Sul
- **Campeonato:** Betway Premiership (South African Premiership)
- **Divisão:** primeira divisão / Premier Division
- **Temporada e status:** 2026/27, em andamento em 12 de novembro de 2026. O site oficial da Premier Soccer League (PSL) apresentava jogos disputados em 30 e 31 de outubro de 2026, partidas futuras de novembro e tabela atual da Premier Division. [1]

## Participantes e jogadores

A relação oficial da PSL identifica os 16 participantes abaixo. Para jogadores, não foi possível estabelecer neste levantamento uma lista nominal completa e suficientemente verificável por elenco, com confirmação independente de que cada nome pertence ao plantel da temporada 2026/27. A fonte pública agregadora consultada permite navegar para páginas de elenco por temporada, mas não equivale a uma lista oficial do clube; sem conferir os registros nominais e a data de vigência em cada elenco, não é seguro transcrever todos os nomes. Por isso, nenhum nome de jogador é atribuído aqui como lista completa. Isso é uma lacuna de cobertura, não uma afirmação de que os clubes não publicaram jogadores. A PSL apresenta perfis oficiais de clubes, porém a página indexada consultada não expôs rosters nominais. [1] [2]

### AmaZulu FC

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/AmaZulu_FC?league=betway-premiership) [1]

### Chippa United

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Chippa_United?league=betway-premiership) [1]

### Durban City

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Durban_City?league=betway-premiership) [1]

### Golden Arrows

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Golden_Arrows?league=betway-premiership) [1]

### Kaizer Chiefs

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Kaizer_Chiefs?league=betway-premiership) [1]

### Kruger United

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Kruger_United?league=betway-premiership) [1]

### Mamelodi Sundowns

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Mamelodi_Sundowns?league=betway-premiership) [1]

### Marumo Gallants

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Marumo_Gallants?league=betway-premiership) [1]

### Milford FC

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Milford_FC?league=betway-premiership) [1]

### Orlando Pirates

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Orlando_Pirates?league=betway-premiership) [1]

### Polokwane City

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Polokwane_City?league=betway-premiership) [1]

### Richards Bay

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Richards_Bay?league=betway-premiership) [1]

### Sekhukhune United

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Sekhukhune_United?league=betway-premiership) [1]

### Siwelele

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Siwelele?league=betway-premiership) [1]

### Stellenbosch FC

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/Stellenbosch_FC?league=betway-premiership) [1]

### TS Galaxy

- **Jogadores 2026/27 confirmados nominalmente neste levantamento:** lista completa não verificada; nomes omitidos.
- **Fonte do clube na PSL:** [perfil oficial](https://www.psl.co.za/club/TS_Galaxy?league=betway-premiership) [1]

## Observações de cobertura

A relação de clubes foi verificada no site oficial da PSL, incluindo a listagem de Premier Division e o Match Centre, que exibia resultados, partidas futuras e tabela da temporada em curso. A página oficial também publicava notícia de 9 de novembro de 2026 sobre prêmios mensais da Betway Premiership, corroborando que a temporada estava em andamento nessa data. [1]

A página da competição no Transfermarkt apresenta seleção explícita 26/27 e links de elenco com temporada 2026 para os clubes; é uma fonte secundária útil para prosseguir a verificação, não substitui confirmação oficial nem prova por si só que todas as inscrições estão atualizadas. Este documento não reutiliza nomes de 2025/26 nem transforma os números agregados do Transfermarkt em elencos nominais. [2]

## Referências

[1]: https://www.psl.co.za/ "Premier Soccer League oficial — clubes, resultados, calendário e notícias"
[2]: https://www.transfermarkt.com/jumplist/startseite/wettbewerb/SFA1 "Transfermarkt — Betway Premiership, temporada 2026/27 e links de elencos"
[3]: https://supersport.com/football/news/e78b92a9-1dde-4d48-ae00-eb44ef504af7/betway-premiership-2026-27-season-launched-as-psl-celebrates-30-years-of-excellence "SuperSport — lançamento da temporada 2026/27"
