# Serie A italiana 2026/27 — clubes e elencos verificáveis

- **País:** Itália
- **Campeonato:** Serie A
- **Divisão:** primeira divisão
- **Temporada/status:** 2026/27 está em andamento. A Lega Serie A identifica o calendário como 2026/2027 e mostra a 12ª rodada marcada para 21–23 de novembro de 2026; em 12 de novembro a rodada ainda era futura. O calendário oficial informa início em 22–23 de agosto de 2026. [1] [2]
- **Cobertura:** a lista oficial identifica 20 clubes. Não foi possível validar, nas páginas públicas examinadas, um elenco completo e explicitamente datado de 2026/27 para cada clube. Para evitar falsos positivos, não se atribuem nomes aos 19 clubes cujas páginas de elenco da liga não foram examinadas. A página de elenco da Juventus foi acessada e seus nomes abaixo são transcritos tal como apresentados; a página mostra 11 jogos disputados, consistente com a temporada em curso. Isso não prova que seja uma lista regulamentar completa ou congelada em uma data específica. [3] [4]

## Clubes participantes e jogadores

Os 20 clubes abaixo constam da lista de clubes da Lega Serie A e da notícia oficial sobre a temporada 2026/27. Os nomes nas seções sem jogadores indicam falta de confirmação nominal de elenco nesta pesquisa, não ausência de jogadores ou de elenco no clube. [1] [3]

### AC Milan
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. A página oficial do clube intitulada “AC Milan Roster and Player Profiles 2026/27” foi localizada, mas o conteúdo acessível na consulta não expôs os nomes dos jogadores. [5]

### Atalanta
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Atalanta](https://www.legaseriea.it/team/atalanta/squad).

### Bologna
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Bologna](https://www.legaseriea.it/team/bologna/squad).

### Cagliari
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Cagliari](https://www.legaseriea.it/team/cagliari/squad).

### Como
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Como](https://www.legaseriea.it/team/como/squad).

### Fiorentina
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Fiorentina](https://www.legaseriea.it/team/fiorentina/squad).

### Frosinone
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Frosinone](https://www.legaseriea.it/team/frosinone/squad).

### Genoa
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Genoa](https://www.legaseriea.it/team/genoa/squad).

### Inter
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Inter](https://www.legaseriea.it/team/inter/squad).

### Juventus
A página de elenco oficial da liga lista os seguintes nomes por posição. A página consultada não declara no texto extraído uma data de atualização nem uma temporada selecionável, portanto os nomes são registrados como **publicados na página consultada durante 2026/27**, não como garantia de elenco integral em uma data de corte. [4]

- **Goleiros:** Carlo Pinsoglio; Guglielmo Vicario; Kamil Mieczyslaw Grabara; Norberto Murara Neto; Raffaele Huli; Riccardo Adrian Radu.
- **Defensores:** Bremer; Andrea Cambiaso; Daniele Rugani; Federico Gatti; Filippo Pagnucco; Francesco Verde; Jhon Janer Lucumi' Bonilla; Juan David Cabal Murillo; Lloyd Casius Kelly; Mehmet Zeki Çelik; Niccolò Rizzo; Pierre Kazaye Rommel Kalulu Kyatengwa.
- **Meio-campistas:** Augusto Sedorf Owusu; Douglas Luiz Soares De Paulo; Grady Makiobo Makiobo; Khephren Thuram-ulien; Manuel Locatelli; Pape Matar Sarr; Teun Koopmeiners; Weston James Earl McKennie.
- **Atacantes:** Arkadiusz Milik; Arman Durmiši; Destiny Elimoghale; Edon Zhegrova; Francisco Fernandes da Conceição; Ismael Konate; Jeremie Boga; Justin Oke Oboavwodou; Kenan Yildiz; Kerim Alajbegović; Nick Woltemade; Nicolás Ivan González; Osayuki Jeff Ekhator; Randal Kolo Muani.

### Lazio
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Lazio](https://www.legaseriea.it/team/lazio/squad).

### Lecce
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Lecce](https://www.legaseriea.it/team/lecce/squad).

### Monza
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Monza](https://www.legaseriea.it/team/monza/squad).

### Napoli
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Napoli](https://www.legaseriea.it/team/napoli/squad).

### Parma
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Parma](https://www.legaseriea.it/team/parma/squad).

### Roma
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Roma](https://www.legaseriea.it/team/roma/squad).

### Sassuolo
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Sassuolo](https://www.legaseriea.it/team/sassuolo/squad).

### Torino
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Torino](https://www.legaseriea.it/team/torino/squad).

### Udinese
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Udinese](https://www.legaseriea.it/team/udinese/squad).

### Venezia
**Jogadores confirmados nesta pesquisa:** nenhum nome listado. Página de elenco da liga: [Lega Serie A — Venezia](https://www.legaseriea.it/team/venezia/squad).

## Referências

[1]: https://en.legaseriea.it/serie-a/news/looking-forward-to-the-2026-27-serie-a-fixture-list "Lega Serie A — times e datas de 2026/27"
[2]: https://en.legaseriea.it/serie-a/fixtures-results "Lega Serie A — calendário e resultados 2026/2027"
[3]: https://en.legaseriea.it/team "Lega Serie A — lista de clubes"
[4]: https://www.legaseriea.it/team/juventus/squad "Lega Serie A — elenco da Juventus"
[5]: https://www.acmilan.com/en/teams/men-first-team "AC Milan — elenco masculino 2026/27"
