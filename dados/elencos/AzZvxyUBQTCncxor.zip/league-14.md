# K League 2 — Coreia do Sul

**País:** Coreia do Sul  
**Campeonato:** Hana Bank K League 2  
**Divisão:** segunda divisão profissional  
**Temporada solicitada:** “2026/27” não é a designação encontrada nas fontes oficiais. A liga disputa temporadas por ano civil e a edição pertinente é **2026**.  
**Status em 12 de novembro de 2026:** temporada 2026 já estava em andamento (a rodada inaugural ocorreu de 28 de fevereiro a 2 de março). A prévia oficial confirma uma edição de 17 clubes e é datada de 27 de fevereiro de 2026. Não se trata de uma temporada ainda por começar. [1]

## Cobertura e limite da informação

A liga confirma 17 participantes, mas a fonte oficial acessível usada nesta pesquisa é uma prévia de rodada, não um cadastro completo e atualizado de jogadores por clube. Para evitar transportar elencos de anos anteriores ou apresentar nomes não verificados, abaixo estão listados apenas jogadores reais explicitamente mencionados na prévia oficial de 2026. A lista nominal por clube é, portanto, **parcial, não um elenco completo**; o clube sem nomes na prévia é assinalado. A prévia também menciona nomes em contexto de chegadas, permanências ou destaques e não deve ser interpretada como cadastro registral atual. Não foi possível verificar, nesta pesquisa, uma página pública oficial de elenco 2026 integral para cada equipe.

## Clubes participantes e jogadores nomeados

### Gimhae FC
Choe Pil-su, Lee Seul-chan, Seol Hyeon-jin, Bruno Costa e Beka. [1]

### Ansan Greeners
Yeon Je-min, Ryu Seung-woo, Cho Ji-hun e Lee Seung-bin. [1]

### Suwon Samsung Bluewings
Hong Jeong-ho, Song Ju-hun, Lee Jun-jae, Kim Joon-hong, Fessin, Reis, Park Hyun-bin, Jung Ho-yeon e Ko Seung-beom. [1]

### Seoul E-Land FC
Euller, Bak Jae-yong, Kim Hyun e Min Seong-jun. [1]

### Yongin City FC
Shin Jin-ho, Choi Young-jun, Kim Bo-sub, Im Chai-min, Suk Hyun-jun e Novo. [1]

### Cheonan City FC
Toungara, Lamas e Park Dae-han. [1]

### Daegu FC
Cesinha, Edgar, Han Kook-young, Ryu Jae-moon e Serafim. [1]

### Hwaseong FC
Demethryus, Vojnovic, Pllana e Jang Min-jun. [1]

### Chungbuk Cheongju FC
A prévia oficial consultada não nomeia jogadores deste clube. [1]

### Suwon FC
Willyan, Matheus Barcelos, Frizzo, Hoel e Derlan. [1]

### Gyeongnam FC
Yoon Il-lok, Lee Beom-soo, Won Ki-jong e Lee Chan-dong. [1]

### Jeonnam Dragons
Valdivia. A prévia diz que o clube reteve a maioria dos principais jogadores, mas não fornece uma lista nominal completa. [1]

### Chungnam Asan FC
A prévia oficial consultada não nomeia jogadores que integrem o elenco de 2026; cita atletas em contexto de saídas, que foram deliberadamente excluídos. [1]

### Paju Citizen FC
Lee Joon-suk, Hong Jeong-un e Jeon Hyeon-byung. [1]

### Busan IPark
Gabriel, Ahn Hyun-beom e Woo Joo-seong. [1]

### Seongnam FC
Shun, Ryoji, Angelotti, Freitas, Venicio e Park Soo-bin. [1]

### Gimpo FC
A prévia confirma que o Gimpo FC era participante (e folgava na rodada de abertura), mas não nomeia jogadores deste clube. [1]

## Referências

[1]: https://www.kleague.com/news_view.do?seq=94460&category=league&orderBy=seq&viewOption=album&page=7 "K League — Hana Bank K League 2 2026 Round 1 Preview"
[2]: https://www.kleague.com/ "K League — site oficial"
[3]: https://www.transfermarkt.com/k-league-2/startseite/wettbewerb/RSK2 "Transfermarkt — K League 2 2026"
