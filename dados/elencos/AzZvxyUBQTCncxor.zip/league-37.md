# Liga Portugal 2 — clubes e elencos 2026/27

- **País:** Portugal
- **Campeonato:** Liga Portugal 2 Meu Super
- **Divisão:** segunda divisão (segundo escalão nacional)
- **Temporada/status:** 2026/27 está em andamento. A Liga Portugal anunciou o início para o fim de semana de 9 de agosto de 2026; a edição listada publicamente já apresenta jogos disputados até a 9.ª jornada, em novembro de 2026. Portanto, não se trata de uma temporada ainda por começar. [1] [2]

## Cobertura e limite de verificação

A edição 2026/27 da competição identifica os 18 clubes abaixo, e a Transfermarkt também identifica 18 participantes e oferece páginas de elenco com seletor explícito de temporada 26/27. [2] [3] Não consegui, nesta pesquisa, extrair e conferir listas nominais completas para todos os 18 clubes. Para não apresentar um elenco incompleto como se fosse completo nem transpor nomes da temporada passada, as seções indicam nominalmente apenas o que foi possível ler diretamente na página de elenco consultada: uma amostra parcial do Benfica B. As páginas de elenco das demais equipes são fornecidas para consulta direta, mas nenhum nome foi presumido ou inventado.

A lista abaixo é a cobertura completa dos clubes participantes; **a cobertura de jogadores é parcial e não constitui uma relação completa de elenco**. A página da Liga Portugal confirma o nome da competição e o calendário, mas não foi localizada uma página oficial pública com elencos nominais completos para cada clube.

## AFS

**Jogadores nominalmente verificados neste levantamento:** nenhum. A página de participantes da temporada o identifica como clube da edição. [2] [3]

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/avs-futebol/kader/verein/110302/saison_id/2026)

## FC Vizela

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/fc-vizela/kader/verein/6912/saison_id/2026)

## FC Felgueiras 1932

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/fc-felgueiras-1932/kader/verein/1701/saison_id/2026)

## Leixões SC

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/leixoes-sc/kader/verein/3345/saison_id/2026)

## GD Chaves

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/gd-chaves/kader/verein/3325/saison_id/2026)

## FC Penafiel

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/fc-penafiel/kader/verein/3327/saison_id/2026)

## Académica OAF

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/academica-coimbra/kader/verein/2990/saison_id/2026)

## Amarante FC

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/amarante-fc/kader/verein/7789/saison_id/2026)

## CD Feirense

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/cd-feirense/kader/verein/3349/saison_id/2026)

## Lusitânia FC Lourosa

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/lusitania-fc-lourosa/kader/verein/8189/saison_id/2026)

## FC Porto B

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/fc-porto-b/kader/verein/10331/saison_id/2026)

## Portimonense SAD

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/portimonense-sad/kader/verein/7378/saison_id/2026)

## SC Farense

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/sc-farense/kader/verein/4294/saison_id/2026)

## SL Benfica B

**Jogadores nominalmente verificados (lista parcial, não elenco integral):** Diogo Ferreira; Arnas Voitinovičius; Gonçalo da Silva; Gabriel Índio; Rui Silva; João Fonseca; José Neto; João Capucho; Leandro Martins; Daniel Banjaqui; Duarte Soares; Kevin Pinto; Diogo Coelho; Nuno Félix; Martim Ferreira; Rafael Quintas; Miguel Figueiredo; Federico Coletta; Tiago Freitas. A página identifica a temporada 26/27 e classifica os nomes como jogadores; a extração visível não permitiu confirmar todo o restante elenco, por isso esta amostra não deve ser tomada como relação completa. [4]

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/sl-benfica-b/kader/verein/10330/saison_id/2026)

## Sporting CP B

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/sporting-cp-b/kader/verein/10949/saison_id/2026)

## CD Tondela

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/cd-tondela/kader/verein/7179/saison_id/2026)

## SC União Torreense

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/sc-uniao-torreense/kader/verein/2432/saison_id/2026)

## UD Leiria

**Jogadores nominalmente verificados neste levantamento:** nenhum.

Fontes: [edição 2026/27](https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295) · [elenco 26/27 na Transfermarkt](https://www.transfermarkt.com/ud-leiria/kader/verein/2639/saison_id/2026)

## Referências

[1]: https://www.ligaportugal.pt/news/27682/definido-o-arranque-das-competicoes-profissionais-2026-27 "Liga Portugal confirma data de início das competições 2026-27"
[2]: https://www.zerozero.pt/edicao/liga-portugal-2-meu-super-2026-27/218295 "Edição Liga Portugal 2 Meu Super 2026-27"
[3]: https://www.transfermarkt.com/liga-sabseg/startseite/wettbewerb/PO2 "Clubes da Liga Portugal 2 2026-27"
[4]: https://www.transfermarkt.com/sl-benfica-b/kader/verein/10330/saison_id/2026 "Elenco do SL Benfica B para a temporada 2026-27"
