# Liga Portugal Betclic 2026/27 — clubes e elencos verificáveis

- **País:** Portugal
- **Campeonato:** Liga Portugal Betclic
- **Divisão:** Primeira Liga (1.ª divisão)
- **Temporada/status em 12 de novembro de 2026:** a competição está identificada no site oficial como época 2026–2027 e a Liga publicou aviso de inscrições de jogadores em setembro de 2026. Porém, a página oficial da competição consultada não exibia classificação nem jogos; portanto, não foi possível confirmar por essa fonte os participantes ou o andamento efetivo. A temporada não deve ser tratada como futura/pré-temporada com base na data, mas os dados públicos capturados são inconsistentes/incompletos.

## Cobertura e ressalva

Não é possível fornecer com segurança uma lista nominal completa dos jogadores de cada elenco a partir das fontes que puderam ser verificadas. O aviso oficial de inscrições não expôs o conteúdo/lista de jogadores na página acessível, e a página oficial da competição retornou “Não foi encontrada classificação” e “Não foram encontrados jogos”. A página do Transfermarkt intitulada “Clubes da Liga Portugal 26/27” exibe 18 clubes e contagens de plantel, mas a informação de temporada ali não foi corroborada pela página oficial consultada; por isso, a relação abaixo é **provisória e atribuída à fonte secundária**, não uma confirmação oficial dos participantes. Não copiei nomes de elencos da temporada anterior nem converti contagens secundárias em listas de jogadores. Em consequência, não são apresentados nomes de jogadores não verificados.

A lista abaixo cobre os 18 clubes que aparecem na página secundária de temporada 26/27. Para cada clube, o link de elenco é a página de plantel dessa temporada no Transfermarkt. Estes links apontam para elencos consultáveis, mas não são tratados aqui como prova suficiente para afirmar que cada nome estava inscrito/pertencia ao clube em 12/11/2026.

## Clubes e elencos

### Sporting CP
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 31 jogadores no plantel; isso é uma contagem, não uma relação nominal confirmada neste relatório.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/sporting-cp/kader/verein/336/saison_id/2026).

### FC Porto
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 29 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/fc-porto/kader/verein/720/saison_id/2026).

### SL Benfica
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 29 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/sl-benfica/kader/verein/294/saison_id/2026).

### SC Braga
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 38 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/sc-braga/kader/verein/1075/saison_id/2026).

### FC Famalicão
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 26 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/fc-famalicao/kader/verein/3329/saison_id/2026).

### GD Estoril Praia
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 26 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/gd-estoril-praia/kader/verein/1465/saison_id/2026).

### Vitória SC
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 28 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/vitoria-sc/kader/verein/2420/saison_id/2026).

### Gil Vicente FC
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 27 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/gil-vicente-fc/kader/verein/2424/saison_id/2026).

### CD Santa Clara
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 36 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/cd-santa-clara/kader/verein/2423/saison_id/2026).

### Rio Ave FC
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 25 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/rio-ave-fc/kader/verein/2425/saison_id/2026).

### FC Arouca
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 28 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/fc-arouca/kader/verein/8024/saison_id/2026).

### FC Alverca
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 24 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/fc-alverca/kader/verein/2521/saison_id/2026).

### CD Nacional
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 28 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/cd-nacional/kader/verein/982/saison_id/2026).

### Moreirense FC
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 25 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/moreirense-fc/kader/verein/979/saison_id/2026).

### Casa Pia AC
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 23 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/casa-pia-ac/kader/verein/3268/saison_id/2026).

### CF Estrela Amadora
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 29 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/cf-estrela-amadora/kader/verein/2431/saison_id/2026).

### Académico de Viseu FC
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 23 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/academico-de-viseu-fc/kader/verein/7788/saison_id/2026).

### CS Marítimo
- **Jogadores nominalmente confirmados neste levantamento:** nenhum. A página secundária indica 26 jogadores.
- Fonte de elenco: [Transfermarkt — plantel 2026](https://www.transfermarkt.pt/cs-maritimo/kader/verein/1301/saison_id/2026).

## Referências

[1]: https://www.ligaportugal.pt/competition/911/liga-portugal-betclic/round/20262027 "Liga Portugal Betclic 2026/27 — página oficial da competição"
[2]: https://www.ligaportugal.pt/news/28214/inscricoes-oficiais-liga-portugal-betclic-%28atualizacao-28-de-agosto%29 "Liga Portugal — inscrições oficiais, atualização de 4 de setembro de 2026"
[3]: https://www.transfermarkt.pt/liga-portugal/startseite/wettbewerb/PO1 "Transfermarkt — clubes da Liga Portugal 26/27"
