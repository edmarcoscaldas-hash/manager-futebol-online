# Liga de Expansión MX — temporada 2026/27

**País:** México  
**Campeonato:** Liga de Expansión MX (Liga BBVA Expansión MX)  
**Divisão:** segunda divisão profissional  
**Status em 12 de novembro de 2026:** temporada em andamento. O Apertura 2026 já completou a fase regular e está nas semifinais; o Clausura 2027 ainda não começou. O próprio site oficial exibe notícias de 10/11/2026 sobre as semifinais do Apertura e estatísticas identificadas como Apertura 2026-2027. [1] [2]

## Cobertura e critério

A fonte primária consultada foi a seção **Plantilla** dos perfis oficiais de cada clube no site da Liga BBVA Expansión MX. Os nomes abaixo são os jogadores que aparecem na plantilla publicada ao consultar a página; comissão técnica foi excluída. As páginas oficiais estavam vinculadas à temporada corrente, mas não exibiam necessariamente um carimbo de data de atualização. Portanto, a lista reflete a plantilla pública consultada em 12/11/2026, e não uma garantia de registro federativo definitivo ou de permanência até o Clausura. Foram encontrados perfis oficiais de todos os 16 clubes que aparecem na tabela do Apertura 2026 da ESPN; a lista de participantes foi conferida também na classificação oficial da liga. [1] [2] [3]

A listagem abaixo transcreve nomes exibidos, em formato abreviado tal como apresentados no cartão da plantilla oficial. Esta pesquisa não encontrou uma fonte oficial separada que certificasse historicamente cada nome em uma data de corte ou cobrisse eventuais alterações posteriores. Não foram completadas lacunas com elencos de 2025/26. As URLs diretas por clube permitem verificar a plantilla publicada.

## Clubes e jogadores

### Alacranes de Durango
Jared Muñoz, Erick De Loa, Dylan Flores, Alejandro Peláez, Andy García, Jesús González, José Múñoz, Miguel Lozano, Jan Ontiveros, José Castillo, David Oteo, Iñaki Castillo, Sergio Flores, Eric Cantú, César Vega, Luis Gutiérrez, Tomás Montano, Jair González, Luis Morales, Rubén Domínguez, Aldieri Valenzuela, Carlos Siqueiros, Brayan Muñóz, Jared Torres, Jesús Escoboza, José Ramírez, Luis Loroña, José Reyes, Juan Angulo. [4]

### Alebrijes de Oaxaca
Carlos Rodas, Octavio Paz, Mario Fuentes, Adrián Justo, Kristian Álvarez, Ethan López, Josué Reyes, Adrián Vázquez, David Collazo, Jhabdul Gonzalez, Tristhan Jaimes, Ángel Hernández, Ángel Tecpanécatl, Sebastián Vizarretea, Aldo Arellano, Michelle Morales, Patrick Villa, Bubakarry Fadika, David Ayala, Miguel Carreón, Alfonso Sánchez, Luke Jeffus, Jorge Alaniz, Guillermo Arteaga, Israel García, Andrey Andrade, Adolfo Valdez, Sergio Gallinar, Diego Martínez. [5]

### Club Atlético La Paz
Carlos Moreno, Jonathan Estrada, Gil Alcalá, Daniel Vázquez, Sergio Vázquez, Daniel Alvarado, Horacio Torres, Yahir Del Aguila, Carlos Robles, Juan Daccarett, Ulises Zurita, Alan Torres, Daniel Hernández, Antonio Soto, Ricardo Rentería, Oscar Millán, Edgar Alaffita, Luis Chiu, Israel Larios, Marco García, Fernando Illescas, Ángel Robles, Johan Alonzo, Jorge Ferrer, Martín Barragán, Ulíses Jaimes. [6]

### Club Atlético Morelia
Roberto Galan, Daniel Fuentes, Ramón Pasquel, René López, Sebastián Hernández, Daniel Zamora, Josecarlos Van Rankin, Roberto Castellanos, Orlando Botello, Gabriel Martínez, Diego Aguilar, Edgar Sánchez, Paulo Romero, Edgar Martínez, Josué Domínguez, Víctor López, Alejandro Andrade, Raúl Sandoval, Mauro Nambo, Michell Rodríguez, Edson Castellanos, Jaziel Martínez, Juan Conejo, Ruben Del Campo, José Flores, Ander Izarra. [7]

### Cancún FC
Edson Arce, Erick Montiel, Alek Álvarez, Jonathan Hernández, Rodrigo Reyes, Jair Cortés, Daniel Guillén, Luis Ruiz, Armando Chávez, Bruce El-mesmari, Francisco Melendre, Francisco Uscanga, Karel Campos, Damián Lomelí, Leonel López, Gipson Preciado, Aarón Arredondo, Christo Vela, Thiago Gigena, Christopher Trejo, José Rodríguez, Gael Gutiérrez. [8]

### Correcaminos UAT
Emiliano Pérez, Edson Reséndez, Walter Ortega, Jesús Piñuelas, Alex Monárrez, Alan Ruiz, Andrés Catalán, Alan Di Pippa, Ricardo González, Oliver Pérez, Omar Islas, Raúl Torres, Wiliam Guzmán, Héctor Uribe, Nahúm Gómez, Gerardo Moreno, Jorge Zapata, Joaquín Estopier, Vicente Torres, Duvan Mina, César Sosa, Juan Cantú, Rafael Arce, Bryan Mendoza, Tomas Sandoval. [9]

### Cruz Azul Hidalgo
Nicolás Calixto, Bruno Salgado, Leonardo Sámano, Josué Díaz, Diego Ramírez, José Suarez, Karol Velázquez, André Cubillas, Iván Silva, Louis Estrada Derbez, Jorge García, Cristhian Leon, Sergio De Los Ríos, Kenneth González, Luis De Jesús, Víctor Taboada, Rogelio González, Jesús Lara, Diego Valdéz, Emmanuel Sánchez, Ariel Castro, Emanuel Rodríguez, Ángel Saavedra, Christian Valdivia, Víctor Velázquez, Fabrizzio Orozco. [10]

### Dorados de Sinaloa
José Castro, Jonathan Vaal, Irwin Zamudio, Ismael Flores, Sebastián Yanez, Diego García, Ramiro Franco, Abraham Flores, Sebastián Cervantes, David Osuna, Willian Gonzalez, Emiliano Velazco, Edson Gutiérrez, Christopher Castro, Dylan Guajardo, Jaime Álvarez, Carlos Galicia, Francisco Contreras, Arath Egaña, Germán Padilla, Martín Sol, Christian Castillo, Fernando González, Michael Ponce, Marcos Flores, Brandon Ordorica, Jhan Rengifo, Leonardo Vargas, Benjamín Sánchez, Oscar Coronel, Jakson Porozo. [11]

### Jaiba Brava
Joel García, Gerardo Ruíz, Roberto Elicerio, Luciano Bocco, Ricardo Peña, Alberto Ríos, José López, Ian Ramírez, Jonathan Tovar, Néstor Arriaga, Axl Padilla, Oscar Manzanarez, Iván Ochoa, Deivoon Magaña, Ronaldo González, Edson Torres, Cristian Cruz, Néstor Corona, Aldo Serna, Jesús López, Sebastián Martínez, Jesús Ocejo, André Ham, Jonathan Martínez, Daniel López, Eduardo Escalante. [12]

### Leones Negros UdeG
Oziel Cantú, Sebastián Martín, Luis Flores, Ulises Torres, Olaf González, Juan Aguayo, Ulíses Meza, Alejandro Bravo, Leonardo Sepulveda, Juan Cázares, Jahaziel Marchand, Juan Brigido, Joel Pérez, Alejandro Carreón, Mauro Valenzuela, Sergio Hernández, Luis Razo, Kevin Loera, Oscar Gil. [13]

### Mineros de Zacatecas
Leonardo Durán, Julio Valenzuela, Luis Cervantes, Salvador Manríquez, Diego Marmolejo, Justing Cano, Luis Hernández, Oscar Mazatán, Weymmar Castro, Alonso García, Paolo Ríos, Erick Carballo, José Ávila, Luis Sandoval, José Esquivel, Andrés Mendoza, Kevin Magaña, Pablo Padilla, Adrián Villalobos, Japheth Jiménez, Juan Machado, Mauro Pérez. [14]

### Piratas FC
David Sánchez, Humberto Hernández, Juan Gómez, Adrián Mantilla, Kenneth Jaime, Ángel López, Diego Cruz, Rolando González, Ramón Palomares, Eduardo Ochoa, Uziel García, José Hernández, Omar Soto, Brian Figueroa, Gabriel López, Antonio Álvarez, Christian Fernández, Edwin Vargas, Jesús Venegas, Martín Jiménez, Roberto Hidalgo, Francisco García, Ricardo Cuevas, Diego Sánchez, Anton Enciso, Ibe Doumbouya, Daniel Lajud, Juan Gamboa. [15]

### Tapatío
Eduardo García, Axel Leyva, Diego Delgadillo, Rodrigo Parra, Carlos Hernández, Carlo Soldati, Raúl Nuño, Sebastián Esparza, Ángel Chávez, Matías Cendejas, Saúl Zamora, Leonardo Jiménez, Juan Uribe, Cristian Inda, Luis Ledesma, Brandon Téllez, Carlos Corona, Gael García, Vladimir Moragrega, Cruz Medina, Jesús Hernández, Diego Latorre, Daniel Villaseca, Leonardo Torres. [16]

### Tepatitlán FC
Alain Estrada, Arturo Gatica, Diego Rodríguez, Gerardo Sánchez, Israel Contreras, Ricardo Alonso, Gabriel Báez, Neri Martínez, Jorge Ríos, Jorge Cervantes, Hassan Aguilar, Said Castañeda, Marco Zavala, Víctor Hernández, Marco López, Bryan Casas, Jonathan Sánchez, Arturo Cárdenas, Dieter Villalpando, Erick Ruiz, Leonardo Bolaños, Hugo Vázquez, Gustavo Olvera, Salvador Rodríguez, Edson Martínez, Fernando Osorio, Arath Moreno, José García, Raúl Ruíz, Nestor Arevalo, Esteban Alcantar, Luis Egurrola, Alfonso Tamay, Franco Modica, Luis Paez, Samuel González, José Godínez, Horace Avila, Julio Cruz. [17]

### Tlaxcala FC
Norberto Bedolla, Abraham Nuño, Andrey Luna, Ismael Govea, Cristian González, Edson Santos, Carlos Hinestroza, Julián Freyfeld, Edson García, Mario Trejo, Roger Hernández, Andrés Iniestra, Emmanuel Hernández, José Plascencia, Francisco Figueroa, Daniel Álvarez, Miguel Ramírez, Jesse Zamudio, Josué Gómez, Adrián Sánchez, Pablo González, Bryan Flores, Juan Blanco, Jesús Hernández, Christian Mota De Oliveira, Raúl Camacho, Erick Robles. [18]

### Venados FC
Cristian González, Santiago Pérez, Ángel Arredondo, Rubén Castellanos, Maximiliano Pinela, Axel Grijalva, Brandon Ochoa, Santiago Montiel, Juan Cruz, Jesús Moreno, Marco Montelongo, Idekel Domínguez, Mauricio Aguilar, Sebastian Saucedo, Santiago Naveda, Erick Torres, Adolfo Domínguez, Duilio Tejeda, Luis Macías, Khaled Amador, Santiago Benitez, Maximo Torres, Asael Hernandez, Jacobo Reyes, Paul Kilani, Lucas Lazarte, Luis Arroyo, Sleyther Lora, Jardel Cejudo. [19]

## Referências

[1]: https://www.ligabbvaexpansion.mx/ "Site oficial da Liga BBVA Expansión MX"  
[2]: https://espndeportes.espn.com/futbol/posiciones/_/liga/mex.2 "Classificação da Liga de Expansión MX 2026-27, ESPN Deportes"  
[3]: https://en.wikipedia.org/wiki/2026%E2%80%9327_Liga_de_Expansi%C3%B3n_MX_season "Temporada 2026–27, referência secundária para calendário e contexto"  
[4]: https://www.ligabbvaexpansion.mx/cancha/club/14295/durango "Alacranes de Durango — plantilla oficial"  
[5]: https://www.ligabbvaexpansion.mx/cancha/club/11780/alebrijes "Alebrijes — plantilla oficial"  
[6]: https://www.ligabbvaexpansion.mx/cancha/club/12578/club-atletico-la-paz "Atlético La Paz — plantilla oficial"  
[7]: https://www.ligabbvaexpansion.mx/cancha/club/12060/ca-morelia "Atlético Morelia — plantilla oficial"  
[8]: https://www.ligabbvaexpansion.mx/cancha/club/12584/cancun-fc "Cancún FC — plantilla oficial"  
[9]: https://www.ligabbvaexpansion.mx/cancha/club/21/correcaminos "Correcaminos — plantilla oficial"  
[10]: https://www.ligabbvaexpansion.mx/cancha/club/14259/cruz-azul-hidalgo "Cruz Azul Hidalgo — plantilla oficial"  
[11]: https://www.ligabbvaexpansion.mx/cancha/club/3111/dorados "Dorados — plantilla oficial"  
[12]: https://www.ligabbvaexpansion.mx/cancha/club/14260/jaiba-brava "Jaiba Brava — plantilla oficial"  
[13]: https://www.ligabbvaexpansion.mx/cancha/club/33/u-de-g "Leones Negros — plantilla oficial"  
[14]: https://www.ligabbvaexpansion.mx/cancha/club/12061/mineros-zacatecas "Mineros de Zacatecas — plantilla oficial"  
[15]: https://www.ligabbvaexpansion.mx/cancha/club/14266/piratas-fc "Piratas FC — plantilla oficial"  
[16]: https://www.ligabbvaexpansion.mx/cancha/club/12058/tapatio "Tapatío — plantilla oficial"  
[17]: https://www.ligabbvaexpansion.mx/cancha/club/12064/tepatitlan-fc "Tepatitlán FC — plantilla oficial"  
[18]: https://www.ligabbvaexpansion.mx/cancha/club/11592/tlaxcala "Tlaxcala — plantilla oficial"  
[19]: https://www.ligabbvaexpansion.mx/cancha/club/10732/venados "Venados — plantilla oficial"
