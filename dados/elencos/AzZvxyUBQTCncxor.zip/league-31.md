# Botola Pro 2026/27 — clubes e jogadores

**País:** Marrocos  
**Campeonato:** Botola Pro Inwi  
**Divisão:** 1ª divisão (D1)  
**Temporada/status:** 2026/27 em andamento em 12 de novembro de 2026. A listagem da FRMF para D1 mostra partidas datadas de 4 de novembro de 2026; a página de competição do Transfermarkt seleciona 26/27 e apresenta calendário/posição da temporada.

**Nota de cobertura:** Foram identificados os 16 participantes e consultadas páginas de elenco marcadas 26/27 do Transfermarkt, que são fonte secundária, não um cadastro oficial. As listas abaixo reproduzem os nomes publicamente listados nessas páginas no momento da consulta; podem não equivaler ao registro federativo completo, e a FRMF não disponibilizou, no material acessível, uma página oficial de elenco por clube. Não foram importados nomes de temporadas anteriores. O número entre parênteses é o total de perfis extraídos; um eventual descompasso com contagem de elenco indica cobertura incompleta da página/fonte, não licença para completar nomes.

A federação marroquina mantém a área oficial da Botola Pro D1 e seu calendário: [FRMF — Botola Pro D1](https://frmf.ma/fr/botola-pro/d1) e [calendário D1](https://frmf.ma/fr/botola-pro/d1/programme). A referência da competição 26/27 usada para listar clubes é [Transfermarkt — Botola Pro Inwi 26/27](https://www.transfermarkt.com/botola-pro-inwi/startseite/wettbewerb/MAR1).

## Renaissance de Berkane (27 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/renaissance-de-berkane/kader/verein/37176/saison_id/2026).

- Munir El Kajoui
- Youssef El Motie
- Mehdi Maftah
- Ismaël Kandouss
- Jamal Harkass
- Adil Tahif
- Oussama Haddadi
- Hamza El Moussaoui
- Mohamed Aymen Sadil
- Haytam Manaout
- Et-Tayeb Boukhriss
- Youssef Aït Bennasser
- Abdelghafour Lamirat
- Soumaila Sidibe
- Ayoub Khairi
- Rayane Aabid
- Mohamed Ouyahia
- Yassine Labhiri
- Zinédine Machach
- Mohamed Amine Essahel
- Omar El Manssouri
- Reda Hajji
- Mounir Chouiar
- Youssef Mehri
- Ryan Mendes
- Oussama Lamlioui
- Youness El Kaabi

## Wydad Casablanca (34 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/wydad-casablanca/kader/verein/6603/saison_id/2026).

- El Mehdi Benabid
- Rachid Ghanimi
- Omar Aqzdaou
- Ayman El Wafi
- Issoufou Dayo
- Sallah Moussaddaq
- Salaheddine Cofi
- Guilherme Ferreira
- Mohammed El Jadidi
- Ayman Dairani
- Yahia Attiyat Allah
- Hamza Jananallah
- Mohamed Moufid
- Walid Atik
- Yahya Jabrane
- Nizar Al-Rashdan
- Adil Khalloufi
- Rayane Mahtou
- Oussama Zemraoui
- Joseph Bakasu
- Naïm Byar
- Aymane El Hassouni
- Pedrinho
- Moisés Paniagua
- Mouad Enzo
- Yassine Jabrane
- Zouhair El Moutaraji
- Zacarías Ghailán
- Walid Nassi
- Haitam Hamani
- Silvere Ganvoula
- Hamza Hannouri
- Soufiane Hetli
- Ahmed Rhailouf

## Raja Club Athletic (29 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/raja-casablanca/kader/verein/2068/saison_id/2026).

- El Mehdi Al Harrar
- Khalid Kbiri Alaoui
- Yassine Zoubir
- Marian Huja
- Badr Benoun
- Ismail Mokadem
- Bouchaib Arrassi
- Chemseddine Knaidil
- Amine Khammas
- Mohamed Boulacsout
- Ayoub El Amloud
- Ishak Zidani
- Michael Agbekpornu
- Othmane Chraibi
- Anas Benomar
- Mohamed Al-Makahasi
- Younes Bakiz
- Aymen Barkok
- Adam Ennaffati
- Youness Dahmani
- Pape Ousmane Sakho
- Felipinho
- Mohammad Abu Zrayq
- Bilal Ould-Chikh
- Adel Bettaieb
- Mounaïm El Idrissy
- Mathias Oyewusi
- Ismail Khafi
- Yahya Iguiz

## AS FAR Rabat (27 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/far-rabat/kader/verein/9099/saison_id/2026).

- Ahmed Reda Tagnaouti
- Mohamed Jemjami
- Ayoub El Khayati
- Hakim Mesbahi
- Fallou Mendy
- Marouane Louadni
- Ayoub Ait Khassou
- Nabil Marmouk
- Tó Carneiro
- Jamal Ech-Chamakh
- Nadir Lougmani
- Anas Bach
- Zineddine Derrag
- Abdelfettah Hadraf
- Khalid Aït Ouarkhane
- Soulaimane El Bouchqali
- Allan Okello
- Merveil Ndockyt
- Jalal-Eddine El Khfiyef
- Youssef El Fahli
- Yazid Faffa
- Ahmed Hammoudan
- Salaheddine Errahouli
- Marouane Oujeddou
- Mouhcine Bouriga
- Joel Beya
- Jephte Kitambala

## MAS Fès (28 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/mas-fes/kader/verein/3282/saison_id/2026).

- Salaheddine Chihab
- Oussama Errahmany
- Walid Laghrissi
- Mohamed Jaouab
- Abdellah Khafifi
- Aymane Chbani
- Samba Mbengue
- Adil Rhaili
- Marouane Ouhrou
- Diogo Calila
- Hamza Ait Allal
- Salaheddine Ghedamsi
- Oussama Noureddine
- Mounir El Gouje
- Achraf Harmach
- Anas Tahiri
- Hamza Afsal
- El Habib Brija
- Soulyman Allouch
- Anas El Mahraoui
- Devin Titus
- Amine El Farissi
- Adam Brika
- Khalid Baba
- Youssef Hafidi
- Tshegofatso Mabasa
- Christopher Ibayi
- Abdoul Kabir Ouédraogo

## FUS Rabat (35 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/fus-rabat/kader/verein/6371/saison_id/2026).

- Ayoub Lakred
- Mehdi Bellarabi
- Hamza Lizoul
- Faraji Karmoune
- Yassine Amhih
- Fernando Chamboco
- Achraf Zine
- Amine Farhane
- Abderrahman Arkid
- Oussama Soukhane
- Abdeslam Achhab
- Hamza Challali
- Walid El Hani
- Oussama Raoui
- Mustapha El Meskini
- Hamza Bouhaddi
- Anas Serrhat
- Amine El Msane
- Anas El Makkaoui
- Abdessamad Mahir
- Soufiane Tazi
- Hilal Ferdaoussi
- Hamza Moujahid
- Issam Naji
- Ismail Moutaraji
- Mohamed Bakhkhach
- Chouaib Faidi
- Anderson Cruz
- Amine Souane
- Montassir Lahtimi
- Yassine Belghroudi
- Déo Bassinga
- Ali El Harrak
- Mohamed Ferhane
- Moctar Diallo

## Hassania d'Agadir (33 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/hassania-union-sport-dagadir/kader/verein/22935/saison_id/2026).

- Gaya Merbah
- Ilyass Motik
- Hamza Antara
- Mouad Bahsain
- Ismail Hrila
- Soulaiman El Amrani
- Ayoub Qasmi
- Ayoub Sahnoune
- Ayoub Boucheta
- Younes El Amali
- Akram Haimoud
- Euclides Cabral
- Ayman Tarrazi
- Rodrigue Kossi Fiogbé
- Badreddine Octobre
- Jalal Tachtach
- Mehdi Akoumi
- Mohamed Doumbia
- Hamza Moumadi
- Hamza El Belghyty
- Abderrahmane Qassaq
- Abdelali Ait Brayim
- Ayoub Benaadi
- Ayoub Yousfi
- Youssef Arbidi
- Imad Riahi
- Amine Azri
- Salaheddine Benyachou
- Hamid Ahadad
- Mustapha Sahd
- Tumisang Orebonye
- Fahd Bendahmane
- Walid Jarmouni

## COD Meknès (31 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/cod-meknes/kader/verein/30625/saison_id/2026).

- Anas Zniti
- Aymane Majid
- Soufiane Taher
- Badr Gaddarine
- Driss El Jabali
- Karim El Bounagate
- Anass Nouader
- Ayoub Lakhlifi
- Saad El Morsli
- Chouaib Boutrid
- Oussama Daoui
- Ayoub Lourhraz
- Mohamed Zrida
- Larbi Naji
- Achraf Hmaidou
- Adnane Berdad
- Taoufik Razko
- Marius Mbou
- Hamza El Janati
- Karim L'Koucha
- Mohamed Aanane
- Hamza Elowasti
- Willy Onana
- Mohamed Zinaf
- Hassan Zraibi
- Abdellatif Benkassou
- Zakaria Bahrou
- Zouhir Eddib
- Joseph Guédé Gnadou
- Yassine Senhaji
- Cruz Ndong Bitheghe

## Ittihad Tanger (29 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/ittihad-tanger/kader/verein/12721/saison_id/2026).

- Badreddine Abyir
- Malcolm Barcola
- Ahmed Azmi
- Aymane Douieb
- Bilal El Ouadghiri
- Mohamed Saoud
- Saad Ait Khorsa
- Akram El Wahabi
- Saad Karouat
- Yassine Kermadi
- Achraf Laâziri
- Anass Lamrabat
- Zakaria Kiani
- Reda El Meliani
- Babacar Sarr
- Ennaama El Bellali
- Gape Edwin Mohutsiwa
- Mohamed El Arouch
- Hamza El Moudene
- Achraf El Quaraoui
- Akram Tali
- Mohamed El Guartit
- Soufyan Ahannach
- Abdelhamid Maali
- Younes Najari
- Ousama Siddiki
- Haytham Bakhlakh
- Senad Jarovic
- Ibrahima Dieng

## Difaâ El Jadida (32 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/difaa-el-jadida/kader/verein/14462/saison_id/2026).

- Babacar Niasse
- Ayoub Ait Wahmane
- Mohamed Bentarcha
- Anas Moulhami
- Israel Nwachukwu Usulor
- Aymen Riyane
- Aymane Takoua
- Boulkassoum Diarra
- Yassine Lhjale
- Hamza Malki
- Soufiane Abaaziz
- Zakaria Oubraim
- Oussama Benchchaoui
- Moctar El Hacen
- Youssef Michte
- Brahim El Idrissi Bouzidi
- Achraf Al Idrissi
- Anass Mostakim
- Megue
- Yassine El Ouatki
- Ayoub El Khafi
- Houdaifa Jamaäne
- Mouad Mouchtanim
- Mohamed Hilali
- Omar Hmamouch
- Ibra Lo
- Abdellah Farah
- Imad Sabik
- Reda Ech-Chgraoui
- Romuald Dacosta
- Abderrazak Ennakouss
- Papa Souley Diallo

## KACM Marrakech (32 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/kawkab-marrakech/kader/verein/4697/saison_id/2026).

- Amine El Ouaad
- Abdelali Mhamdi
- Mohamed Baayou
- Naoufal Ait Oubna
- Anass Rachak
- Mohssine Rabja
- Aboubacar Camara
- Hamza Smaali
- Mohamed Adam Benhita
- Akram El Hamdaoui
- Ismail El Alami
- Nabil Khali
- Mohamed Elabdi
- Mohammed Battah
- Hamza Fassoukh
- Abdelkarim Baadi
- Abdellah Bouallali
- Youssef Raiani
- Abdellah Haimoud
- Hamza Rafaa
- Oussama Mahrous
- Sabir Bougrine
- Khalil Tamrani
- Mahmoud El Kayssoumi
- Mohamed Dadssi
- Saleh Essallami
- Oussama Haffari
- Jawad Ghabra
- Ayoub Maamouri
- Youssef Zghoudi
- Hamza Founti
- Hamza Zagmouzi

## Union Touarga Sportif (30 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/union-de-touarga/kader/verein/79389/saison_id/2026).

- Houssam Bouelainine
- Reda Asmama
- Walid Hasbi
- Hamza Regragui
- Mehdi Ashabi
- Youssef Kajai
- Tahar Ahmed El Khalej
- Yassine El Khalej
- Khalid Kasbi
- Anas Nanah
- Oussama Jalfate
- Youness Akharraz
- Omar Arjoune
- Danny
- Konan Gatou Koffi
- Walid Rhailouf
- Adam Chakir
- Mohamed Es Sahel
- Redouan Ait Lamkadem
- Youssef Ait M'barek
- Mouad Dahak
- Abdelkabir El Ouadi
- Zoubir Housni
- Mohammed Fouzair
- Salim Ghazzani
- Saad Lotfi
- Nasreddine Moustaghfir
- Samuel Tebily
- Ayoub Ajerrar
- Abdeljalil Chaynane

## Renaissance Zemamra (31 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/renaissance-zemamra/kader/verein/74953/saison_id/2026).

- Mohamed Ferni
- Marouane Fakhr
- Hamza Jlid
- Abderrahmane Soufiane
- James Ajako
- Bilal Soufi
- Reda Ait Boughima
- Mohamed Abdouramane
- Amine El Maswab
- Ismail Soubai
- Ousmane Diallo
- Oussama El Attar
- Abdessamad Badaoui
- Zouheir El Hachemi
- Aiman El Aatga
- Abdellatif El Bajjani
- Anass El Ghannouj
- Oussama Dahr
- Hassane Adamou
- Mouad Mouzalim
- Zakaria Ajoughlal
- Mohsine Moutaouali
- Mouad Rahni
- Mohamed Kamal
- Youssef Dalouzi
- Youness Moukhlis
- Issam Jaafra
- Abdelaziz El Hamzaoui
- Jawad Essaghir
- Achraf Eddahbi
- Amine El Moutaouakil

## Moghreb Atlético Tétouan (33 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/moghreb-tetouan/kader/verein/9100/saison_id/2026).

- Gabaski
- Said Lamaiz
- Yassine Amaadour
- Zakaria Benabbou
- Soulayman Driouech
- Yassine Karraz
- Issam Bouabsidi
- Ghofrane Naouali
- Moncef Amri
- Mohamed Dades
- Yassine Aboursas
- Achraf Marzak
- Akram Eddaoudi
- Ayoub El Ouardighi
- Mouad Karmoun
- Mustapha El Crachna
- Hicham Zeghari
- Fayçal Fajr
- Rida Chahid
- Seydi Diouck
- Mohamed Kassou
- Mohamed Said Bouksyr
- Ahmed Lakhtibi
- Mohamed El Morabit
- Diae-Eddine Eddaoudi
- Aboubacar Konate
- Anwar Oussarhan
- Abdessamad Sendague
- Haytham El Bahja
- Youssef El Houari
- Nadir El Fadili
- Mounir Habach
- Seydou Diabate

## Amal Tiznit (28 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/amal-tiznit/kader/verein/85473/saison_id/2026).

- Mehdi El Jourbaoui
- Youssef Tafay
- Youssef Faqir
- Jad Assouab
- Koffi Holete
- Abderrahmane Bifinzi
- Mamadou Tounkara
- Omar Housni
- Ayoub El Malki
- Saad Benlahsen
- Tarik Asstati
- Hatim Bouhbouh
- Ayoub Adila
- Badr Raghay
- Popoola Sodiq
- Nourddine Komh
- Abdelghafour El Kouhil
- Badreddine Mouzdahir
- Mouad Goulouss
- Othman Fadiz
- Soufiane El Azhari
- Abdellatif Ait Ouaarab
- Youssef Anouar
- Hassan Boulaabar
- Younes Sakhi
- Abdelkader Ettalbi
- Yassine Zraa
- Zakaria Essalhi

## Widad Témara (28 jogadores listados)

Fonte: [elenco 2026/27 do Transfermarkt](https://www.transfermarkt.com/widad-temara/kader/verein/59814/saison_id/2026).

- Brahim El Yamlahi
- Rabie Ajlid
- Hatim Siouahe
- Reda Bakkouri
- Imad Babassa
- Nizar Cherki
- Ayoub Belcadi
- Mohamed Belkaida
- Zakaria Labib
- Said Lbeyd
- Souhail Amri
- Mouad Gari
- Lahcen Kabiri
- Omar El Khattab
- Rabiae Bounit
- Fahd El Kaaba
- Karim Ait Mohamed
- Abdellah Cherrad
- Othman Sabri
- Ismail Sbahe
- Ibrahima Balia Sagna
- Mohamed Assraoui
- Oussama Essabri
- Taoufik Ijrouten
- Akram Khouidssi
- Zakaria Oulbenna
- Oussama Essafi
- Mohamed Wail Babah

## Referências

[FRMF — Botola Pro D1](https://frmf.ma/fr/botola-pro/d1)  
[FRMF — Calendário da Botola Pro D1](https://frmf.ma/fr/botola-pro/d1/programme)  
[Transfermarkt — competição Botola Pro Inwi, temporada 26/27](https://www.transfermarkt.com/botola-pro-inwi/startseite/wettbewerb/MAR1)
