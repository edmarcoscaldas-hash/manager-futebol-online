# Elencos da K League 1 — temporada 2026/27

- **País:** Coreia do Sul
- **Campeonato:** K League 1
- **Divisão:** primeira divisão
- **Temporada/status (data de referência: 12 nov. 2026):** não há uma temporada K League 1 denominada **2026/27**. A competição opera por temporada de ano civil: a edição identificada oficialmente como 2026 está em andamento em novembro de 2026. A organização de 2027 é uma edição separada, prevista para começar no ano civil de 2027; portanto, seus elencos definitivos não podem ser tratados como elencos de “2026/27”. [1] [2]

## Cobertura e critério

Não existe uma lista de participantes ou um conjunto de elencos oficiais da K League 1 para uma temporada 2026/27 a listar. Por isso, não atribuo clubes, jogadores ou elencos da temporada 2026 a uma temporada 2026/27 e não reproduzo nomes de páginas de temporadas anteriores como se fossem atuais. Nesta data, a página oficial da liga registra partidas e classificação da K League 1 de 2026, com 12 equipes e 31 jogos disputados por clube na classificação exibida. A notícia de calendário/formatos de 2026 publicada pela K League United relata que a edição 2026 é a última com 12 clubes e que a K League 1 passará a 14 participantes em 2027; esse formato não constitui uma temporada 2026/27 nem confirma, por si só, os 14 participantes finais. [1] [2]

## Clubes e jogadores

**Nenhuma seção de clube com jogadores é apresentada para 2026/27**, porque a temporada sob essa designação não foi encontrada em fonte oficial e não há base pública verificável para certificar elencos dessa edição. A fonte oficial consultada para a classificação de 2026 mostra FC Seoul, Ulsan, Gangwon, Jeju, Jeonbuk, Daejeon Hana Citizen, Incheon, Anyang, Pohang, Gimcheon Sangmu, Bucheon e Gwangju como participantes da edição civil de 2026 — não como participantes confirmados de 2026/27. [1]

## Fontes

[1] Site oficial da K League — resultados, classificação e páginas de clubes (consultado em 12 nov. 2026): https://www.kleague.com/

[2] K League United — “What to look forward to in K League in 2026” (19 jan. 2026), com mudanças previstas para a edição civil de 2027: https://www.kleagueunited.com/2026/01/what-to-look-forward-to-in-k-league-in.html
