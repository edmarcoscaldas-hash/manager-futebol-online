# Egyptian Second Division — Egito, 2026/27

- **País:** Egito
- **Campeonato:** Egyptian Second Division A, também referida pela EFA como دوري أندية القسم الثاني أ / دوري المحترفين (Professional League)
- **Divisão:** 2ª divisão (Second Division A)
- **Status em 12 de novembro de 2026:** temporada em andamento. A EFA publicou em 9 de julho de 2026 o sorteio do torneio de 2026/27; tabela independente já registra partidas e classificação da temporada. [1] [2]

## Limite de cobertura de elencos

Não foi possível verificar publicamente uma relação atual, completa e atribuível à temporada 2026/27 de jogadores para cada participante. A publicação oficial localizada confirma o sorteio/temporada, mas não expõe no texto extraído os elencos. A tabela de temporada da FootyStats confirma a competição em andamento e os 20 participantes abaixo, mas não equivale a uma lista oficial de jogadores registrados. Por isso, não atribuo jogadores sem evidência de elenco específica da temporada; “nenhum jogador verificável” não significa elenco vazio. Não usei elencos de temporadas anteriores como substitutos.

## Clubes participantes e jogadores verificáveis

Os participantes são apresentados conforme a tabela 2026/27 da FootyStats, fonte secundária que identifica 20 equipes. A EFA é a fonte oficial localizada para o sorteio da competição 2026/27. Cada link de clube aponta à respectiva ficha estatística atual, não a uma roster page oficial.

### FC Masar
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha FC Masar na FootyStats](https://footystats.org/clubs/fc-masar-1393933). [2]

### Pharco FC
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Pharco FC na FootyStats](https://footystats.org/clubs/pharco-fc-678722). [2]

### Kahraba Ismailia
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Kahraba Ismailia na FootyStats](https://footystats.org/clubs/kahraba-ismailia-931355). [2]

### Maleyet Kafr El Zayiat
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Maleyet Kafr El Zayiat na FootyStats](https://footystats.org/clubs/maleyet-kafr-el-zayiat-688354). [2]

### Haras El Hodood
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Haras El Hodood na FootyStats](https://footystats.org/clubs/haras-el-hodood-1133). [2]

### Al Nasr
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Al Nasr na FootyStats](https://footystats.org/clubs/al-nasr-1140). [2]

### El Mansura
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha El Mansura na FootyStats](https://footystats.org/clubs/el-mansura-17831). [2]

### Telecom Egypt SC
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Telecom Egypt SC na FootyStats](https://footystats.org/clubs/telecom-egypt-sc-17828). [2]

### Tersana
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Tersana na FootyStats](https://footystats.org/clubs/tersana-17827). [2]

### El Seka El Hadid
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha El Seka El Hadid na FootyStats](https://footystats.org/clubs/el-seka-el-hadid-689344). [2]

### Baladiyyat Al Mehalla
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Baladiyyat Al Mehalla na FootyStats](https://footystats.org/clubs/baladiyyat-al-mehalla-17829). [2]

### El Entag El Harby
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha El Entag El Harby na FootyStats](https://footystats.org/clubs/el-entag-el-harby-1118). [2]

### Ismaily SC
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Ismaily SC na FootyStats](https://footystats.org/clubs/ismaily-sc-1124). [2]

### Team FC
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Team FC na FootyStats](https://footystats.org/clubs/team-fc-1393934). [2]

### El Daklyeh FC
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha El Daklyeh FC na FootyStats](https://footystats.org/clubs/el-daklyeh-fc-1117). [2]

### Proxy SC
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Proxy SC na FootyStats](https://footystats.org/clubs/proxy-sc-931352). [2]

### Tanta SC
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Tanta SC na FootyStats](https://footystats.org/clubs/tanta-sc-1123). [2]

### La Viena FC
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha La Viena FC na FootyStats](https://footystats.org/clubs/la-viena-fc-697973). [2]

### Delta United
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Delta United na FootyStats](https://footystats.org/clubs/delta-united-1860253). [2]

### Dayrout SC
Jogadores nomeados verificáveis em fonte pública de elenco 2026/27 consultada: **nenhum localizado**. Fonte do clube: [ficha Dayrout SC na FootyStats](https://footystats.org/clubs/dayrout-sc-688357). [2]

## Referências

[1]: https://www.facebook.com/EFA/posts/%D9%82%D8%B1%D8%B9%D8%A9-%D8%AF%D9%88%D8%B1%D9%8A-%D8%A3%D9%86%D8%AF%D9%8A%D8%A9-%D8%A7%D9%84%D9%82%D8%B3%D9%85-%D8%A7%D9%84%D8%AB%D8%A7%D9%86%D9%8A-%D8%A3-%D8%AF%D9%88%D8%B1%D9%8A-%D8%A7%D9%84%D9%85%D8%AD%D8%AA%D8%B1%D9%81%D9%8A%D9%86-%D9%84%D9%85%D9%88%D8%B3%D9%85-2026-2027-/1054763486905944/ "Egyptian Football Association: sorteio da Second Division A 2026/27"
[2]: https://footystats.org/egypt/second-division "FootyStats: tabela Egyptian Second Division 2026/27"
[3]: https://www.national-football-teams.com/leagues/57/2026_1/Egypt.html "National Football Teams: ligas egípcias em 2026/27"
