# Liga MX 2026/27 — clubes e elencos publicamente verificáveis

- **País:** México
- **Campeonato:** Liga MX / Liga BBVA MX (masculina)
- **Divisão:** Primeira divisão
- **Temporada/status em 12 de novembro de 2026:** temporada 2026/27 em andamento. O calendário oficial do Apertura 2026 cobre jornadas até 20–22 de novembro e playoffs em novembro/dezembro; a página oficial de calendário registrava jogos da jornada 16 de 6–8 de novembro. Portanto, a temporada não estava por começar. [1] [2]

## Cobertura e critério

A relação de participantes abaixo corresponde à temporada 26/27 (não foi copiada de 25/26): a página da competição no Transfermarkt identifica expressamente “Liga MX Apertura 26/27”, 18 clubes e liga a cada plantel com `saison_id/2026`. Ela é uma fonte secundária, não substitui confirmação oficial da inscrição. [3]

Não foi possível confirmar, nesta pesquisa, páginas oficiais de elenco atualizadas para todos os clubes nem recuperar de modo uniforme e auditável os nomes dos jogadores dos 18 plantéis. Por isso, não apresento listas parciais como se fossem completas e não reutilizo nomes de temporadas anteriores. Os links de elenco abaixo são referências por clube para a temporada 2026 (26/27) na fonte secundária; cada clube requer conferência do roster atual, inclusive de suas transferências e inscrições. **Cobertura de clubes: 18/18; cobertura de nomes de jogadores: incompleta, nenhum elenco integral certificado neste documento.** Comissão técnica não é tratada como jogador.

## Clubes participantes e elencos

### CF América
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [4]

### CD Cruz Azul
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [5]

### CD Guadalajara
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [6]

### Deportivo Toluca FC
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [7]

### Tigres UANL
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [8]

### CF Monterrey
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [9]

### Club Tijuana
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [10]

### Pumas UNAM
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [11]

### Atlas Guadalajara
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [12]

### Club León FC
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [13]

### Santos Laguna
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [14]

### FC Juárez
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [15]

### Club Necaxa
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [16]

### Atlético de San Luis
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [17]

### CF Pachuca
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [18]

### Querétaro FC
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [19]

### Club Puebla
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [20]

### CF Atlante
Plantel nominal: não reproduzido por falta de extração completa verificável nesta pesquisa. [21]

## Referências

[1]: https://d1ezr1jf3kzw59.cloudfront.net/docs/publicaciones/ligamx/2026-2027/1/calendario-liga-mx-torneo-apertura-2026.pdf "Calendário oficial Liga MX Apertura 2026"
[2]: https://www.ligamx.net/cancha/calendarios "Calendário oficial da Liga MX"
[3]: https://www.transfermarkt.es/liga-mx-apertura/startseite/wettbewerb/MEXA "Liga MX Apertura 26/27 e clubes"
[4]: https://www.transfermarkt.es/cf-america/kader/verein/3631/saison_id/2026 "Elenco CF América 2026/27"
[5]: https://www.transfermarkt.es/cd-cruz-azul/kader/verein/3711/saison_id/2026 "Elenco Cruz Azul 2026/27"
[6]: https://www.transfermarkt.es/cd-guadalajara/kader/verein/6711/saison_id/2026 "Elenco Guadalajara 2026/27"
[7]: https://www.transfermarkt.es/deportivo-toluca-fc/kader/verein/1804/saison_id/2026 "Elenco Toluca 2026/27"
[8]: https://www.transfermarkt.es/tigres-uanl/kader/verein/7055/saison_id/2026 "Elenco Tigres 2026/27"
[9]: https://www.transfermarkt.es/cf-monterrey/kader/verein/2407/saison_id/2026 "Elenco Monterrey 2026/27"
[10]: https://www.transfermarkt.es/club-tijuana/kader/verein/13353/saison_id/2026 "Elenco Tijuana 2026/27"
[11]: https://www.transfermarkt.es/unam-pumas/kader/verein/7633/saison_id/2026 "Elenco Pumas 2026/27"
[12]: https://www.transfermarkt.es/atlas-guadalajara/kader/verein/8590/saison_id/2026 "Elenco Atlas 2026/27"
[13]: https://www.transfermarkt.es/club-leon-fc/kader/verein/4941/saison_id/2026 "Elenco León 2026/27"
[14]: https://www.transfermarkt.es/santos-laguna/kader/verein/1403/saison_id/2026 "Elenco Santos Laguna 2026/27"
[15]: https://www.transfermarkt.es/fc-juarez/kader/verein/49283/saison_id/2026 "Elenco FC Juárez 2026/27"
[16]: https://www.transfermarkt.es/club-necaxa/kader/verein/1146/saison_id/2026 "Elenco Necaxa 2026/27"
[17]: https://www.transfermarkt.es/atletico-de-san-luis/kader/verein/40188/saison_id/2026 "Elenco Atlético de San Luis 2026/27"
[18]: https://www.transfermarkt.es/cf-pachuca/kader/verein/4035/saison_id/2026 "Elenco Pachuca 2026/27"
[19]: https://www.transfermarkt.es/queretaro-fc/kader/verein/4961/saison_id/2026 "Elenco Querétaro 2026/27"
[20]: https://www.transfermarkt.es/club-puebla/kader/verein/5662/saison_id/2026 "Elenco Puebla 2026/27"
[21]: https://www.transfermarkt.es/cf-atlante/kader/verein/6709/saison_id/2026 "Elenco Atlante 2026/27"
