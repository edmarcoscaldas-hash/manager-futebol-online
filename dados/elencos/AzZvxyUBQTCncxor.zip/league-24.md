# Eerste Divisie 2026/27 — clubes e jogadores verificáveis

- **País:** Países Baixos
- **Campeonato:** Keuken Kampioen Divisie (Eerste Divisie)
- **Divisão:** segunda divisão masculina neerlandesa
- **Temporada/status (12 nov. 2026):** temporada 2026/27 em andamento. A página da liga informa início em 7 de agosto de 2026; o calendário oficial apresenta jogos da temporada e notícias de novembro. [1] [2]

## Cobertura e limite

A liga e a imprensa especializada confirmam 20 participantes, listados abaixo. Não encontrei em todos os 20 clubes uma publicação oficial de elenco com escopo e data que permitisse certificar uma lista completa e homogênea de jogadores em 12/11/2026. Para evitar atribuir a 2026/27 nomes de temporadas anteriores ou chamar uma lista de goleadores de elenco completo, as páginas dos clubes mostram apenas jogadores identificados explicitamente em estatísticas da temporada 2026/27 quando essas estatísticas estavam disponíveis na página consultada. Uma lista de goleadores/estatísticas é evidência de participação, não roster completo. Os clubes sem nomes abaixo não tiveram nomes de jogadores individualmente confirmados nas fontes abertas nesta checagem; isso não significa ausência de jogadores ou de elenco publicado em outros canais.

## Clubes e nomes individualmente identificados

### Almere City FC

**Jogadores identificados nas estatísticas de 2026/27:** Ferdy Druijf, Emanuel Poku, Olivier de Nijs, Enzo Cornelisse, Marley Dors, Byron Burgering, Hamza el Dahri, Jamie Jacobs, Joey Jacobs, Martin Wasinski, Milan de Haan, Immanuel Ghogli, Mees Hoedemakers, Bas Pennock, Emmanuel van de Blaak e James Lawrence. **Cobertura parcial, não elenco completo.** [3]

### De Graafschap

**Jogadores identificados nas estatísticas de 2026/27:** Julian Kania, Bjorn van Zijl, Donny Warmerdam, Fedde de Jong, Kyano Kwint, Nolan Martens, Toivo Mero, Gabriele Finocchiaro, Mark Diemers, Nart Ahmeti, Rowan Besselink, Thomas Kok, Gijs Bolk, Jannes Wieckhoff, Joran Hardeman, Kaya Symons e Ties Wieggers. **Cobertura parcial, não elenco completo.** [4]

### FC Den Bosch

**Jogadores identificados nas estatísticas de 2026/27:** Sebastian Karlsson Grach, Devon De Corte, Ilias Boumassaoudi, Kevin Monzialo, Sheddy Barglan, Hessel Eikelboom, Lorenzo Hoffman, Silvan Broker, Mees Laros, Emian-Johar Semedo, Jeffry Fortes, Bohao Wang e Pepijn van de Merbel. **Cobertura parcial, não elenco completo.** [5]

### FC Dordrecht

**Jogadores identificados nas estatísticas de 2026/27:** Ayoub Ouarghi, Martin Vetkal, Lorenzo Riccio, Nicolas Rossi, Beni Mpanzu, Dario Sits, Joey de Bie, Robin van Asten, Rochanio Lenz, Senne Vugts, Stan Henderikx, Lucas Roman, Yannis M'Bemba, Jurre van Aken, Nick Venema, Adil Lechkar, Jaden Pinas, Ninho Felicia e Bjorn Hardley. **Cobertura parcial, não elenco completo.** [6]

### FC Eindhoven

**Jogadores identificados nas estatísticas de 2026/27:** Rayan Buifrahi, Kevin van Veen, Owen Renfrum, Siegert Baartmans, Antonio Bazdaric, Guus Beaumont, Hyman Ali, Mika de Jonge, Niek Munsters, Raf van de Riet, Vicente Besuijen, Clint Essers, Amir Bryson, Junior Poortvliet, Luc Netten, Rens Boon e Xander Blomme. **Cobertura parcial, não elenco completo.** [7]

### FC Emmen

Não foi possível confirmar uma relação de jogadores nomeados na página consultada; a página mostra partidas/resultados de 2026/27, mas não roster nem seção de estatísticas de jogadores em conteúdo extraível. [8]

### FC Volendam

**Jogadores identificados nas estatísticas de 2026/27:** Henk Veerman, Reuven Niemeijer, Frederik Ihler, Alex Plat, Younes el Meftahi, Daan Huisman, Luca Blondeau, Nick Doodeman, Nordin Bukala, Kayden Wolff, Mike Kleijn, Mohammed Belfqih, Precious Ugwu, Mawouna Amevor, Daan Bisschops, Jair Haakmat e Serigne Deme. **Cobertura parcial, não elenco completo.** [9]

### Helmond Sport

**Jogadores identificados nas estatísticas de 2026/27:** Mauro Lenaerts, Tarik Essakkati, Dean Huiberts, Livio Cicero, Michel Ludwig, Sem Dekkers, Brian Koglin, Joep van der Sluijs, Kiton Ekoli, Labinot Bajrami, Helgi Ingason, Xander van der Velde, Pol Llonch, Wassim Lantaki, Lovro Golic e Thomas Poll. **Cobertura parcial, não elenco completo.** [10]

### Heracles Almelo

**Jogadores identificados nas estatísticas de 2026/27:** Jean-Paul N'djoli, Tristan van Gilst, Sem Scheperman, Manny, Chafik Abbas, Damon Mirani, Maurice Wrusch, David Vicente, Djevencio van der Kust, Mario Borac, Thomas Bruns, Max Hauswirth, David Tomic, Mimeirhel Benita, Jeff Reine-Adelaide, Fabian de Keijzer, Mike te Wierik e Stijn Bultman. **Cobertura parcial, não elenco completo.** [11]

### Jong Ajax

**Jogadores identificados nas estatísticas de 2026/27:** Emre Unuvar, Diego Pugno, Pharell Nash, Jano Monserrate, Abdoulaye Camara, Leo Salazar, Levi Acheampong, Dies Janse, Jahyendrow Amour, Mohamed Abdalla, Ryan van de Pavert, Marvin Muzungu, Mark Verkuijl, Fouad Zahouani, Avery Appiah, Geronimo Spina, Jeshurun Simeon, Jinairo Johnson e Joeri Heerkens. **Cobertura parcial, não elenco completo.** [12]

### Jong AZ

**Jogadores identificados nas estatísticas de 2026/27:** Ayoub Oufkir, Bendeguz Kovacs, Julian Oerip, Rio Robbemond, Tycho de Wit, Yoel van den Ban, Andrea Natali, Hessel de Wit, Jerroldino Bergraaf, Jesper Zwart, Mathijs Menu e Jeremiah Esajas. **Cobertura parcial, não elenco completo.** [13]

### Jong PSV

**Jogadores identificados nas estatísticas de 2026/27:** Austyn Jones, Fabio Kluit, Samuel Dumbili, Shuryjano Cornecion, Boet Mulders, Kyano Penso, Souleymane Sidibe, Jim Koller, Michael Bresser, Philip Holseter-Karlsen, Rivas Manuhutu, Bouhamdi Amir, Jairo Beerens, Madi Monamay, Manuel Bahaty e Mikkel Bro Hansen. **Cobertura parcial, não elenco completo; estatísticas incluem participação na Eerste Divisie.** [14]

### Jong FC Utrecht

**Jogadores identificados nas estatísticas de 2026/27:** Emmanuel Chigozie Owen, Massien Ghaddari, Bjorn Menzo, Jaygo van Ommeren, Noa Dundas, Wessel Kooy, Jamie Schuldes, Jerayno Hunte, Yousri Sbai, Driss Laaouina, Tijn den Boggende, Oualid Agougil, Viggo Plantinga, Kenji Goes e Nana Gyamfi-Amoah. **Cobertura parcial, não elenco completo.** [15]

### MVV Maastricht

**Jogadores identificados nas estatísticas de 2026/27:** Elias Sierra, Jael Pawirodihardjo, Olivier Dumont, Stan Van Dessel, Delano Asante, Finn Dicke, Lennerd Daneels, Milan Hofland e Sil van der Wegen. **Cobertura parcial, não elenco completo.** [16]

### NAC Breda

**Jogadores identificados nas estatísticas de 2026/27:** Charles-Andreas Brym, Moussa Soumano, Paul Gladon, Mohamed Nassoh, Pepijn Reulen, Imran Nazih, Kamal Sowah, Mohamed Bouchouari, Boyd Lucassen, Gabriel Misehouy, Jannes Van Hecke, Mats Seuntjens, Jan Van den Bergh, Fredrik Oldrup Jensen, Leo Greiml, Rio Hillen, Brahim Ghalidi, Maximilien Balard e Michael Verrips. **Cobertura parcial, não elenco completo.** [17]

### TOP Oss

**Jogadores identificados nas estatísticas de 2026/27:** Mauresmo Hinoke, Franslyn Nsingi, Maurilio de Lannoy, Andy Visser, Kyanno Silva, Marcelencio Esajas, Maxim Mariani, Milo Horemans, Richard van der Venne, Justin Mathieu, Ilounga Pata, Julian Kuijpers, Sirine Doucoure, Jacey Pansa, Mert Erkan, Delano Vianello, Jafar Bynoe, Lars Mol, Mike Havekotte e Alvaro Henry. **Cobertura parcial, não elenco completo.** [18]

### Roda JC Kerkrade

A página consultada confirma jogos da Eerste Divisie 2026/27, mas não expõe uma lista de elenco nem estatísticas individualizadas de jogadores no conteúdo extraído. Não acrescento nomes sem confirmação explícita. [19]

### VVV-Venlo

A página consultada confirma partidas e estatísticas coletivas de 2026/27, mas não expõe roster ou estatísticas individualizadas de jogadores no conteúdo extraído. Não acrescento nomes sem confirmação explícita. [20]

### Vitesse

**Jogadores identificados nas estatísticas de 2026/27:** Naoufal Bannis, Ayman Sellouf, Filipe de Carvalho, Jeredy Hilterman, Nino Zonneveld, Connor van den Berg, Marco Schikora, Nathan Markelo, Omar Achouitar, Chiel Olde Keizer, Marcus Steffen, Pontus Dahbo, Ricardo-Felipe Schwarz, Solomon Bonnah, Alexander Buttner, Mathijs Marschalk, Valon Zumberi e Youssef Ouallil. **Cobertura parcial, não elenco completo.** [21]

### RKC Waalwijk

A página consultada confirma partidas e estatísticas coletivas de 2026/27, mas não expõe roster ou estatísticas individualizadas de jogadores no conteúdo extraído. Não acrescento nomes sem confirmação explícita. [22]

## Referências

[1]: https://www.vi.nl/competities/eerste-divisie/over "VI — Keuken Kampioen Divisie 2026/27"
[2]: https://keukenkampioendivisie.nl/definitief-competitieprogramma-2026-27-vastgesteld "Keuken Kampioen Divisie — calendário definitivo 2026/27"
[3]: https://www.footboom1.com/en/football/team/almere-city "Footboom — Almere City"
[4]: https://www.footboom1.com/en/football/team/de-graafschap "Footboom — De Graafschap"
[5]: https://www.footboom1.com/en/football/team/den-bosch "Footboom — Den Bosch"
[6]: https://www.footboom1.com/en/football/team/dordrecht "Footboom — Dordrecht"
[7]: https://www.footboom1.com/en/football/team/eindhoven-fc "Footboom — FC Eindhoven"
[8]: https://www.footboom1.com/en/football/team/fc-emmen "Footboom — FC Emmen"
[9]: https://www.footboom1.com/en/football/team/fc-volendam "Footboom — FC Volendam"
[10]: https://www.footboom1.com/en/football/team/helmond "Footboom — Helmond Sport"
[11]: https://www.footboom1.com/en/football/team/heracles "Footboom — Heracles Almelo"
[12]: https://www.footboom1.com/en/football/team/jong-ajax "Footboom — Jong Ajax"
[13]: https://www.footboom1.com/en/football/team/jong-az "Footboom — Jong AZ"
[14]: https://www.footboom1.com/en/football/team/jong-psv "Footboom — Jong PSV"
[15]: https://www.footboom1.com/en/football/team/jong-utrecht "Footboom — Jong FC Utrecht"
[16]: https://www.footboom1.com/en/football/team/maastricht "Footboom — MVV Maastricht"
[17]: https://www.footboom1.com/en/football/team/nac-breda "Footboom — NAC Breda"
[18]: https://www.footboom1.com/en/football/team/oss "Footboom — TOP Oss"
[19]: https://www.footboom1.com/en/football/team/roda "Footboom — Roda JC Kerkrade"
[20]: https://www.footboom1.com/en/football/team/venlo "Footboom — VVV-Venlo"
[21]: https://www.footboom1.com/en/football/team/vitesse "Footboom — Vitesse"
[22]: https://www.footboom1.com/en/football/team/waalwijk "Footboom — RKC Waalwijk"
