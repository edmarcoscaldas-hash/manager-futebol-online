# A-League Men 2026/27 — clubes e jogadores

**País:** Austrália (competição trans-Tasman; Wellington Phoenix e Auckland FC são clubes neozelandeses).
**Campeonato:** Isuzu UTE A-League Men.
**Divisão:** primeira divisão masculina profissional.
**Temporada/status em 12 de novembro de 2026:** em andamento. A temporada começou em 16 de outubro de 2026.

## Cobertura e critério

A fonte principal é o [Guia oficial A-League Men 2026/27](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf), publicação da Australian Professional Leagues. O documento informa que contém 12 clubes e que elencos, estatísticas e calendário estão atualizados a 15 de outubro de 2026; as listas de plantéis estão datadas de 16 de outubro. Portanto, estas são listas nominais verificáveis no início da temporada, não um registro de transferências até 12 de novembro. Incluo a lista principal e o elenco jovem nos casos em que aparecem no guia. Não incluo comissão técnica.

O calendário oficial confirma o início em 16 de outubro: [comunicado de calendário 2026/27](https://aleagues.com.au/news/aleague-men-2026-2027-fixture-list-revealed-key-dates-fixture-information/). Todos os 12 clubes têm lista no guia oficial. As fontes por clube abaixo apontam para o documento oficial, que contém a página do respectivo elenco; a lista geral da liga pode ser consultada em [A-Leagues Clubs](https://aleagues.com.au/a-league-clubs/).

## Adelaide United

**Jogadores nomeados no guia (lista principal e jovens):** Bart Vriends, Panagiotis Kikianis, Ryan Kitto, Juan Muniz, Craig Goodwin, Jonny Yull, Max Vartuli, Jay Barnett, Israel Monga, Ben Folami, Jake Najdovski, Dylan Pierias, Jacob Brazete, Joshua Smits, Luke Duzel, Mitchell Smith, Brody Burkitt, Ethan Cox, Ryan White, Sotiri Phillis, Ethan Alagich, Harry Crawford, Fabian Talladira, Joey Garuccio, Vinko Stanisic, Amlani Tatu, Malual Nichola, Feyzo Kasumovic, Anselmo, Denver Minster, Ajak Riak, Aston Burns, Luka Blazevic, Laris Cesko, Mitchell Knight, Daniel Wojcik.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Adelaide United](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Auckland FC

**Jogadores nomeados no guia (lista principal e jovens):** Michael Woud, Hiroki Sakai, Nando Pijnaker, Cameron Howieson, Felipe Gallegos, Sam Cosgrove, Lachlan Bayliss, Francis De Vries, Daniel Normann, Callan Elliot, Marley Leuluai, Oliver Middleton, Isa Prins, Jake Brimmer, Ronan Wynne, Aaron Cartwright, Logan Rogerson, Aaron Calver, Joe Knowles, Jonty Bidois, Luka Vicelich, Van Fitzharris, Lachlan Brook, Carlos Ranui, Aston Burns, Matthew D'Hotman, James Mitchell, Dejaun Naidoo, Damion Kim, Harley Hill, Eli Jones, William Gross, Sean Kane, Michael Wong, Nathan Martin, Liam Hill, Benjamin Perez Baldoni, Charlie Hale.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Auckland FC](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Brisbane Roar

**Jogadores nomeados no guia (lista principal e jovens):** Dean Bouzanis, Jacob Nasso, Dimitri Valkanis, Thomas Aldred, Noah Maieroni, Tyrese Francois, Virgiliu Postolachi, Tae-Hee Nam, Marko Ilic, Tate Russell, Emin Durakovic, Hosine Bility, Joel King, Justin Vidic, Sabit Ngor, Max Court, Nathan Amanatidis, Oscar Page, George Plusnin, Emmett Shaw, Jordan Lauton, Archie Mitchell, Milorad Stajic, Charlie Parkin, Jackson O'Reilly, Taj Sorensen, Niall Thom, Clayton Jones, Nyang (Nelson) Deng.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Brisbane Roar](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Central Coast Mariners

**Jogadores nomeados no guia (lista principal e jovens):** Diesel Herrington, Trent Sainsbury, Lucas Mauragis, Haine Eames, Chris Donnell, Oliver Lavale, John-Kymani Gordon, Noah McCann, Storm Roux, Harrison Steele, Presley Ortiz, Rufai Abubakar, Daniel Scarlett, Arthur De Lima, Taiyo Hisamatsu, Kristian Popovic, Andrew Redmayne, Bailey Brandtman, Alex Bolton, Dylan Peraic-Cullen, Shumba Mutokoyi, Max Naylor, Oliver O`Carroll, Jesse Mantell, Callum McCaskey, Stevan Rujak, Noah Hooper, Gabriel Tilo, Jai Ajanovic, Ali Auglah, Ty Mckibbin, Isaac Kwon, Ethan Law.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Central Coast Mariners](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Macarthur FC

**Jogadores nomeados no guia (lista principal e jovens):** Alex Robinson, Tatsuki Nara, Jonathan Aspropotamitis, Kai Kennedy, Connor Pain, Luke Vickery, Ben Gibson, Ryan Fraser, Bernardo, James Hilton, Michael Pratezina, Apostolos Stamatelopoulos, Oliver Randazzo, Dylan Rose, Harry Politidis, Henrique Oliveira, Nathan Paull, Liam Rose, Kosta Grozos, Dean Bosnjak, Callum Talbot, Jing Reec, Zane Helweh, Sebastian Krslovic, Will McKay, Harry Menham, Musa Toure, Joshua Lakkis, Sonny Sterjovski, Michael Paragalli, Justin Cardozo Machado, Harper Ryles, Prayaag Thapa, Liam McMaster, Jack Wheat.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Macarthur FC](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Melbourne City

**Jogadores nomeados no guia (lista principal e jovens):** Macklin Freke, Harrison Delbridge, Liam Bonetig, Matheus Rossetto, Mathew Leckie, Max Caputo, Emiliano Marcondes, Awer Mabil, Nathaniel Atkinson, Besian Kutleshi, Andrew Nabbout, Aziz Behich, Julio Cascante, Quinn Macnicol, Ben Mazzeo, Alessandro Lopane, Peter Antoniou, Medin Memeti, Kavian Rahmani, Ryan Kalms, Jayden Necovski, Matthew Baker, Akeem Gerald, Beckham Baker, James Nieuwenhuizen, Lawrence Wong, Takeshi Kanamori, Roland Ballah, Angus Mackintosh, Isiah Boston, Luka Demuth, Tobias Servin, Dominic Aravanis, Jake Pilovski, Jonty Benfield, Sam Robson.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Melbourne City](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Melbourne Victory

**Jogadores nomeados no guia (lista principal e jovens):** Jack Warshawsky, Jason Davidson, Philipp Ziereis, Brendan Hamill, Louis D`Arrigo, Jordi Valadon, Harrison Sawyer, Denis Genreau, Clarismario, Matthew Grimaldi, Tom Lockyer, Josh Inserra, Franco Lino, Oliver Dragicevic, Guillermo May, Xavier Stella, Keegan Jelacic, Malik Olukhale, Jack Duncan, Jack Mihailidis, William Kengni, Daniel Graskoski, Harrison Shillington, Michael Ghossaini, Charles Nduka, Winston Ashburner, Oliver Dimovski, Alex Lee, Theodore Limberis, Lewis Marinucci, Daniel Matina, Noah Tanfara, Ethan Troselj, Oskar Von Schrenk.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Melbourne Victory](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Newcastle Jets

**Jogadores nomeados no guia (lista principal e jovens):** James Delianov, Alex Grant, Joe Shaughnessy, Zane Schreiber, Patrick Wood, Nikos Vergos, Zach Clough, Joe Lolley, Max Burgess, Will Kennedy, Ethan Debono, Alex Badolato, Alex Nassiep, Joel Bertolissio, Daniel Wilmering, Alex Nunes, Oscar Fryer, Oscar Gonzalez, Julian Recchia, Will Dobson, Jake Goodwin, Angus Reid, Oliver Cockle, Thomas Aquilina, Jordan Baylis, Max Cooper, Xavier Bertoncello, Nicholas Badolato, Bryn Wells, Archie Brideson, Callan Prestwidge, Jesse Hill, Kaiden Walshe.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Newcastle Jets](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Perth Glory

**Jogadores nomeados no guia (lista principal e jovens):** Charbel Shamoon, Sam Sutton, Scott Wootton, Lachlan Jackson, Riley Foxe, Brandon O`Neill, Stefan Colakovski, Jaiden Kucharski, Tom Lawrence, Sebastian Kukucka, Matt Dench, Henry Hore, Lucas Scicluna, Pieter Jacobsz, Cher Deng, Trent Ostler, Matt Ellis, Anthony Didulica, Andriano Lebib, Sebastian Despotovski, William Freney, Calem Nieuwenhof, Matthew Sutton, Daniel Solsky, Tadi Kuzamba, Oliver Evans, Giovanni De Abreu, Ryan Warner, Brian Kaltak, _Youth Aaron Black.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Perth Glory](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Sydney FC

**Jogadores nomeados no guia (lista principal e jovens):** Gus Hoefsloot, James Overy, Jordan Courtney-Perkins, Jacob Farrell, Akol Akon, Wataru Kamijo, Oriola Sunday, Victor Campuzano, Abel Walatee, Harrison Devenish-Meares, Takahiro Sekine, Jake Hollman, Gabriel Popovic, Ben Garuccio, Zachary Harrison, Tiago Quintal, Mathias Macallister, Rhyan Grant, Nickolas Alfaro, Ethan Dyer, Joseph Lacey, Alex Zaverdinos, Marcel Tisserand, Marin France, Tyler Williams, Al Hassan Toure, Rhys Youlley, Alex Popovic, Aaron Black, Zinadein Ardiansyah, Joshua Brazete, Ryan Buttigieg, Ethan Fletcher, Zac Fowler, Harrison Jablonski, Samuel Lancaster, Jack Middleby, Miles Milliner, Dionn Nigro, Josef Sikora, Laurence Taylor, Jared Williams, Nicholas Zdrilic.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Sydney FC](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Wellington Phoenix

**Jogadores nomeados no guia (lista principal e jovens):** Corban Piper, Walter Scott, Fin Roa Conchie, Bryce Duke, Max Anderson, Rafael Duran, Riley Bidois, Henry Gray, Alex Rufer, Isaac Hughes, Nathan Walker, Lukas Kelly-Heald, James McGarry, Xuan Loke, Kazuki Nagasawa, Matthew Sheridan, Bill Tuiloma, Alby Kelly-Heald, Ben Trenberth, Anaru Cassidy, Jayden Smith, Eamonn McCarron, Ryan Lee, Daniel Nelson, Dylan Gardiner, Luke Mitchell, Fletcher Pratt, Joseph McIntyre, Mac Munro, Kyle Koch, Zac Cashmore, Jack Clegg, Cruz Pietersen, Joseph Chalabi.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Wellington Phoenix](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Western Sydney Wanderers

**Jogadores nomeados no guia (lista principal e jovens):** Alex Gersbach, Steven Ugarkovic, Aydan Hammond, Dylan Scicluna, Hiroshi Ibusuki, Miguel Di Pizio, Atiya Waraga, Nicolas Milanovic, Oscar Morrison, Jarrod Carluccio, Lawrence Thomas, Liam Gillion, Anthony Pantazopoulos, Jordan Holmes, Nathan Barrie, Emile Katrib, Brandon Borrello, Joshua Cetinic, Georgio Hassarati, Angus Thurgate, German Ferreyra, Ricky Fransen, Marcus Savic, Panashe Madanha, Alaat Abdul-Rahman, Jai Rose, Awan Lual, Tristan Vidackovic, Lachlan Allen, Oscar Archbold, Kade Baccus, Pearson Kasawaya, Johnny Pavlovic, Tristan Arrarte, Noah Ovens, Anderson Back, Corey Da Cruz.

Fonte: [Guia oficial A-League Men 2026/27 — elenco de Western Sydney Wanderers](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf).

## Referências

- [Guia oficial A-League Men 2026/27 — Australian Professional Leagues](https://aleagues.com.au/wp-content/uploads/sites/17/2026/10/A-League_Men_2026-27_Season_Guide.pdf)
- [Calendário oficial 2026/27 — A-Leagues](https://aleagues.com.au/news/aleague-men-2026-2027-fixture-list-revealed-key-dates-fixture-information/)
- [Clubes oficiais — A-Leagues](https://aleagues.com.au/a-league-clubs/)
