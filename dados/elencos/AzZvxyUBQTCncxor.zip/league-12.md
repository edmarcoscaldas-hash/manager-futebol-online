# Brasileirão Série C: temporada 2026/27

- **País:** Brasil.
- **Campeonato:** Campeonato Brasileiro Série C (Brasileirão Série C).
- **Divisão:** terceira divisão nacional.
- **Temporada/status em 12 nov. 2026:** não existe temporada oficial contínua identificada como “2026/27” nas fontes consultadas; a competição é publicada por edição anual. A Série C 2026 teve tabela básica oficial com 20 clubes e datas de abril a outubro de 2026 [1] [2]. A próxima edição é a Série C 2027, prevista com 24 clubes. Em 11 nov. 2026, eram conhecidos 23 participantes; a vaga restante seria ocupada pela última equipe rebaixada da Série B [3]. Assim, em 12 nov., a edição de 2027 ainda não tinha lista completa de clubes, e não há aqui elencos de 2027 oficialmente confirmados.
- **Critério de elenco:** só listar jogadores em elenco publicamente verificável correspondente à edição solicitada. A pesquisa não encontrou fonte oficial ou roster confiável que confirmasse elenco da Série C 2027 para os clubes abaixo. Não se reaproveitam escalações de 2026 nem nomes de comissão técnica. “Nenhum nome verificável” não significa que o clube não tenha jogadores contratados; significa que a fonte disponível não permite atribuí-los com segurança ao elenco da próxima edição.

## Participantes de 2027 confirmados em fonte publicada em 11 nov. 2026

A relação abaixo reproduz os 23 clubes apontados como confirmados pelo Jornal da Paraíba, publicada após o encerramento dos quadrangulares decisivos da Série C 2026 [3]. A CBF é a fonte primária da competição, mas a página consultada apresenta a Série C 2026 e não disponibiliza uma página de elenco para 2027 [1]. Para cada clube, **jogadores nomeados: nenhum nome de elenco 2027 publicamente verificável nas fontes consultadas**.

### ABC (RN)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### América-MG (MG)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Amazonas (AM)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Anápolis (GO)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### ASA (AL)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Barra (SC)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Botafogo-PB (PB)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Brusque (SC)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Caxias (RS)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Figueirense (SC)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Floresta (CE)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Gama (DF)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Goiatuba (GO)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Guarani (SP)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Ituano (SP)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Londrina (PR)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Maranhão (MA)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Nacional (AM)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Paysandu (PA)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Ponte Preta (SP)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Uberlândia (MG)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Volta Redonda (RJ)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

### Ypiranga (RS)
- **Jogadores:** nenhum nome de elenco 2027 publicamente verificável.
- **Fonte de participação:** [3].

## Vaga ainda não definida

### Último clube rebaixado da Série B 2026 — a confirmar
- **Jogadores:** não aplicável; o clube participante ainda não estava definido na notícia de 11 nov. 2026 [3].
- **Fonte:** [3].

## Observações de cobertura

A cobertura de participantes é de fonte jornalística, não uma lista final oficial da CBF; compreende 23 clubes confirmados e uma vaga pendente segundo a publicação de 11 nov. 2026 [3]. A tabela básica da CBF usada para delimitar a edição 2026 confirma que ela era edição anual, composta por 20 clubes, e não fonte de elencos para 2027 [2]. Não foi possível confirmar elencos de jogadores associados a 2027: clubes podem alterar contratos e inscrições entre edições, portanto elencos de 2026 ou temporadas anteriores foram deliberadamente omitidos. A página pública da CBF consultada rotula sua tabela como “2026” [1]; o levantamento não afirma ter verificado o fechamento posterior de eventuais transferências ou inscrições.

## Referências

[1]: https://www.cbf.com.br/futebol-brasileiro/tabelas/campeonato-brasileiro/serie-c "CBF, Campeonato Brasileiro Série C"
[2]: https://stcbfsiteprdimgbrs.blob.core.windows.net/img-site/cdn/Tabela_Basica_Brasileiro_Serie_C_2026_feac51f2a9.pdf "CBF, tabela básica da Série C 2026"
[3]: https://jornaldaparaiba.com.br/esportes/veja-os-times-confirmados-na-serie-c-do-brasileiro-2027 "Jornal da Paraíba, participantes confirmados da Série C 2027, 11 nov. 2026"
[4]: https://www.olympics.com/pt/noticias/serie-c-2027-times-terceira-divisao-brasileiro "Olympics.com, situação da Série C 2027, atualizado em 8 set. 2026"
