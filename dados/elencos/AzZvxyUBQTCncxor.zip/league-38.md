# Tunisian Ligue 1 — temporada 2026/27

- **País:** Tunísia
- **Campeonato:** Ligue Professionnelle 1 (Tunisian Ligue 1)
- **Divisão:** Primeira divisão
- **Temporada / status em 12 de novembro de 2026:** Em andamento. A Federação Tunisiana de Futebol (FTF) mantém resultados e calendário de 30 rodadas para 16 clubes. A cobertura de competição da Sport News Africa também identifica a edição 2026/27 como ativa e registra jogos disputados em outubro. [1] [2]

## Cobertura de elencos

A listagem pública consultada da Transfermarkt seleciona explicitamente 2026/27 (“26/27”), mostra 16 equipes e oferece, para cada uma, um link de elenco específico da temporada (`saison_id/2026`). Os links abaixo são referências secundárias de elenco e permitem consultar os nomes associados a cada clube. Não localizei, nas páginas oficiais consultadas da FTF, uma roster page oficial consolidada com nomes dos jogadores para todos os clubes. Por isso, não reproduzo nomes sem validação individual: esta entrega verifica e lista todos os participantes, mas **não constitui uma transcrição nominal completa dos jogadores**. Comissão técnica não é tratada como elenco de jogadores. [1] [3]

## Clubes participantes e fontes de elenco

Os nomes dos 16 clubes abaixo correspondem à listagem de clubes da edição 2026/27 na fonte de elencos. A FTF utiliza abreviações nos resultados; a Sport News Africa também mostra os clubes por nome em tabela e jogos. [1] [2] [3]

### Espérance Sportive de Tunis (Esperance Tunis)
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/esperance-tunis/kader/verein/3342/saison_id/2026).

### Club Africain
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/club-africain/kader/verein/819/saison_id/2026).

### Club Sportif Sfaxien (CS Sfaxien)
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/cs-sfaxien/kader/verein/581/saison_id/2026).

### Stade Tunisien
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/stade-tunisien/kader/verein/4812/saison_id/2026).

### Étoile Sportive du Sahel (Etoile Sportive du Sahel / ES Sahel)
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/etoile-sportive-du-sahel/kader/verein/250/saison_id/2026).

### Avenir Sportif de La Marsa (AS Marsa)
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/as-marsa/kader/verein/18792/saison_id/2026).

### Espérance Sportive de Zarzis (ES Zarzis)
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/es-zarzis/kader/verein/2205/saison_id/2026).

### Union Sportive Monastirienne (US Monastir)
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/us-monastir/kader/verein/9890/saison_id/2026).

### Club Athlétique Bizertin (CA Bizertin)
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/club-athletique-bizertin/kader/verein/12717/saison_id/2026).

### Union Sportive de Ben Guerdane
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/union-sportive-de-ben-guerdane/kader/verein/30507/saison_id/2026).

### Olympique de Béja
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/olympique-beja/kader/verein/8117/saison_id/2026).

### Jeunesse Sportive Omrane
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/jeunesse-sportive-omrane/kader/verein/88478/saison_id/2026).

### Étoile Sportive de Métlaoui (ES Metlaoui)
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/etoile-sportive-metlaoui/kader/verein/39801/saison_id/2026).

### Progrès Sportif de Sakiet Eddaïer
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/progres-sportif-sakiet-eddaier/kader/verein/63909/saison_id/2026).

### Club Sportif de Hammam-Lif
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/cs-hammam-lif/kader/verein/22815/saison_id/2026).

### Espoir Sportif de Hammam-Sousse
Jogadores: consultar [elenco 2026/27](https://www.transfermarkt.us/es-hammam-sousse/kader/verein/22817/saison_id/2026).

## Fontes

[1]: https://www.ftf.org.tn/fr/calendrier-ligue-i/ "Federação Tunisiana de Futebol — Calendário da Ligue I"
[2]: https://sportnewsafrica.com/en/fixtures/tunisian-ligue-1/ "Sport News Africa — Tunisian Ligue 1 2026-27 fixtures and results"
[3]: https://www.transfermarkt.us/ligue-1/startseite/wettbewerb/TUN1 "Transfermarkt — Tunisian Ligue 1, clubes e elencos 2026/27"
